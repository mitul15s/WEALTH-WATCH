#!/usr/bin/env python3
"""
WealthWatch India — Price Fetcher v3
======================================
Fetches prices for NSE/BSE stocks, crypto, and gold.
All values are stored and pushed in INR.

FX: Fetches live USD/INR rate from exchangerate-api (free tier).
NSE stocks: yfinance with .NS suffix (National Stock Exchange).
BSE stocks: yfinance with .BO suffix (Bombay Stock Exchange).
Crypto:     CoinGecko — prices requested directly in INR.
Gold:       MCX via yfinance (GOLD.MCX) or GC=F × USD/INR.

Setup:
  pip install requests yfinance apscheduler python-dotenv
"""

import os
import time
import logging
import requests
import yfinance as yf
from datetime import datetime, timezone, date
from dotenv import load_dotenv
from apscheduler.schedulers.blocking import BlockingScheduler

load_dotenv()

API_URL        = os.getenv("WEALTHWATCH_API_URL", "http://localhost:3000")
PRICE_SECRET   = os.getenv("PRICE_UPDATE_SECRET", "dev-secret-change-me")
FETCH_INTERVAL = int(os.getenv("FETCH_INTERVAL_MINUTES", "15"))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S IST",
)
log = logging.getLogger("WealthWatch-IN")

_last_snapshot_date = None
_usd_inr_rate       = 83.94          # fallback if FX fetch fails


# ── NSE/BSE Stocks (use .NS for NSE, .BO for BSE) ────────────────────
NSE_STOCK_MAP = {
    "RELIANCE.NS":  "RELIANCE",
    "TCS.NS":       "TCS",
    "HDFCBANK.NS":  "HDFCBANK",
    "INFY.NS":      "INFY",
    "WIPRO.NS":     "WIPRO",
    "ICICIBANK.NS": "ICICIBANK",
    "SBIN.NS":      "SBIN",
    "BAJFINANCE.NS":"BAJFINANCE",
    "LT.NS":        "LT",
    "ADANIENT.NS":  "ADANIENT",
    "HINDUNILVR.NS":"HINDUNILVR",
    "KOTAKBANK.NS": "KOTAKBANK",
    "AXISBANK.NS":  "AXISBANK",
    "SUNPHARMA.NS": "SUNPHARMA",
    "MARUTI.NS":    "MARUTI",
    "TATAMOTORS.NS":"TATAMOTORS",
    "TITAN.NS":     "TITAN",
    "NESTLEIND.NS": "NESTLEIND",
    "ASIANPAINT.NS":"ASIANPAINT",
    "ULTRACEMCO.NS":"ULTRACEMCO",
}

# ── Crypto tickers — CoinGecko IDs → WealthWatch ticker ──────────────
COINGECKO_MAP = {
    "bitcoin":      "BTC",
    "ethereum":     "ETH",
    "solana":       "SOL",
    "cardano":      "ADA",
    "matic-network":"MATIC",
    "polkadot":     "DOT",
    "chainlink":    "LINK",
    "dogecoin":     "DOGE",
    "ripple":       "XRP",
    "litecoin":     "LTC",
}


# ── FX rate: USD → INR ────────────────────────────────────────────────
def fetch_usd_inr() -> float:
    global _usd_inr_rate
    try:
        r = requests.get(
            "https://api.exchangerate-api.com/v4/latest/USD",
            timeout=8
        )
        r.raise_for_status()
        rate = r.json()["rates"]["INR"]
        _usd_inr_rate = rate
        log.info(f"USD/INR = {rate:.2f}")
        return rate
    except Exception as e:
        log.warning(f"FX fetch failed ({e}), using cached rate {_usd_inr_rate:.2f}")
        return _usd_inr_rate


# ── NSE/BSE Stocks ────────────────────────────────────────────────────
def fetch_nse_stocks() -> list[dict]:
    tickers = list(NSE_STOCK_MAP.keys())
    try:
        data = yf.download(
            tickers, period="2d", interval="1d",
            progress=False, auto_adjust=True
        )
        if data.empty:
            log.warning("yfinance returned empty NSE data")
            return []

        close = data["Close"]
        out   = []

        for yf_t, ww_t in NSE_STOCK_MAP.items():
            if yf_t not in close.columns:
                continue
            prices = close[yf_t].dropna()
            if len(prices) < 1:
                continue
            cur  = float(prices.iloc[-1])
            prev = float(prices.iloc[-2]) if len(prices) >= 2 else cur
            chg  = ((cur - prev) / prev * 100) if prev > 0 else 0
            out.append({
                "ticker":    ww_t,
                "price":     round(cur, 2),       # already in INR from NSE
                "change24h": round(chg, 4),
            })

        log.info(f"NSE/BSE stocks: {len(out)} tickers fetched")
        return out
    except Exception as e:
        log.error(f"NSE stock fetch failed: {e}")
        return []


# ── Crypto in INR via CoinGecko ───────────────────────────────────────
def fetch_crypto_inr() -> list[dict]:
    ids = ",".join(COINGECKO_MAP.keys())
    url = (
        f"https://api.coingecko.com/api/v3/simple/price"
        f"?ids={ids}&vs_currencies=inr&include_24hr_change=true"
    )
    try:
        resp = requests.get(url, timeout=12)
        resp.raise_for_status()
        data = resp.json()
        out  = []
        for cg_id, ticker in COINGECKO_MAP.items():
            if cg_id in data:
                out.append({
                    "ticker":    ticker,
                    "price":     round(data[cg_id].get("inr", 0), 2),
                    "change24h": round(data[cg_id].get("inr_24h_change", 0), 4),
                })
        log.info(f"Crypto: {len(out)} tickers in INR from CoinGecko")
        return out
    except Exception as e:
        log.error(f"CoinGecko fetch failed: {e}")
        return []


# ── Gold in INR via MCX ───────────────────────────────────────────────
def fetch_gold_inr(usd_inr: float) -> list[dict]:
    try:
        # Try MCX gold futures first (10g per unit)
        gold = yf.Ticker("GC=F").history(period="2d", interval="1d")
        if gold.empty:
            raise ValueError("Empty history for GC=F")

        cur_usd  = float(gold["Close"].iloc[-1])
        prev_usd = float(gold["Close"].iloc[-2]) if len(gold) >= 2 else cur_usd

        # Convert troy oz → 10g (1 troy oz = 31.1035g)
        # MCX Gold contract = 10g
        grams_per_oz = 31.1035
        cur_inr_10g  = (cur_usd  / grams_per_oz) * 10 * usd_inr
        prev_inr_10g = (prev_usd / grams_per_oz) * 10 * usd_inr
        chg          = ((cur_inr_10g - prev_inr_10g) / prev_inr_10g * 100) if prev_inr_10g > 0 else 0

        log.info(f"Gold: ₹{cur_inr_10g:.0f}/10g ({chg:+.2f}%)")
        return [
            {"ticker": "XAU",   "price": round(cur_inr_10g, 2),              "change24h": round(chg, 4)},
            {"ticker": "GOLD",  "price": round(cur_inr_10g, 2),              "change24h": round(chg, 4)},
            {"ticker": "GOLDG", "price": round(cur_inr_10g / 10, 2),         "change24h": round(chg, 4)},  # per gram
        ]
    except Exception as e:
        log.error(f"Gold fetch failed: {e}")
        return []


# ── Silver in INR ─────────────────────────────────────────────────────
def fetch_silver_inr(usd_inr: float) -> list[dict]:
    try:
        silver = yf.Ticker("SI=F").history(period="2d", interval="1d")
        if silver.empty:
            return []
        cur_usd  = float(silver["Close"].iloc[-1])
        prev_usd = float(silver["Close"].iloc[-2]) if len(silver) >= 2 else cur_usd
        grams_per_oz = 31.1035
        cur_inr_kg   = (cur_usd / grams_per_oz) * 1000 * usd_inr
        prev_inr_kg  = (prev_usd / grams_per_oz) * 1000 * usd_inr
        chg = ((cur_inr_kg - prev_inr_kg) / prev_inr_kg * 100) if prev_inr_kg > 0 else 0
        log.info(f"Silver: ₹{cur_inr_kg:.0f}/kg ({chg:+.2f}%)")
        return [{"ticker": "XAG", "price": round(cur_inr_kg, 2), "change24h": round(chg, 4)}]
    except Exception as e:
        log.warning(f"Silver fetch failed: {e}")
        return []


# ── Push helpers ──────────────────────────────────────────────────────
def _post(path: str, payload: dict) -> bool:
    try:
        r = requests.post(
            f"{API_URL}{path}",
            json=payload,
            headers={
                "Content-Type":   "application/json",
                "x-price-secret": PRICE_SECRET,
            },
            timeout=10,
        )
        r.raise_for_status()
        log.info(f"POST {path}: {r.json().get('message', 'OK')}")
        return True
    except Exception as e:
        log.error(f"POST {path} failed: {e}")
        return False


# ── Main fetch cycle ──────────────────────────────────────────────────
def run_cycle():
    global _last_snapshot_date
    log.info("=" * 54)
    ist = datetime.now(timezone.utc).astimezone(
        __import__("zoneinfo").ZoneInfo("Asia/Kolkata")
    )
    log.info(f"Cycle @ {ist.strftime('%H:%M IST, %d %b %Y')}")

    usd_inr = fetch_usd_inr()
    time.sleep(0.5)

    prices: list[dict] = []
    prices += fetch_nse_stocks()
    time.sleep(1.2)
    prices += fetch_crypto_inr()
    prices += fetch_gold_inr(usd_inr)
    prices += fetch_silver_inr(usd_inr)

    if not prices:
        log.error("All price fetches failed — nothing pushed")
        return

    ok = _post("/api/prices", {"prices": prices})
    if ok:
        _post("/api/alerts/evaluate", {})
        today = datetime.now(timezone.utc).date()
        if _last_snapshot_date != today:
            if _post("/api/snapshots", {}):
                _last_snapshot_date = today

    log.info(f"Cycle complete — {len(prices)} tickers pushed in INR")


# ── Entry point ───────────────────────────────────────────────────────
if __name__ == "__main__":
    log.info("WealthWatch India Price Fetcher v3")
    log.info(f"API  : {API_URL}")
    log.info(f"Every: {FETCH_INTERVAL} minutes")

    run_cycle()   # immediate first run on startup

    scheduler = BlockingScheduler(timezone="Asia/Kolkata")
    scheduler.add_job(
        run_cycle,
        trigger="interval",
        minutes=FETCH_INTERVAL,
        max_instances=1,
        coalesce=True,
    )
    log.info("Scheduler running — Ctrl+C to stop")
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        log.info("Stopped.")
