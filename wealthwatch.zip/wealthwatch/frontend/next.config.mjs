/** @type {import('next').NextConfig} */
const nextConfig = {
  env: {
    MONGODB_URI:             process.env.MONGODB_URI,
    NEXTAUTH_SECRET:         process.env.NEXTAUTH_SECRET,
    NEXTAUTH_URL:            process.env.NEXTAUTH_URL,
    PRICE_UPDATE_SECRET:     process.env.PRICE_UPDATE_SECRET,
    GOOGLE_CLIENT_ID:        process.env.GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET:    process.env.GOOGLE_CLIENT_SECRET,
    NEXT_PUBLIC_CURRENCY:    process.env.NEXT_PUBLIC_CURRENCY    || 'INR',
    NEXT_PUBLIC_LOCALE:      process.env.NEXT_PUBLIC_LOCALE      || 'en-IN',
    NEXT_PUBLIC_API_URL:     process.env.NEXT_PUBLIC_API_URL     || 'http://localhost:3000',
  },
  experimental: {
    serverComponentsExternalPackages: ['mongoose'],
  },
};

export default nextConfig;
