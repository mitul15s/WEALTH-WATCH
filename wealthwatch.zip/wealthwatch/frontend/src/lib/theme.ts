// ─── Metallic design tokens ────────────────────────────────────────────
export const T = {
  bg:       '#0e0f11',
  surface:  '#15161a',
  surface2: '#1c1d23',
  faint:    '#1e2028',
  border:   'rgba(255,255,255,0.06)',
  border2:  'rgba(255,255,255,0.11)',

  // metallic text ramp
  platinum: '#c8cdd6',
  silver:   '#9ba3af',
  steel:    '#6b7280',
  iron:     '#3d4249',

  // accent metals
  gold:    '#c9aa71',
  gold2:   '#e8d5a3',
  copper:  '#b87333',

  // semantic
  gain:    '#6dbf8a',
  gainBg:  'rgba(109,191,138,0.08)',
  loss:    '#d97070',
  lossBg:  'rgba(217,112,112,0.08)',
} as const;

// ─── Shared style helpers ──────────────────────────────────────────────
export const mono = "'JetBrains Mono', monospace";
export const sans = "'Inter', system-ui, sans-serif";

export const card: React.CSSProperties = {
  background: T.surface,
  border: `0.5px solid ${T.border}`,
  borderRadius: 10,
  padding: '18px 20px',
};

export const panelTitle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 500,
  color: T.silver,
  letterSpacing: '0.03em',
  marginBottom: 14,
};

export const label: React.CSSProperties = {
  fontSize: 10,
  fontFamily: mono,
  color: T.steel,
  letterSpacing: '0.08em',
  textTransform: 'uppercase' as const,
  marginBottom: 6,
};

export function gainLossColor(v: number) {
  return v >= 0 ? T.gain : T.loss;
}
export function gainLossBg(v: number) {
  return v >= 0 ? T.gainBg : T.lossBg;
}
