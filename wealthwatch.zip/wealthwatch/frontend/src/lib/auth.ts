import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { NextResponse } from 'next/server';

/**
 * Returns the userId from the current server-side session.
 * Returns a 401 NextResponse if there is no active session.
 *
 * Usage inside an API route:
 *   const { userId, error } = await requireAuth();
 *   if (error) return error;
 */
export async function requireAuth(): Promise<
  { userId: string; error: null } | { userId: null; error: NextResponse }
> {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    return {
      userId: null,
      error: NextResponse.json(
        { success: false, message: 'Unauthorised — please sign in' },
        { status: 401 }
      ),
    };
  }

  return { userId: session.user.id, error: null };
}

/**
 * Extend next-auth Session type to include userId.
 * Place this declaration in your global types or here.
 */
declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      name?: string | null;
      email?: string | null;
      image?: string | null;
    };
  }
}
