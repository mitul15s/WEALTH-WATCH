import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { AssetType } from '@/types';

// ─── Class merging ────────────────────────────────────────────────────
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ─── INR formatting (Indian numbering system: Lakhs & Crores) ─────────
export function formatCurrency(value: number, decimals = 0): string {
  const abs = Math.abs(value);
  const sign = value < 0 ? '-' : '';
  if (abs >= 1_00_00_000) return `${sign}₹${(abs / 1_00_00_000).toFixed(2)} Cr`;
  if (abs >= 1_00_000)    return `${sign}₹${(abs / 1_00_000).toFixed(2)} L`;
  return (
    sign +
    new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(value)
  );
}

export function formatCurrencyFull(value: number, decimals = 2): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value);
}

export function formatCompact(value: number): string {
  const abs = Math.abs(value);
  const sign = value < 0 ? '-' : '';
  if (abs >= 1_00_00_000) return `${sign}₹${(abs / 1_00_00_000).toFixed(2)}Cr`;
  if (abs >= 1_00_000)    return `${sign}₹${(abs / 1_00_000).toFixed(1)}L`;
  if (abs >= 1_000)       return `${sign}₹${(abs / 1_000).toFixed(1)}k`;
  return formatCurrency(value, 0);
}

export function formatPercent(value: number, decimals = 2): string {
  const sign = value >= 0 ? '+' : '';
  return `${sign}${value.toFixed(decimals)}%`;
}

export function formatNumber(value: number, decimals = 4): string {
  return new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  }).format(value);
}

// ─── Asset type metadata — metallic palette ───────────────────────────
export const ASSET_META: Record<AssetType, {
  label: string;
  icon: string;
  color: string;
  dimColor: string;
  textColor: string;
}> = {
  crypto: {
    label: 'Cryptocurrency',
    icon: '₿',
    color: '#c9aa71',
    dimColor: 'rgba(201,170,113,0.10)',
    textColor: '#c9aa71',
  },
  stocks: {
    label: 'Stocks (NSE/BSE)',
    icon: '◈',
    color: '#9ba3af',
    dimColor: 'rgba(155,163,175,0.10)',
    textColor: '#9ba3af',
  },
  gold: {
    label: 'Gold / Silver',
    icon: '◉',
    color: '#b87333',
    dimColor: 'rgba(184,115,51,0.10)',
    textColor: '#b87333',
  },
  cash: {
    label: 'Cash & Savings',
    icon: '₹',
    color: '#6dbf8a',
    dimColor: 'rgba(109,191,138,0.08)',
    textColor: '#6dbf8a',
  },
};

// ─── PnL helpers — metallic green/red ────────────────────────────────
export function isPnLPositive(value: number) { return value >= 0; }

export function pnlColor(value: number): string {
  return value >= 0 ? '#6dbf8a' : '#d97070';
}

export function pnlBgColor(value: number): string {
  return value >= 0 ? 'rgba(109,191,138,0.08)' : 'rgba(217,112,112,0.08)';
}

// ─── IST date formatting ──────────────────────────────────────────────
export function formatDate(iso: string): string {
  return new Intl.DateTimeFormat('en-IN', {
    month: 'short', day: 'numeric', year: 'numeric',
    timeZone: 'Asia/Kolkata',
  }).format(new Date(iso));
}

export function formatDateTime(iso: string): string {
  return new Intl.DateTimeFormat('en-IN', {
    month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
    timeZone: 'Asia/Kolkata',
  }).format(new Date(iso));
}

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins  = Math.floor(diff / 60_000);
  const hours = Math.floor(diff / 3_600_000);
  const days  = Math.floor(diff / 86_400_000);
  if (mins < 1)   return 'Just now';
  if (mins < 60)  return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

// ─── Misc ─────────────────────────────────────────────────────────────
export function clamp(val: number, min: number, max: number) {
  return Math.min(Math.max(val, min), max);
}

export function generateSparkData(length = 12, trend: 'up' | 'down' | 'flat' = 'up'): number[] {
  const data: number[] = [50];
  for (let i = 1; i < length; i++) {
    const noise = (Math.random() - 0.48) * 8;
    const drift = trend === 'up' ? 1.5 : trend === 'down' ? -1.5 : 0;
    data.push(Math.max(10, Math.min(100, data[i - 1] + noise + drift)));
  }
  return data;
}
