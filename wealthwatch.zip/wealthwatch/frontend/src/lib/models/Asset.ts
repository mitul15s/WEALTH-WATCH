import mongoose, { Schema, Document, Model } from 'mongoose';
import { AssetType } from '@/types';

export interface IAsset extends Document {
  userId: string;
  name: string;
  ticker: string;
  type: AssetType;
  quantity: number;
  avgBuyPrice: number;
  currentPrice: number;
  change24h: number;
  lastUpdated: Date;
  createdAt: Date;
  updatedAt: Date;
  // Virtuals
  currentValue: number;
  costBasis: number;
  unrealizedPnL: number;
  unrealizedPnLPct: number;
  change24hAbs: number;
}

const AssetSchema = new Schema<IAsset>(
  {
    userId:        { type: String, required: true, index: true },
    name:          { type: String, required: true, trim: true },
    ticker:        { type: String, required: true, trim: true, uppercase: true },
    type:          { type: String, enum: ['crypto', 'stocks', 'gold', 'cash'], required: true },
    quantity:      { type: Number, required: true, min: 0 },
    avgBuyPrice:   { type: Number, required: true, min: 0 },
    currentPrice:  { type: Number, default: 0, min: 0 },
    change24h:     { type: Number, default: 0 },    // % change
    lastUpdated:   { type: Date, default: Date.now },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// ─── Virtuals (computed, not stored) ─────────────────────────────────
AssetSchema.virtual('currentValue').get(function () {
  return this.quantity * this.currentPrice;
});

AssetSchema.virtual('costBasis').get(function () {
  return this.quantity * this.avgBuyPrice;
});

AssetSchema.virtual('unrealizedPnL').get(function () {
  return this.quantity * (this.currentPrice - this.avgBuyPrice);
});

AssetSchema.virtual('unrealizedPnLPct').get(function () {
  if (this.avgBuyPrice === 0) return 0;
  return ((this.currentPrice - this.avgBuyPrice) / this.avgBuyPrice) * 100;
});

AssetSchema.virtual('change24hAbs').get(function () {
  if (this.change24h === 0) return 0;
  const prevPrice = this.currentPrice / (1 + this.change24h / 100);
  return (this.currentPrice - prevPrice) * this.quantity;
});

// ─── Indexes ──────────────────────────────────────────────────────────
AssetSchema.index({ userId: 1, ticker: 1 });
AssetSchema.index({ userId: 1, type: 1 });

const Asset: Model<IAsset> =
  mongoose.models.Asset || mongoose.model<IAsset>('Asset', AssetSchema);

export default Asset;
