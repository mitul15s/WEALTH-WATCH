import mongoose, { Schema, Document, Model } from 'mongoose';
import { AssetType, TransactionType } from '@/types';

export interface ITransaction extends Document {
  userId: string;
  assetId: mongoose.Types.ObjectId;
  assetName: string;
  assetTicker: string;
  assetType: AssetType;
  type: TransactionType;
  quantity: number;
  price: number;
  total: number;
  fee: number;
  note: string;
  date: Date;
  createdAt: Date;
}

const TransactionSchema = new Schema<ITransaction>(
  {
    userId:       { type: String, required: true, index: true },
    assetId:      { type: Schema.Types.ObjectId, ref: 'Asset', required: true },
    assetName:    { type: String, required: true },
    assetTicker:  { type: String, required: true, uppercase: true },
    assetType:    { type: String, enum: ['crypto', 'stocks', 'gold', 'cash'], required: true },
    type:         { type: String, enum: ['BUY', 'SELL', 'DEPOSIT', 'WITHDRAW', 'TRANSFER'], required: true },
    quantity:     { type: Number, required: true, min: 0 },
    price:        { type: Number, required: true, min: 0 },
    total:        { type: Number, required: true },   // = quantity × price (+ fee for buys)
    fee:          { type: Number, default: 0 },
    note:         { type: String, default: '' },
    date:         { type: Date, default: Date.now },
  },
  { timestamps: true }
);

// ─── Indexes ──────────────────────────────────────────────────────────
TransactionSchema.index({ userId: 1, date: -1 });
TransactionSchema.index({ userId: 1, assetId: 1 });

const Transaction: Model<ITransaction> =
  mongoose.models.Transaction ||
  mongoose.model<ITransaction>('Transaction', TransactionSchema);

export default Transaction;
