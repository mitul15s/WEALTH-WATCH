import mongoose, { Schema, Document, Model } from 'mongoose';

export interface ISnapshot extends Document {
  userId: string;
  date: Date;          // start-of-day UTC — one doc per user per day
  totalValue: number;
  breakdown: {
    crypto: number;
    stocks: number;
    gold:   number;
    cash:   number;
  };
  createdAt: Date;
}

const SnapshotSchema = new Schema<ISnapshot>(
  {
    userId:     { type: String, required: true, index: true },
    date:       { type: Date,   required: true },
    totalValue: { type: Number, required: true },
    breakdown: {
      crypto: { type: Number, default: 0 },
      stocks: { type: Number, default: 0 },
      gold:   { type: Number, default: 0 },
      cash:   { type: Number, default: 0 },
    },
  },
  { timestamps: true }
);

// One snapshot per user per day
SnapshotSchema.index({ userId: 1, date: -1 }, { unique: true });

const Snapshot: Model<ISnapshot> =
  mongoose.models.Snapshot || mongoose.model<ISnapshot>('Snapshot', SnapshotSchema);

export default Snapshot;
