import mongoose, { Schema, Document, Model } from 'mongoose';

export type AlertCondition = 'above' | 'below' | 'change_pct_up' | 'change_pct_down';
export type AlertStatus    = 'active' | 'triggered' | 'dismissed';

export interface IAlert extends Document {
  userId:      string;
  assetId:     mongoose.Types.ObjectId;
  assetName:   string;
  assetTicker: string;
  condition:   AlertCondition;
  targetValue: number;           // price threshold or % change
  currentValue?: number;         // last checked value
  status:      AlertStatus;
  triggeredAt?: Date;
  notifyEmail: boolean;
  createdAt:   Date;
  updatedAt:   Date;
}

const AlertSchema = new Schema<IAlert>(
  {
    userId:      { type: String, required: true, index: true },
    assetId:     { type: Schema.Types.ObjectId, ref: 'Asset', required: true },
    assetName:   { type: String, required: true },
    assetTicker: { type: String, required: true, uppercase: true },
    condition:   {
      type: String,
      enum: ['above', 'below', 'change_pct_up', 'change_pct_down'],
      required: true,
    },
    targetValue:  { type: Number, required: true },
    currentValue: { type: Number },
    status:       { type: String, enum: ['active', 'triggered', 'dismissed'], default: 'active' },
    triggeredAt:  { type: Date },
    notifyEmail:  { type: Boolean, default: false },
  },
  { timestamps: true }
);

AlertSchema.index({ userId: 1, status: 1 });
AlertSchema.index({ assetId: 1, status: 1 });

const Alert: Model<IAlert> =
  mongoose.models.Alert || mongoose.model<IAlert>('Alert', AlertSchema);

export default Alert;
