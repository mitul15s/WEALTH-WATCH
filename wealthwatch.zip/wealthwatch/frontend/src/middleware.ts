import { withAuth } from 'next-auth/middleware';
import { NextResponse } from 'next/server';

export default withAuth(
  function middleware(req) {
    // If authenticated, allow through
    return NextResponse.next();
  },
  {
    callbacks: {
      // Authorised if a token exists
      authorized: ({ token }) => !!token,
    },
    pages: {
      signIn: '/auth/signin',
    },
  }
);

// Protect everything except auth pages, public assets, and API auth routes
export const config = {
  matcher: [
    '/((?!auth|api/auth|_next/static|_next/image|favicon.ico).*)',
  ],
};
