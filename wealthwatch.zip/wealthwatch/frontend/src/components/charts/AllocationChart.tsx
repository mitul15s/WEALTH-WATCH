'use client';

import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import { AllocationBreakdown } from '@/types';
import { formatCurrency, ASSET_META } from '@/lib/utils';
import { T, mono } from '@/lib/theme';

interface AllocationChartProps {
  allocation: AllocationBreakdown;
  totalValue: number;
}

const KEYS = ['crypto', 'stocks', 'gold', 'cash'] as const;

function CustomTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  const { name, value } = payload[0].payload;
  return (
    <div style={{ background: T.surface2, border: `0.5px solid ${T.border2}`, borderRadius: 8, padding: '9px 13px', fontFamily: mono }}>
      <div style={{ fontSize: 10, color: T.steel, marginBottom: 3 }}>{name}</div>
      <div style={{ fontSize: 13, fontWeight: 500, color: T.platinum }}>{formatCurrency(value)}</div>
    </div>
  );
}

export default function AllocationChart({ allocation, totalValue }: AllocationChartProps) {
  const data = KEYS
    .map(k => ({ key: k, name: ASSET_META[k].label, value: allocation[k] ?? 0, color: ASSET_META[k].color, pct: totalValue > 0 ? ((allocation[k] ?? 0) / totalValue) * 100 : 0 }))
    .filter(d => d.value > 0);

  return (
    <div style={{ background: T.surface, border: `0.5px solid ${T.border}`, borderRadius: 10, padding: '18px 20px' }}>
      <div style={{ fontSize: 12, fontWeight: 500, color: T.silver, letterSpacing: '0.03em', marginBottom: 14 }}>Allocation</div>

      <div style={{ height: 155, position: 'relative' }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} cx="50%" cy="50%" innerRadius={50} outerRadius={70} paddingAngle={2} dataKey="value" strokeWidth={0}>
              {data.map(e => <Cell key={e.key} fill={e.color} />)}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
          </PieChart>
        </ResponsiveContainer>
        <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', textAlign: 'center', pointerEvents: 'none' }}>
          <div style={{ fontSize: 15, fontWeight: 500, fontFamily: mono, color: T.platinum }}>100%</div>
          <div style={{ fontSize: 9, color: T.steel, fontFamily: mono, letterSpacing: '0.06em', textTransform: 'uppercase' }}>allocated</div>
        </div>
      </div>

      <div style={{ marginTop: 10 }}>
        {data.map((d, i) => (
          <div key={d.key} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 0', borderBottom: i < data.length - 1 ? `0.5px solid ${T.border}` : 'none' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
              <div style={{ width: 7, height: 7, borderRadius: 2, background: d.color, flexShrink: 0 }} />
              <span style={{ fontSize: 11, color: T.steel }}>{d.name}</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <span style={{ fontSize: 10, fontFamily: mono, color: T.iron }}>{d.pct.toFixed(0)}%</span>
              <span style={{ fontSize: 11, fontFamily: mono, fontWeight: 500, color: d.color }}>{formatCurrency(d.value)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
