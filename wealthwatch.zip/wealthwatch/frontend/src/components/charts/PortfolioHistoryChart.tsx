'use client';

import { useState, useEffect, useMemo } from 'react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ReferenceLine,
} from 'recharts';
import { TimeRange } from '@/types';
import { formatCurrency } from '@/lib/utils';

interface SnapshotPoint {
  date: string;
  totalValue: number;
  breakdown: { crypto: number; stocks: number; gold: number; cash: number };
}

const RANGES: TimeRange[] = ['1W', '1M', '3M', '6M', '1Y', 'ALL'];

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  const val = payload[0]?.value as number;
  const bd  = payload[0]?.payload?.breakdown;
  return (
    <div style={{
      background: '#1f222a', border: '0.5px solid rgba(255,255,255,0.13)',
      borderRadius: 10, padding: '12px 16px', fontFamily: "'DM Mono', monospace",
      minWidth: 180,
    }}>
      <div style={{ fontSize: 11, color: '#7a7a84', marginBottom: 8 }}>{label}</div>
      <div style={{ fontSize: 17, fontWeight: 500, color: '#e8e6e0', marginBottom: 8 }}>
        {formatCurrency(val, 0)}
      </div>
      {bd && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
          {[
            { k: 'crypto', c: '#d4952a', l: 'Crypto' },
            { k: 'stocks', c: '#5a8fc2', l: 'Stocks' },
            { k: 'gold',   c: '#c2a85a', l: 'Gold'   },
            { k: 'cash',   c: '#5aab7e', l: 'Cash'   },
          ].map(({ k, c, l }) => bd[k] > 0 && (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', gap: 16 }}>
              <span style={{ fontSize: 10, color: c }}>{l}</span>
              <span style={{ fontSize: 10, color: '#7a7a84' }}>{formatCurrency(bd[k], 0)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

interface PortfolioHistoryChartProps {
  currentValue: number;
}

export default function PortfolioHistoryChart({ currentValue }: PortfolioHistoryChartProps) {
  const [range,     setRange]     = useState<TimeRange>('1M');
  const [snapshots, setSnapshots] = useState<SnapshotPoint[]>([]);
  const [loading,   setLoading]   = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/snapshots?range=${range}`)
      .then(r => r.json())
      .then(j => { if (j.success) setSnapshots(j.data); })
      .finally(() => setLoading(false));
  }, [range]);

  const data = useMemo(() => {
    if (snapshots.length === 0) return [];
    return snapshots.map(s => ({
      label: new Date(s.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      value: s.totalValue,
      breakdown: s.breakdown,
    }));
  }, [snapshots]);

  const firstVal  = data[0]?.value ?? currentValue;
  const change    = currentValue - firstVal;
  const changePct = firstVal > 0 ? (change / firstVal) * 100 : 0;
  const isPos     = change >= 0;
  const lineColor = isPos ? '#d4952a' : '#c45c5c';

  // Cost-basis reference line (first snapshot value = approximate invested)
  const costBasis = firstVal;

  return (
    <div style={{
      background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)',
      borderRadius: 12, padding: '22px 24px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
        <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: '0.04em' }}>Portfolio History</div>
        <div style={{ display: 'flex' }}>
          {RANGES.map((r, i) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              style={{
                padding: '4px 10px', background: range === r ? '#1f222a' : 'none',
                border: '0.5px solid rgba(255,255,255,0.07)',
                borderLeft: i > 0 ? 'none' : undefined,
                borderRadius: i === 0 ? '6px 0 0 6px' : i === RANGES.length - 1 ? '0 6px 6px 0' : 0,
                color: range === r ? '#e8e6e0' : '#7a7a84',
                fontFamily: "'DM Mono', monospace", fontSize: 11,
                cursor: 'pointer', transition: 'all 0.15s',
              }}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 18 }}>
        <span style={{
          fontSize: 11, fontFamily: "'DM Mono', monospace",
          color: isPos ? '#5aab7e' : '#c45c5c',
          padding: '2px 8px', borderRadius: 4,
          background: isPos ? 'rgba(90,171,126,0.1)' : 'rgba(196,92,92,0.1)',
        }}>
          {isPos ? '▲' : '▼'} {isPos ? '+' : ''}{formatCurrency(change, 0)} ({changePct >= 0 ? '+' : ''}{changePct.toFixed(2)}%)
        </span>
        <span style={{ fontSize: 11, color: '#44454d', fontFamily: "'DM Mono', monospace" }}>
          over {range === 'ALL' ? 'all time' : `the last ${range}`}
        </span>
        {loading && (
          <span style={{ fontSize: 11, color: '#44454d', fontFamily: "'DM Mono', monospace" }}>
            · loading…
          </span>
        )}
      </div>

      <div style={{ height: 220 }}>
        {data.length > 1 ? (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="histGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%"   stopColor={lineColor} stopOpacity={0.2} />
                  <stop offset="100%" stopColor={lineColor} stopOpacity={0.01} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
              <XAxis
                dataKey="label"
                tick={{ fill: '#44454d', fontSize: 10, fontFamily: "'DM Mono', monospace" }}
                tickLine={false} axisLine={false} interval="preserveStartEnd"
              />
              <YAxis
                tick={{ fill: '#44454d', fontSize: 10, fontFamily: "'DM Mono', monospace" }}
                tickLine={false} axisLine={false}
                tickFormatter={v => `$${(v / 1000).toFixed(0)}k`}
                width={48}
              />
              <Tooltip content={<CustomTooltip />} cursor={{ stroke: 'rgba(255,255,255,0.08)', strokeWidth: 1 }} />
              {/* Cost basis reference line */}
              <ReferenceLine
                y={costBasis}
                stroke="rgba(255,255,255,0.12)"
                strokeDasharray="4 4"
                label={{ value: 'start', position: 'right', fontSize: 9, fill: '#44454d', fontFamily: "'DM Mono', monospace" }}
              />
              <Area
                type="monotone" dataKey="value"
                stroke={lineColor} strokeWidth={1.5}
                fill="url(#histGrad)" dot={false}
                activeDot={{ r: 4, fill: lineColor, strokeWidth: 0 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          /* Empty state while data accumulates */
          <div style={{
            height: '100%', display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            color: '#44454d', gap: 8,
          }}>
            <div style={{ fontSize: 28 }}>◈</div>
            <div style={{ fontSize: 12, fontFamily: "'DM Mono', monospace" }}>
              {loading ? 'Loading history…' : 'History builds daily — check back tomorrow'}
            </div>
            <div style={{ fontSize: 11, color: '#2c2d32', fontFamily: "'DM Mono', monospace", maxWidth: 280, textAlign: 'center' }}>
              A snapshot is taken automatically at midnight UTC each day
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
