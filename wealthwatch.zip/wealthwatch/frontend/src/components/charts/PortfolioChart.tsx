'use client';

import { useState, useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TimeRange } from '@/types';
import { formatCurrency, formatCompact, formatPercent } from '@/lib/utils';
import { T, mono } from '@/lib/theme';

function generateHistory(endValue: number, range: TimeRange) {
  const configs: Record<TimeRange, { points: number; volatility: number; drift: number }> = {
    '1D': { points: 24, volatility: 0.004, drift: 0.001 },
    '1W': { points: 7,  volatility: 0.012, drift: 0.004 },
    '1M': { points: 30, volatility: 0.018, drift: 0.008 },
    '3M': { points: 12, volatility: 0.025, drift: 0.015 },
    '1Y': { points: 12, volatility: 0.04,  drift: 0.025 },
    'ALL':{ points: 16, volatility: 0.055, drift: 0.04  },
  };
  const { points, volatility, drift } = configs[range];
  const rawVals: number[] = [endValue];
  for (let i = 1; i < points; i++) {
    const noise = (Math.random() - 0.48) * volatility;
    rawVals.unshift(rawVals[0] * (1 - drift - noise));
  }
  const now = new Date();
  return rawVals.map((v, i) => {
    const d = new Date(now);
    const label = (() => {
      if (range === '1D') { d.setHours(now.getHours() - (points - 1 - i)); return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false }); }
      if (range === '1W') { d.setDate(now.getDate() - (points - 1 - i)); return d.toLocaleDateString('en-IN', { weekday: 'short' }); }
      if (range === '1M') { d.setDate(now.getDate() - (points - 1 - i)); return d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }); }
      d.setMonth(now.getMonth() - (points - 1 - i));
      return d.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });
    })();
    return { label, value: Math.round(v) };
  });
}

const RANGES: TimeRange[] = ['1D', '1W', '1M', '3M', '1Y', 'ALL'];

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: T.surface2, border: `0.5px solid ${T.border2}`, borderRadius: 8, padding: '9px 13px', fontFamily: mono }}>
      <div style={{ fontSize: 10, color: T.steel, marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 14, fontWeight: 500, color: T.platinum }}>{formatCurrency(payload[0].value)}</div>
    </div>
  );
}

export default function PortfolioChart({ currentValue }: { currentValue: number }) {
  const [range, setRange] = useState<TimeRange>('1W');
  const data    = useMemo(() => generateHistory(currentValue || 18_00_000, range), [currentValue, range]);
  const startVal = data[0]?.value ?? 0;
  const change   = currentValue - startVal;
  const changePct = startVal > 0 ? (change / startVal) * 100 : 0;
  const isPos = change >= 0;
  const lineColor = T.gold;

  return (
    <div style={{ background: T.surface, border: `0.5px solid ${T.border}`, borderRadius: 10, padding: '18px 20px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
        <div style={{ fontSize: 12, fontWeight: 500, color: T.silver, letterSpacing: '0.03em' }}>Portfolio performance</div>
        <div style={{ display: 'flex' }}>
          {RANGES.map((r, i) => (
            <button key={r} onClick={() => setRange(r)} style={{
              padding: '3px 9px', background: range === r ? T.faint : 'none',
              border: `0.5px solid ${T.border}`,
              borderLeft: i > 0 ? 'none' : undefined,
              borderRadius: i === 0 ? '5px 0 0 5px' : i === RANGES.length - 1 ? '0 5px 5px 0' : 0,
              color: range === r ? T.platinum : T.steel,
              fontFamily: mono, fontSize: 10, cursor: 'pointer', letterSpacing: '0.04em',
              transition: 'all 0.15s',
            }}>{r}</button>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
        <span style={{ fontSize: 10, fontFamily: mono, color: isPos ? T.gain : T.loss, padding: '2px 7px', borderRadius: 4, background: isPos ? T.gainBg : T.lossBg }}>
          {isPos ? '▲ +' : '▼ '}{formatCompact(Math.abs(change))} ({formatPercent(changePct)})
        </span>
        <span style={{ fontSize: 10, color: T.iron, fontFamily: mono }}>vs period start</span>
      </div>

      <div style={{ height: 195 }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 4, right: 2, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="pgGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={lineColor} stopOpacity={0.15} />
                <stop offset="100%" stopColor={lineColor} stopOpacity={0.01} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" vertical={false} />
            <XAxis dataKey="label" tick={{ fill: T.iron, fontSize: 9, fontFamily: mono }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
            <YAxis tick={{ fill: T.iron, fontSize: 9, fontFamily: mono }} tickLine={false} axisLine={false} tickFormatter={v => `₹${(v/100000).toFixed(0)}L`} width={44} />
            <Tooltip content={<CustomTooltip />} cursor={{ stroke: 'rgba(255,255,255,0.06)', strokeWidth: 1 }} />
            <Area type="monotone" dataKey="value" stroke={lineColor} strokeWidth={1.2} fill="url(#pgGrad)" dot={false} activeDot={{ r: 3, fill: lineColor, strokeWidth: 0 }} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
