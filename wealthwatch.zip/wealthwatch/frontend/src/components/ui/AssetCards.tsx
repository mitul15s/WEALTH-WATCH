'use client';

import { AllocationBreakdown, Asset, AssetType } from '@/types';
import { formatCurrency, formatPercent, ASSET_META, generateSparkData } from '@/lib/utils';
import { T, mono } from '@/lib/theme';

interface AssetCardsProps {
  assets: Asset[];
  allocation: AllocationBreakdown;
  totalValue: number;
  loading?: boolean;
}

const ASSET_TYPES: AssetType[] = ['crypto', 'stocks', 'gold', 'cash'];

function Sparkline({ data, color }: { data: number[]; color: string }) {
  const max = Math.max(...data), min = Math.min(...data), range = max - min || 1;
  const W = 120, H = 28;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * W;
    const y = H - ((v - min) / range) * (H - 4) - 2;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" style={{ height: 28, display: 'block', marginTop: 10 }}>
      <polyline points={pts.join(' ')} fill="none" stroke={color} strokeWidth="1.2" strokeLinejoin="round" strokeLinecap="round" opacity={0.65} />
      <circle cx={pts[pts.length - 1].split(',')[0]} cy={pts[pts.length - 1].split(',')[1]} r="2" fill={color} />
    </svg>
  );
}

function SkeletonCard() {
  return (
    <div style={{ background: T.surface, border: `0.5px solid ${T.border}`, borderRadius: 10, padding: '16px 18px' }}>
      <div className="skeleton" style={{ width: 30, height: 30, borderRadius: 7, marginBottom: 12 }} />
      <div className="skeleton" style={{ width: 70, height: 10, marginBottom: 7 }} />
      <div className="skeleton" style={{ width: 110, height: 20, marginBottom: 5 }} />
      <div className="skeleton" style={{ width: 55, height: 10, marginBottom: 12 }} />
      <div className="skeleton" style={{ width: '100%', height: 28 }} />
    </div>
  );
}

export default function AssetCards({ assets, allocation, totalValue, loading }: AssetCardsProps) {
  if (loading) {
    return (
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10, marginBottom: 14 }}>
        {[0,1,2,3].map(i => <SkeletonCard key={i} />)}
      </div>
    );
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10, marginBottom: 14 }}>
      {ASSET_TYPES.map(type => {
        const meta       = ASSET_META[type];
        const value      = allocation[type] ?? 0;
        const pct        = totalValue > 0 ? (value / totalValue) * 100 : 0;
        const typeAssets = assets.filter(a => a.type === type);
        const wgtChg     = typeAssets.length && value > 0
          ? typeAssets.reduce((s, a) => s + (a.change24h ?? 0) * (a.currentValue ?? 0), 0) / value
          : 0;
        const isPos  = wgtChg >= 0;
        const trend  = wgtChg > 0.5 ? 'up' : wgtChg < -0.5 ? 'down' : 'flat';
        const sparks = generateSparkData(14, trend);

        return (
          <div
            key={type}
            style={{
              background: T.surface, border: `0.5px solid ${T.border}`,
              borderRadius: 10, padding: '16px 18px', cursor: 'pointer',
              transition: 'border-color 0.15s, background 0.15s',
            }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLElement).style.borderColor = T.border2;
              (e.currentTarget as HTMLElement).style.background  = T.surface2;
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLElement).style.borderColor = T.border;
              (e.currentTarget as HTMLElement).style.background  = T.surface;
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <div style={{ width: 30, height: 30, borderRadius: 7, background: meta.dimColor, color: meta.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 500 }}>
                {meta.icon}
              </div>
              <span style={{ fontSize: 10, fontFamily: mono, fontWeight: 500, color: isPos ? T.gain : T.loss }}>
                {isPos ? '+' : ''}{wgtChg.toFixed(2)}%
              </span>
            </div>
            <div style={{ fontSize: 10, fontFamily: mono, color: T.steel, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 3 }}>
              {meta.label}
            </div>
            <div style={{ fontSize: 18, fontWeight: 400, fontFamily: mono, color: meta.color }}>
              {formatCurrency(value)}
            </div>
            <div style={{ fontSize: 10, color: T.iron, fontFamily: mono, marginTop: 2 }}>
              {pct.toFixed(1)}% · {typeAssets.length} position{typeAssets.length !== 1 ? 's' : ''}
            </div>
            <Sparkline data={sparks} color={meta.color} />
          </div>
        );
      })}
    </div>
  );
}
