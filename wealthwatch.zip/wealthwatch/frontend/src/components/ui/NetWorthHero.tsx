'use client';

import { PortfolioSnapshot } from '@/types';
import { formatCurrency, formatCompact, formatPercent } from '@/lib/utils';
import { T, mono, gainLossColor, gainLossBg } from '@/lib/theme';

interface NetWorthHeroProps {
  portfolio: PortfolioSnapshot | null;
  loading?: boolean;
}

export default function NetWorthHero({ portfolio, loading }: NetWorthHeroProps) {
  if (loading || !portfolio) {
    return (
      <div style={{ background: T.surface, border: `0.5px solid ${T.border}`, borderRadius: 10, padding: '24px 28px', marginBottom: 14, height: 110 }}>
        <div className="skeleton" style={{ width: 120, height: 11, marginBottom: 10 }} />
        <div className="skeleton" style={{ width: 260, height: 42 }} />
      </div>
    );
  }

  const { totalValue, totalChange24h, totalChange24hPct, totalUnrealizedPnL, totalUnrealizedPnLPct, assets } = portfolio;
  const isPosChange = totalChange24h >= 0;
  const isPosPnL    = totalUnrealizedPnL >= 0;
  const topAsset    = assets[0];

  return (
    <div style={{
      background: T.surface, border: `0.5px solid ${T.border2}`, borderRadius: 10,
      padding: '22px 28px', marginBottom: 14,
      display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
      position: 'relative', overflow: 'hidden', flexWrap: 'wrap', gap: 18,
    }}>
      {/* subtle gold gradient sweep */}
      <div style={{ position: 'absolute', top: 0, right: 0, width: 200, height: '100%', background: 'linear-gradient(90deg, transparent, rgba(201,170,113,0.025))', pointerEvents: 'none' }} />

      <div>
        <div style={{ fontSize: 10, fontFamily: mono, color: T.steel, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 7 }}>
          Total Net Worth
        </div>
        <div style={{ fontSize: 40, fontWeight: 300, color: T.platinum, letterSpacing: '-0.02em', lineHeight: 1, fontFamily: "'Inter', sans-serif" }}>
          <span style={{ fontSize: 22, fontWeight: 400, color: T.silver, marginRight: 3 }}>₹</span>
          {Math.round(totalValue).toLocaleString('en-IN')}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 9 }}>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 4, padding: '3px 8px', borderRadius: 4,
            fontSize: 11, fontFamily: mono, fontWeight: 500,
            background: gainLossBg(totalChange24h), color: gainLossColor(totalChange24h),
          }}>
            {isPosChange ? '▲' : '▼'} {isPosChange ? '+' : ''}{formatCompact(totalChange24h)} ({formatPercent(totalChange24hPct)})
          </span>
          <span style={{ fontSize: 11, color: T.iron, fontFamily: mono }}>24h</span>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 32, flexWrap: 'wrap' }}>
        {[
          {
            label: 'Unrealized P&L',
            value: (isPosPnL ? '+' : '') + formatCompact(totalUnrealizedPnL),
            sub: formatPercent(totalUnrealizedPnLPct),
            color: gainLossColor(totalUnrealizedPnL),
          },
          {
            label: 'Top holding',
            value: topAsset?.ticker ?? '—',
            sub: topAsset ? formatPercent(topAsset.change24h) : '',
            color: topAsset ? gainLossColor(topAsset.change24h) : T.steel,
          },
          {
            label: 'Positions',
            value: String(assets.length),
            sub: 'tracked',
            color: T.platinum,
          },
        ].map(({ label, value, sub, color }) => (
          <div key={label} style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 10, fontFamily: mono, color: T.steel, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 4 }}>{label}</div>
            <div style={{ fontSize: 20, fontWeight: 400, fontFamily: mono, color }}>{value}</div>
            <div style={{ fontSize: 10, fontFamily: mono, color, marginTop: 2, opacity: 0.8 }}>{sub}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
