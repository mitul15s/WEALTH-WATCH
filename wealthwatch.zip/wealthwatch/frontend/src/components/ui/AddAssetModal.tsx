'use client';

import { useState, useRef, useEffect } from 'react';
import { X } from 'lucide-react';
import { AssetType } from '@/types';
import { ASSET_META, formatCurrency } from '@/lib/utils';
import { T, mono } from '@/lib/theme';
import toast from 'react-hot-toast';

interface AddAssetModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const ASSET_TYPES: AssetType[] = ['crypto', 'stocks', 'gold', 'cash'];

const SUGGESTIONS: Record<AssetType, string[]> = {
  crypto: ['BTC', 'ETH', 'SOL', 'ADA', 'MATIC', 'XRP'],
  stocks: ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'WIPRO', 'SBIN', 'BAJFINANCE', 'ICICIBANK'],
  gold:   ['XAU', 'XAG', 'GOLD'],
  cash:   ['SAVINGS', 'FD', 'PPF', 'NPS'],
};

const NAMES: Record<AssetType, { [k: string]: string }> = {
  crypto: { BTC: 'Bitcoin', ETH: 'Ethereum', SOL: 'Solana', ADA: 'Cardano', MATIC: 'Polygon', XRP: 'XRP' },
  stocks: { RELIANCE: 'Reliance Industries', TCS: 'Tata Consultancy Services', HDFCBANK: 'HDFC Bank', INFY: 'Infosys', WIPRO: 'Wipro', SBIN: 'State Bank of India', BAJFINANCE: 'Bajaj Finance', ICICIBANK: 'ICICI Bank' },
  gold:   { XAU: 'Gold (10g)', XAG: 'Silver (1kg)', GOLD: 'Digital Gold' },
  cash:   { SAVINGS: 'Savings Account', FD: 'Fixed Deposit', PPF: 'PPF Account', NPS: 'NPS Account' },
};

const INPUT: React.CSSProperties = {
  width: '100%', background: T.bg, border: `0.5px solid ${T.border2}`,
  borderRadius: 7, padding: '9px 11px', color: T.platinum,
  fontFamily: mono, fontSize: 12, outline: 'none', transition: 'border-color 0.15s',
};

const FIELD = ({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) => (
  <div style={{ marginBottom: 13 }}>
    <div style={{ fontSize: 10, fontFamily: mono, color: T.steel, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 5 }}>{label}</div>
    {children}
    {error && <div style={{ fontSize: 10, color: T.loss, marginTop: 3, fontFamily: mono }}>{error}</div>}
  </div>
);

export default function AddAssetModal({ open, onClose, onSuccess }: AddAssetModalProps) {
  const [type,        setType]       = useState<AssetType>('stocks');
  const [name,        setName]       = useState('');
  const [ticker,      setTicker]     = useState('');
  const [quantity,    setQuantity]   = useState('');
  const [avgBuyPrice, setAvgBuyPrice]= useState('');
  const [loading,     setLoading]    = useState(false);
  const [errors,      setErrors]     = useState<Record<string, string>>({});
  const nameRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) { setTimeout(() => nameRef.current?.focus(), 80); setName(''); setTicker(''); setQuantity(''); setAvgBuyPrice(''); setErrors({}); }
  }, [open]);

  useEffect(() => {
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', esc);
    return () => window.removeEventListener('keydown', esc);
  }, [onClose]);

  function pickSuggestion(s: string) {
    setTicker(s);
    const nameMap = NAMES[type];
    if (nameMap[s] && !name) setName(nameMap[s]);
  }

  function validate() {
    const e: Record<string, string> = {};
    if (!name.trim())              e.name        = 'Name required';
    if (!ticker.trim())            e.ticker      = 'Ticker required';
    if (!quantity || +quantity<=0) e.quantity    = 'Enter valid quantity';
    if (!avgBuyPrice || +avgBuyPrice<=0) e.price = 'Enter valid price in ₹';
    setErrors(e); return Object.keys(e).length === 0;
  }

  async function handleSubmit() {
    if (!validate()) return;
    setLoading(true);
    try {
      const res  = await fetch('/api/assets', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: name.trim(), ticker: ticker.trim().toUpperCase(), type, quantity: parseFloat(quantity), avgBuyPrice: parseFloat(avgBuyPrice) }) });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      toast.success(`${ticker.toUpperCase()} added`);
      onSuccess(); onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to add asset');
    } finally { setLoading(false); }
  }

  const totalCost = (parseFloat(quantity) || 0) * (parseFloat(avgBuyPrice) || 0);
  if (!open) return null;

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div style={{ background: T.surface, border: `0.5px solid ${T.border2}`, borderRadius: 12, padding: '24px 28px', width: 460, maxWidth: '100%', animation: 'fadeIn 0.18s ease' }}
        onClick={e => e.stopPropagation()}>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <div style={{ fontSize: 15, fontWeight: 500, color: T.platinum }}>Add asset</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: T.steel, display: 'flex', alignItems: 'center' }}><X size={17} /></button>
        </div>

        {/* Type selector */}
        <div style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 10, fontFamily: mono, color: T.steel, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 8 }}>Asset type</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 7 }}>
            {ASSET_TYPES.map(t => {
              const m = ASSET_META[t]; const sel = type === t;
              return (
                <button key={t} onClick={() => { setType(t); setTicker(''); setName(''); }}
                  style={{ padding: '9px 6px', borderRadius: 8, border: sel ? `1px solid ${m.color}` : `0.5px solid ${T.border}`, background: sel ? m.dimColor : 'none', color: sel ? m.color : T.steel, cursor: 'pointer', transition: 'all 0.15s', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                  <span style={{ fontSize: 16 }}>{m.icon}</span>
                  <span style={{ fontSize: 9, fontFamily: mono, letterSpacing: '0.04em' }}>{t.toUpperCase()}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <FIELD label="Asset name" error={errors.name}>
            <input ref={nameRef} style={{ ...INPUT, borderColor: errors.name ? T.loss : undefined }} placeholder="e.g. Reliance Industries" value={name} onChange={e => setName(e.target.value)} />
          </FIELD>
          <FIELD label="Ticker" error={errors.ticker}>
            <input style={{ ...INPUT, borderColor: errors.ticker ? T.loss : undefined }} placeholder="e.g. RELIANCE" value={ticker} onChange={e => setTicker(e.target.value.toUpperCase())} />
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginTop: 5 }}>
              {SUGGESTIONS[type].slice(0,5).map(s => (
                <span key={s} onClick={() => pickSuggestion(s)} style={{ fontSize: 9, fontFamily: mono, padding: '2px 6px', borderRadius: 3, background: T.faint, color: T.steel, cursor: 'pointer', border: `0.5px solid ${T.border}`, transition: 'color 0.12s' }}
                  onMouseEnter={e => (e.currentTarget.style.color = T.gold)} onMouseLeave={e => (e.currentTarget.style.color = T.steel)}>{s}</span>
              ))}
            </div>
          </FIELD>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <FIELD label="Quantity" error={errors.quantity}>
            <input type="number" min="0" step="any" style={{ ...INPUT, borderColor: errors.quantity ? T.loss : undefined }} placeholder="0" value={quantity} onChange={e => setQuantity(e.target.value)} />
          </FIELD>
          <FIELD label="Avg buy price (₹)" error={errors.price}>
            <input type="number" min="0" step="any" style={{ ...INPUT, borderColor: errors.price ? T.loss : undefined }} placeholder="0.00" value={avgBuyPrice} onChange={e => setAvgBuyPrice(e.target.value)} />
          </FIELD>
        </div>

        {totalCost > 0 && (
          <div style={{ background: T.faint, borderRadius: 7, padding: '9px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, border: `0.5px solid ${T.border}` }}>
            <span style={{ fontSize: 11, color: T.steel, fontFamily: mono }}>Cost basis</span>
            <span style={{ fontSize: 14, fontWeight: 500, fontFamily: mono, color: T.gold }}>{formatCurrency(totalCost)}</span>
          </div>
        )}

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
          <button onClick={onClose} style={{ background: 'none', border: `0.5px solid ${T.border2}`, borderRadius: 7, padding: '8px 18px', color: T.steel, fontSize: 12, cursor: 'pointer', fontFamily: "'Inter', sans-serif" }}>Cancel</button>
          <button onClick={handleSubmit} disabled={loading} style={{ background: loading ? 'rgba(201,170,113,0.5)' : T.gold, color: '#0e0e0e', border: 'none', borderRadius: 7, padding: '8px 18px', fontSize: 12, fontWeight: 500, cursor: loading ? 'not-allowed' : 'pointer', fontFamily: "'Inter', sans-serif" }}>
            {loading ? 'Adding…' : 'Add Asset'}
          </button>
        </div>
      </div>
    </div>
  );
}
