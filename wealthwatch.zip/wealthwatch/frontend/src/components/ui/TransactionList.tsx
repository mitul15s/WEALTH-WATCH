'use client';

import { Transaction } from '@/types';
import { formatCurrency, formatDateTime, ASSET_META } from '@/lib/utils';
import { T, mono } from '@/lib/theme';

const TX_STYLE: Record<string, { label: string; color: string; bg: string }> = {
  BUY:      { label: 'BUY',  color: T.gain, bg: T.gainBg },
  SELL:     { label: 'SELL', color: T.loss, bg: T.lossBg },
  DEPOSIT:  { label: 'DEP',  color: '#8bafc9', bg: 'rgba(139,175,201,0.08)' },
  WITHDRAW: { label: 'WDR',  color: T.copper,  bg: 'rgba(184,115,51,0.08)'  },
  TRANSFER: { label: 'TRF',  color: T.silver,  bg: 'rgba(155,163,175,0.08)' },
};

function SkeletonRow() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 6px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
        <div className="skeleton" style={{ width: 28, height: 28, borderRadius: 7 }} />
        <div>
          <div className="skeleton" style={{ width: 90, height: 12, marginBottom: 5 }} />
          <div className="skeleton" style={{ width: 65, height: 10 }} />
        </div>
      </div>
      <div className="skeleton" style={{ width: 70, height: 13 }} />
    </div>
  );
}

export default function TransactionList({ transactions, loading, limit }: { transactions: Transaction[]; loading?: boolean; limit?: number }) {
  const items = limit ? transactions.slice(0, limit) : transactions;

  if (loading) return <div>{[0,1,2,3,4].map(i => <SkeletonRow key={i} />)}</div>;

  if (items.length === 0) {
    return <div style={{ textAlign: 'center', padding: '28px 0', color: T.iron, fontSize: 12, fontFamily: mono }}>No transactions yet</div>;
  }

  return (
    <div>
      {items.map((tx, i) => {
        const meta  = ASSET_META[tx.assetType];
        const s     = TX_STYLE[tx.type] ?? TX_STYLE.BUY;
        const isOut = ['SELL', 'WITHDRAW'].includes(tx.type);
        return (
          <div key={tx._id}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 6px', borderRadius: 7, borderBottom: i < items.length - 1 ? `0.5px solid rgba(255,255,255,0.03)` : 'none', transition: 'background 0.12s', cursor: 'default' }}
            onMouseEnter={e => (e.currentTarget.style.background = T.faint)}
            onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <div style={{ width: 28, height: 28, borderRadius: 7, background: meta.dimColor, color: meta.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 500, flexShrink: 0 }}>
                {meta.icon}
              </div>
              <div>
                <div style={{ fontSize: 12, fontWeight: 500, color: T.platinum }}>{tx.assetName}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 2 }}>
                  <span style={{ fontSize: 9, padding: '1px 5px', borderRadius: 3, background: s.bg, color: s.color, fontFamily: mono, letterSpacing: '0.04em' }}>{s.label}</span>
                  <span style={{ fontSize: 10, color: T.steel, fontFamily: mono }}>{formatDateTime(tx.date)}</span>
                </div>
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 12, fontFamily: mono, fontWeight: 500, color: isOut ? T.loss : T.gain }}>
                {isOut ? '−' : '+'}{formatCurrency(Math.abs(tx.total))}
              </div>
              <div style={{ fontSize: 10, color: T.steel, fontFamily: mono, marginTop: 1 }}>
                {tx.quantity.toFixed(4)} {tx.assetTicker}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
