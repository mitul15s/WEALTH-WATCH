'use client';

import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Asset, TransactionType } from '@/types';
import { ASSET_META, formatCurrency } from '@/lib/utils';
import toast from 'react-hot-toast';

interface AddTransactionModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
  assets: Asset[];
  defaultAssetId?: string;
}

const TX_TYPES: TransactionType[] = ['BUY', 'SELL', 'DEPOSIT', 'WITHDRAW'];
const TX_COLORS: Record<TransactionType, string> = {
  BUY:      '#5aab7e',
  SELL:     '#c45c5c',
  DEPOSIT:  '#5a8fc2',
  WITHDRAW: '#c2a85a',
  TRANSFER: '#8b6fc2',
};

const INPUT: React.CSSProperties = {
  width: '100%', background: '#1f222a',
  border: '0.5px solid rgba(255,255,255,0.13)', borderRadius: 8,
  padding: '10px 12px', color: '#e8e6e0',
  fontFamily: "'DM Mono', monospace", fontSize: 13, outline: 'none',
};

export default function AddTransactionModal({
  open, onClose, onSuccess, assets, defaultAssetId,
}: AddTransactionModalProps) {
  const [assetId,  setAssetId]  = useState(defaultAssetId || '');
  const [type,     setType]     = useState<TransactionType>('BUY');
  const [quantity, setQuantity] = useState('');
  const [price,    setPrice]    = useState('');
  const [fee,      setFee]      = useState('0');
  const [note,     setNote]     = useState('');
  const [date,     setDate]     = useState(new Date().toISOString().split('T')[0]);
  const [loading,  setLoading]  = useState(false);

  const selectedAsset = assets.find(a => a._id === assetId);
  const total = (parseFloat(quantity) || 0) * (parseFloat(price) || 0);
  const withFee = type === 'BUY' ? total + parseFloat(fee || '0') : total - parseFloat(fee || '0');

  useEffect(() => {
    if (open) {
      setAssetId(defaultAssetId || assets[0]?._id || '');
      setType('BUY'); setQuantity(''); setPrice(''); setFee('0'); setNote('');
      setDate(new Date().toISOString().split('T')[0]);
    }
  }, [open, defaultAssetId, assets]);

  // Pre-fill price with current price when asset is selected
  useEffect(() => {
    if (selectedAsset && !price) {
      setPrice(selectedAsset.currentPrice?.toFixed(2) || '');
    }
  }, [assetId]);

  async function handleSubmit() {
    if (!assetId || !quantity || !price) {
      toast.error('Please fill in all required fields');
      return;
    }
    setLoading(true);
    try {
      const res  = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          assetId, type,
          quantity: parseFloat(quantity),
          price: parseFloat(price),
          fee: parseFloat(fee) || 0,
          note,
          date: new Date(date).toISOString(),
        }),
      });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      toast.success(`${type} recorded for ${selectedAsset?.name}`);
      onSuccess();
      onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to record transaction');
    } finally {
      setLoading(false);
    }
  }

  if (!open) return null;

  return (
    <div
      style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.75)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.13)', borderRadius: 16, padding: '28px 32px', width: 500, maxWidth: '100%', animation: 'fadeIn 0.2s ease' }}
        onClick={e => e.stopPropagation()}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
          <div style={{ fontSize: 17, fontWeight: 600 }}>Record Transaction</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#7a7a84', display: 'flex' }}><X size={18} /></button>
        </div>

        {/* Transaction type */}
        <div style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7a7a84', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 8 }}>Type</div>
          <div style={{ display: 'flex', gap: 8 }}>
            {TX_TYPES.map(t => (
              <button
                key={t}
                onClick={() => setType(t)}
                style={{
                  flex: 1, padding: '8px 0', borderRadius: 8,
                  border: type === t ? `1px solid ${TX_COLORS[t]}` : '0.5px solid rgba(255,255,255,0.1)',
                  background: type === t ? `${TX_COLORS[t]}18` : 'none',
                  color: type === t ? TX_COLORS[t] : '#7a7a84',
                  fontFamily: "'DM Mono', monospace", fontSize: 11,
                  letterSpacing: '0.06em', cursor: 'pointer', transition: 'all 0.15s',
                }}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Asset picker */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7a7a84', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 6 }}>Asset</div>
          <select
            value={assetId}
            onChange={e => { setAssetId(e.target.value); setPrice(''); }}
            style={{ ...INPUT, appearance: 'none' }}
          >
            <option value="">Select asset…</option>
            {assets.map(a => (
              <option key={a._id} value={a._id}>
                {a.name} ({a.ticker}) — {formatCurrency(a.currentPrice ?? 0)}
              </option>
            ))}
          </select>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
          <div>
            <div style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7a7a84', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 6 }}>Quantity</div>
            <input type="number" min="0" step="any" style={INPUT} placeholder="0.00" value={quantity} onChange={e => setQuantity(e.target.value)} />
          </div>
          <div>
            <div style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7a7a84', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 6 }}>Price / Unit (USD)</div>
            <input type="number" min="0" step="any" style={INPUT} placeholder="0.00" value={price} onChange={e => setPrice(e.target.value)} />
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
          <div>
            <div style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7a7a84', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 6 }}>Fee (USD)</div>
            <input type="number" min="0" step="any" style={INPUT} placeholder="0.00" value={fee} onChange={e => setFee(e.target.value)} />
          </div>
          <div>
            <div style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7a7a84', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 6 }}>Date</div>
            <input type="date" style={INPUT} value={date} onChange={e => setDate(e.target.value)} />
          </div>
        </div>

        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7a7a84', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 6 }}>Note (optional)</div>
          <input style={INPUT} placeholder="DCA purchase, dividend reinvestment…" value={note} onChange={e => setNote(e.target.value)} />
        </div>

        {/* Total preview */}
        {total > 0 && (
          <div style={{ background: '#1f222a', borderRadius: 8, padding: '10px 14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, border: '0.5px solid rgba(255,255,255,0.07)' }}>
            <span style={{ fontSize: 12, color: '#7a7a84', fontFamily: "'DM Mono', monospace" }}>
              Total {type === 'BUY' ? '(incl. fee)' : '(after fee)'}
            </span>
            <span style={{ fontSize: 15, fontWeight: 600, fontFamily: "'DM Mono', monospace", color: TX_COLORS[type] }}>
              {type === 'SELL' || type === 'WITHDRAW' ? '−' : '+'}{formatCurrency(Math.abs(withFee), 2)}
            </span>
          </div>
        )}

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <button onClick={onClose} style={{ background: 'none', border: '0.5px solid rgba(255,255,255,0.13)', borderRadius: 8, padding: '9px 20px', color: '#7a7a84', fontFamily: "'Syne', sans-serif", fontSize: 13, cursor: 'pointer' }}>Cancel</button>
          <button
            onClick={handleSubmit} disabled={loading}
            style={{ background: loading ? 'rgba(212,149,42,0.5)' : '#d4952a', color: '#000', border: 'none', borderRadius: 8, padding: '9px 20px', fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer' }}
          >
            {loading ? 'Saving…' : 'Record'}
          </button>
        </div>
      </div>
    </div>
  );
}
