'use client';

import { useState } from 'react';
import { Asset } from '@/types';
import { formatCurrency, formatPercent, formatNumber, ASSET_META, pnlColor, pnlBgColor } from '@/lib/utils';
import { Trash2, TrendingUp, TrendingDown } from 'lucide-react';
import toast from 'react-hot-toast';

interface AssetsTableProps {
  assets: Asset[];
  onRefresh: () => void;
}

type SortKey = 'name' | 'currentValue' | 'change24h' | 'unrealizedPnLPct' | 'type';
type SortDir = 'asc' | 'desc';

export default function AssetsTable({ assets, onRefresh }: AssetsTableProps) {
  const [sortKey,  setSortKey]  = useState<SortKey>('currentValue');
  const [sortDir,  setSortDir]  = useState<SortDir>('desc');
  const [deleting, setDeleting] = useState<string | null>(null);

  function handleSort(key: SortKey) {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('desc'); }
  }

  async function handleDelete(id: string, name: string) {
    if (!confirm(`Remove ${name} from your portfolio?`)) return;
    setDeleting(id);
    try {
      const res  = await fetch(`/api/assets/${id}`, { method: 'DELETE' });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      toast.success(`${name} removed`);
      onRefresh();
    } catch (err) {
      toast.error('Failed to remove asset');
    } finally {
      setDeleting(null);
    }
  }

  const sorted = [...assets].sort((a, b) => {
    let av: number | string, bv: number | string;
    if (sortKey === 'name')              { av = a.name;               bv = b.name; }
    else if (sortKey === 'currentValue') { av = a.currentValue ?? 0;  bv = b.currentValue ?? 0; }
    else if (sortKey === 'change24h')    { av = a.change24h ?? 0;     bv = b.change24h ?? 0; }
    else if (sortKey === 'unrealizedPnLPct') { av = a.unrealizedPnLPct ?? 0; bv = b.unrealizedPnLPct ?? 0; }
    else                                 { av = a.type;               bv = b.type; }

    if (typeof av === 'string') return sortDir === 'asc' ? av.localeCompare(bv as string) : (bv as string).localeCompare(av);
    return sortDir === 'asc' ? av - (bv as number) : (bv as number) - av;
  });

  const SortIndicator = ({ k }: { k: SortKey }) => (
    <span style={{ color: sortKey === k ? '#d4952a' : '#44454d', marginLeft: 4, fontSize: 10 }}>
      {sortKey === k ? (sortDir === 'asc' ? '▲' : '▼') : '⇅'}
    </span>
  );

  const TH = ({ children, k, right }: { children: React.ReactNode; k: SortKey; right?: boolean }) => (
    <th
      onClick={() => handleSort(k)}
      style={{
        padding: '10px 12px', textAlign: right ? 'right' : 'left',
        fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7a7a84',
        letterSpacing: '0.08em', textTransform: 'uppercase', cursor: 'pointer',
        userSelect: 'none', borderBottom: '0.5px solid rgba(255,255,255,0.07)',
        whiteSpace: 'nowrap',
      }}
    >
      {children}<SortIndicator k={k} />
    </th>
  );

  if (assets.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '60px 0', color: '#44454d' }}>
        <div style={{ fontSize: 32, marginBottom: 12 }}>◈</div>
        <div style={{ fontSize: 14, fontFamily: "'DM Mono', monospace" }}>No assets yet</div>
        <div style={{ fontSize: 12, color: '#44454d', marginTop: 6 }}>Add your first asset to get started</div>
      </div>
    );
  }

  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <TH k="name">Asset</TH>
            <TH k="type">Type</TH>
            <TH k="currentValue" right>Value</TH>
            <TH k="change24h" right>24h</TH>
            <TH k="unrealizedPnLPct" right>P&L</TH>
            <th style={{ padding: '10px 12px', borderBottom: '0.5px solid rgba(255,255,255,0.07)', width: 48 }} />
          </tr>
        </thead>
        <tbody>
          {sorted.map((asset, i) => {
            const meta    = ASSET_META[asset.type];
            const pnl     = asset.unrealizedPnL    ?? 0;
            const pnlPct  = asset.unrealizedPnLPct ?? 0;
            const chg     = asset.change24h         ?? 0;
            const val     = asset.currentValue      ?? 0;

            return (
              <tr
                key={asset._id}
                style={{
                  borderBottom: i < sorted.length - 1 ? '0.5px solid rgba(255,255,255,0.05)' : 'none',
                  transition: 'background 0.15s',
                }}
                onMouseEnter={e => (e.currentTarget.style.background = '#1a1c22')}
                onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
              >
                {/* Asset */}
                <td style={{ padding: '13px 12px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{
                      width: 34, height: 34, borderRadius: 9,
                      background: meta.dimColor, color: meta.color,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 14, fontWeight: 500, flexShrink: 0,
                    }}>
                      {meta.icon}
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{asset.name}</div>
                      <div style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7a7a84', marginTop: 1 }}>
                        {formatNumber(asset.quantity, 6)} {asset.ticker}
                      </div>
                    </div>
                  </div>
                </td>

                {/* Type badge */}
                <td style={{ padding: '13px 12px' }}>
                  <span style={{
                    fontSize: 10, fontFamily: "'DM Mono', monospace",
                    padding: '3px 7px', borderRadius: 4,
                    background: meta.dimColor, color: meta.color,
                    letterSpacing: '0.06em', textTransform: 'uppercase',
                  }}>
                    {asset.type}
                  </span>
                </td>

                {/* Value */}
                <td style={{ padding: '13px 12px', textAlign: 'right' }}>
                  <div style={{ fontSize: 13, fontWeight: 500, fontFamily: "'DM Mono', monospace" }}>
                    {formatCurrency(val, 0)}
                  </div>
                  <div style={{ fontSize: 10, color: '#44454d', fontFamily: "'DM Mono', monospace", marginTop: 1 }}>
                    @ {formatCurrency(asset.currentPrice ?? 0)}
                  </div>
                </td>

                {/* 24h change */}
                <td style={{ padding: '13px 12px', textAlign: 'right' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 4 }}>
                    {chg >= 0 ? <TrendingUp size={12} color="#5aab7e" /> : <TrendingDown size={12} color="#c45c5c" />}
                    <span style={{
                      fontSize: 12, fontFamily: "'DM Mono', monospace",
                      color: chg >= 0 ? '#5aab7e' : '#c45c5c', fontWeight: 500,
                    }}>
                      {formatPercent(chg)}
                    </span>
                  </div>
                </td>

                {/* Unrealized P&L */}
                <td style={{ padding: '13px 12px', textAlign: 'right' }}>
                  <div style={{
                    display: 'inline-flex', flexDirection: 'column', alignItems: 'flex-end',
                    padding: '4px 8px', borderRadius: 6,
                    background: pnlBgColor(pnl),
                  }}>
                    <span style={{ fontSize: 12, fontFamily: "'DM Mono', monospace", fontWeight: 500, color: pnlColor(pnl) }}>
                      {pnl >= 0 ? '+' : ''}{formatCurrency(pnl, 0)}
                    </span>
                    <span style={{ fontSize: 10, fontFamily: "'DM Mono', monospace", color: pnlColor(pnl), opacity: 0.8 }}>
                      {formatPercent(pnlPct)}
                    </span>
                  </div>
                </td>

                {/* Delete */}
                <td style={{ padding: '13px 12px', textAlign: 'center' }}>
                  <button
                    onClick={() => handleDelete(asset._id, asset.name)}
                    disabled={deleting === asset._id}
                    style={{
                      background: 'none', border: 'none', cursor: 'pointer',
                      color: '#44454d', padding: 6, borderRadius: 6,
                      display: 'flex', alignItems: 'center',
                      transition: 'color 0.15s',
                      opacity: deleting === asset._id ? 0.4 : 1,
                    }}
                    onMouseEnter={e => (e.currentTarget.style.color = '#c45c5c')}
                    onMouseLeave={e => (e.currentTarget.style.color = '#44454d')}
                  >
                    <Trash2 size={14} />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
