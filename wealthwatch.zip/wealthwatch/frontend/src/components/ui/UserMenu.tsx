'use client';

import { useState, useRef, useEffect } from 'react';
import { signOut, useSession } from 'next-auth/react';
import { LogOut, Settings, Download, User, Calculator } from 'lucide-react';
import { T, mono } from '@/lib/theme';
import Link from 'next/link';

export default function UserMenu() {
  const { data: session } = useSession();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const initials = session?.user?.name
    ? session.user.name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2) : '?';

  const menuItem = (icon: React.ReactNode, label: string, action: () => void, danger = false) => (
    <button onClick={() => { action(); setOpen(false); }}
      style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 9, padding: '8px 11px', borderRadius: 7, background: 'none', border: 'none', color: danger ? T.loss : T.steel, fontFamily: "'Inter', sans-serif", fontSize: 12, cursor: 'pointer', transition: 'all 0.12s', textAlign: 'left' as const }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = T.faint; (e.currentTarget as HTMLElement).style.color = danger ? T.loss : T.platinum; }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'none'; (e.currentTarget as HTMLElement).style.color = danger ? T.loss : T.steel; }}>
      {icon}{label}
    </button>
  );

  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button onClick={() => setOpen(o => !o)}
        style={{ width: 30, height: 30, borderRadius: '50%', background: 'rgba(201,170,113,0.1)', border: `1px solid ${T.gold}40`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: T.gold, fontFamily: mono, fontSize: 11, fontWeight: 500, cursor: 'pointer', transition: 'all 0.15s' }}
        title={session?.user?.name ?? 'Profile'}>
        {session?.user?.image
          ? <img src={session.user.image} alt="" width={30} height={30} style={{ borderRadius: '50%' }} />
          : initials}
      </button>

      {open && (
        <div style={{ position: 'absolute', top: 38, right: 0, width: 210, background: T.surface2, border: `0.5px solid ${T.border2}`, borderRadius: 10, padding: '5px', zIndex: 300, animation: 'fadeIn 0.15s ease' }}>
          <div style={{ padding: '9px 11px 10px', borderBottom: `0.5px solid ${T.border}`, marginBottom: 4 }}>
            <div style={{ fontSize: 12, fontWeight: 500, color: T.platinum, marginBottom: 2 }}>{session?.user?.name}</div>
            <div style={{ fontSize: 10, color: T.steel, fontFamily: mono, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{session?.user?.email}</div>
          </div>
          {menuItem(<User size={13} />, 'Profile', () => {})}
          {menuItem(<Settings size={13} />, 'Settings', () => window.location.href = '/settings')}
          {menuItem(<Calculator size={13} />, 'SIP Calculator', () => window.location.href = '/sip')}
          {menuItem(<Download size={13} />, 'Export CSV', () => window.open('/api/export/transactions?format=csv', '_blank'))}
          <div style={{ borderTop: `0.5px solid ${T.border}`, marginTop: 4, paddingTop: 4 }}>
            {menuItem(<LogOut size={13} />, 'Sign out', () => signOut({ callbackUrl: '/auth/signin' }), true)}
          </div>
        </div>
      )}
    </div>
  );
}
