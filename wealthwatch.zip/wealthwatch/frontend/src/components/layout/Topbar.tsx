'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, BarChart3, ArrowLeftRight, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';

const NAV_ITEMS = [
  { href: '/',             label: 'Dashboard',    icon: LayoutDashboard },
  { href: '/assets',       label: 'Assets',       icon: BarChart3 },
  { href: '/transactions', label: 'Transactions', icon: ArrowLeftRight },
];

interface TopbarProps {
  onAddAsset?: () => void;
  lastRefreshed?: Date | null;
  onRefresh?: () => void;
}

export default function Topbar({ onAddAsset, lastRefreshed, onRefresh }: TopbarProps) {
  const pathname = usePathname();
  const [now, setNow] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    const tick = () =>
      setNow(new Date().toLocaleDateString('en-US', {
        weekday: 'short', month: 'short', day: 'numeric', year: 'numeric',
      }));
    tick();
    const id = setInterval(tick, 60_000);
    return () => clearInterval(id);
  }, []);

  const handleRefresh = async () => {
    if (!onRefresh) return;
    setRefreshing(true);
    await onRefresh();
    setTimeout(() => setRefreshing(false), 600);
  };

  return (
    <header
      style={{
        background: '#111316',
        borderBottom: '0.5px solid rgba(255,255,255,0.07)',
        position: 'sticky', top: 0, zIndex: 100,
      }}
    >
      <div
        style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 28px', height: '56px', maxWidth: '1400px', margin: '0 auto',
        }}
      >
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '10px', textDecoration: 'none' }}>
            <div
              style={{
                width: 30, height: 30, background: '#d4952a', borderRadius: 7,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: "'DM Mono', monospace", fontSize: 13, fontWeight: 700, color: '#000',
              }}
            >
              W
            </div>
            <span style={{ fontSize: 15, fontWeight: 600, color: '#e8e6e0', letterSpacing: '0.04em' }}>
              WealthWatch
            </span>
          </Link>

          {/* Nav links */}
          <nav style={{ display: 'flex', gap: 4 }}>
            {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
              const active = pathname === href;
              return (
                <Link
                  key={href}
                  href={href}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 6,
                    padding: '5px 12px', borderRadius: 7, textDecoration: 'none',
                    fontSize: 13, fontWeight: active ? 500 : 400,
                    color: active ? '#e8e6e0' : '#7a7a84',
                    background: active ? 'rgba(255,255,255,0.07)' : 'transparent',
                    transition: 'all 0.15s',
                  }}
                >
                  <Icon size={14} />
                  {label}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Right side */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          {/* Live indicator */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#2ab8a0', letterSpacing: '0.06em' }}>
            <span style={{
              width: 6, height: 6, borderRadius: '50%', background: '#2ab8a0',
              animation: 'pulse-dot 2s ease-in-out infinite',
            }} />
            LIVE
          </div>

          <span style={{ fontSize: 11, color: '#44454d', fontFamily: "'DM Mono', monospace" }}>{now}</span>

          {onRefresh && (
            <button
              onClick={handleRefresh}
              style={{
                background: 'none', border: '0.5px solid rgba(255,255,255,0.13)',
                borderRadius: 7, padding: '5px 8px', cursor: 'pointer',
                color: '#7a7a84', display: 'flex', alignItems: 'center',
                transition: 'all 0.15s',
              }}
              title="Refresh prices"
            >
              <RefreshCw size={13} style={{ transform: refreshing ? 'rotate(360deg)' : 'none', transition: 'transform 0.6s' }} />
            </button>
          )}

          {onAddAsset && (
            <button
              onClick={onAddAsset}
              style={{
                background: '#d4952a', color: '#000',
                border: 'none', borderRadius: 7, padding: '7px 16px',
                fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 600,
                cursor: 'pointer', letterSpacing: '0.04em',
                transition: 'opacity 0.15s',
              }}
            >
              + Add Asset
            </button>
          )}
        </div>
      </div>

      <style>{`
        @keyframes pulse-dot { 0%,100%{opacity:1} 50%{opacity:.4} }
      `}</style>
    </header>
  );
}
