'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, BarChart3, ArrowLeftRight, TrendingUp, Bell, RefreshCw, Menu, X } from 'lucide-react';
import UserMenu from '@/components/ui/UserMenu';
import { T, mono } from '@/lib/theme';

const NAV = [
  { href: '/',             label: 'Dashboard',   icon: LayoutDashboard },
  { href: '/assets',       label: 'Assets',      icon: BarChart3       },
  { href: '/transactions', label: 'History',     icon: ArrowLeftRight  },
  { href: '/analytics',    label: 'Analytics',   icon: TrendingUp      },
  { href: '/alerts',       label: 'Alerts',      icon: Bell            },
];

interface TopbarV2Props {
  onAddAsset?: () => void;
  onAddTransaction?: () => void;
  lastRefreshed?: Date | null;
  onRefresh?: () => void;
}

export default function TopbarV2({ onAddAsset, onAddTransaction, onRefresh }: TopbarV2Props) {
  const pathname = usePathname();
  const [istTime,    setIstTime]    = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const tick = () => {
      const d = new Date();
      setIstTime(d.toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: false }) + ' IST');
    };
    tick();
    const id = setInterval(tick, 30_000);
    return () => clearInterval(id);
  }, []);

  async function handleRefresh() {
    if (!onRefresh) return;
    setRefreshing(true);
    await onRefresh();
    setTimeout(() => setRefreshing(false), 600);
  }

  const barStyle: React.CSSProperties = {
    background: T.surface,
    borderBottom: `0.5px solid ${T.border}`,
    position: 'sticky', top: 0, zIndex: 100,
  };

  const linkStyle = (active: boolean): React.CSSProperties => ({
    display: 'flex', alignItems: 'center', gap: 5,
    padding: '5px 11px', borderRadius: 6, textDecoration: 'none',
    fontSize: 12, fontWeight: active ? 500 : 400,
    color: active ? T.platinum : T.steel,
    background: active ? T.faint : 'transparent',
    transition: 'all 0.15s',
  });

  return (
    <>
      <header style={barStyle}>
        {/* Market ticker bar */}
        <div style={{ borderBottom: `0.5px solid ${T.border}`, padding: '5px 24px', display: 'flex', alignItems: 'center', gap: 20, overflowX: 'auto', scrollbarWidth: 'none' }}>
          {[
            { label: 'Sensex', value: '79,486', chg: '+0.62%', pos: true },
            { label: 'Nifty 50', value: '24,131', chg: '-0.18%', pos: false },
            { label: 'Bank Nifty', value: '52,346', chg: '+0.60%', pos: true },
            { label: 'Nifty IT', value: '38,942', chg: '+1.62%', pos: true },
            { label: 'Gold MCX', value: '₹71,840', chg: '-0.29%', pos: false },
            { label: 'USD/INR', value: '83.94', chg: '+0.04%', pos: true },
            { label: 'BTC', value: '₹58,04,000', chg: '+2.14%', pos: true },
          ].map(t => (
            <div key={t.label} style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
              <span style={{ fontSize: 10, color: T.steel, fontFamily: mono }}>{t.label}</span>
              <span style={{ fontSize: 10, fontFamily: mono, fontWeight: 500, color: T.silver }}>{t.value}</span>
              <span style={{ fontSize: 9, fontFamily: mono, color: t.pos ? T.gain : T.loss }}>{t.chg}</span>
            </div>
          ))}
        </div>

        {/* Main nav */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px', height: 48, maxWidth: 1400, margin: '0 auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: 9, textDecoration: 'none', flexShrink: 0 }}>
              <div style={{ width: 26, height: 26, border: `1px solid ${T.gold}`, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: mono, fontSize: 11, fontWeight: 500, color: T.gold }}>W</div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 500, color: T.platinum, letterSpacing: '0.02em' }}>WealthWatch</div>
                <div style={{ fontSize: 9, color: T.steel, fontFamily: mono, letterSpacing: '0.06em' }}>India Portfolio</div>
              </div>
            </Link>

            <nav style={{ display: 'flex', gap: 2 }} className="desktop-nav">
              {NAV.map(({ href, label, icon: Icon }) => (
                <Link key={href} href={href} style={linkStyle(pathname === href)}>
                  <Icon size={13} />
                  {label}
                </Link>
              ))}
            </nav>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 9, fontFamily: mono, color: T.gain, letterSpacing: '0.06em' }}>
              <span className="live-dot" />
              <span className="hide-mobile">NSE LIVE</span>
            </div>
            <span style={{ fontSize: 10, color: T.iron, fontFamily: mono }} className="hide-mobile">{istTime}</span>

            {onRefresh && (
              <button onClick={handleRefresh} style={{ background: 'none', border: `0.5px solid ${T.border2}`, borderRadius: 6, padding: '5px 8px', cursor: 'pointer', color: T.steel, display: 'flex', alignItems: 'center', transition: 'all 0.15s' }}
                title="Refresh prices">
                <RefreshCw size={12} style={{ transform: refreshing ? 'rotate(360deg)' : 'none', transition: 'transform 0.5s' }} />
              </button>
            )}
            {onAddTransaction && (
              <button onClick={onAddTransaction} style={{ background: 'none', border: `0.5px solid ${T.border2}`, borderRadius: 6, padding: '6px 13px', color: T.silver, fontSize: 12, cursor: 'pointer', fontFamily: "'Inter', sans-serif", transition: 'all 0.15s' }} className="hide-mobile">
                + Trade
              </button>
            )}
            {onAddAsset && (
              <button onClick={onAddAsset} style={{ background: 'transparent', border: `0.5px solid ${T.gold}`, color: T.gold, borderRadius: 6, padding: '6px 14px', fontSize: 12, fontWeight: 500, cursor: 'pointer', fontFamily: "'Inter', sans-serif", transition: 'all 0.15s', letterSpacing: '0.02em' }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(201,170,113,0.08)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                + Asset
              </button>
            )}
            <UserMenu />
            <button onClick={() => setMobileOpen(o => !o)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: T.steel, display: 'none', alignItems: 'center' }} className="show-mobile">
              {mobileOpen ? <X size={19} /> : <Menu size={19} />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div style={{ background: T.surface, borderTop: `0.5px solid ${T.border}`, padding: '10px 18px 18px' }}>
            {NAV.map(({ href, label, icon: Icon }) => (
              <Link key={href} href={href} onClick={() => setMobileOpen(false)} style={{ ...linkStyle(pathname === href), display: 'flex', marginBottom: 4, padding: '10px 10px' }}>
                <Icon size={15} style={{ marginRight: 6 }} />{label}
              </Link>
            ))}
          </div>
        )}
      </header>

      <style>{`
        @media (max-width: 680px) {
          .desktop-nav { display: none !important; }
          .hide-mobile { display: none !important; }
          .show-mobile { display: flex !important; }
        }
        @media (min-width: 681px) { .show-mobile { display: none !important; } }
      `}</style>
    </>
  );
}
