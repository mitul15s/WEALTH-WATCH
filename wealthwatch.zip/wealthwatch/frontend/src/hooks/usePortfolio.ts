'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { Asset, PortfolioSnapshot } from '@/types';

interface UsePortfolioReturn {
  portfolio: PortfolioSnapshot | null;
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
  lastRefreshed: Date | null;
}

export function usePortfolio(refreshInterval = 60_000): UsePortfolioReturn {
  const [portfolio, setPortfolio] = useState<PortfolioSnapshot | null>(null);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState<string | null>(null);
  const [lastRefreshed, setLastRefreshed] = useState<Date | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const fetchPortfolio = useCallback(async () => {
    try {
      setError(null);
      const res  = await fetch('/api/assets');
      const json = await res.json();
      if (!json.success) throw new Error(json.message || 'Failed to load portfolio');
      setPortfolio(json.data);
      setLastRefreshed(new Date());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Network error');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPortfolio();
    intervalRef.current = setInterval(fetchPortfolio, refreshInterval);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [fetchPortfolio, refreshInterval]);

  return { portfolio, loading, error, refetch: fetchPortfolio, lastRefreshed };
}

// ─── useAsset: single asset detail ───────────────────────────────────
export function useAsset(id: string) {
  const [asset, setAsset]   = useState<Asset | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]   = useState<string | null>(null);

  const fetchAsset = useCallback(async () => {
    try {
      setError(null);
      const res  = await fetch(`/api/assets/${id}`);
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      setAsset(json.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load asset');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => { fetchAsset(); }, [fetchAsset]);

  return { asset, loading, error, refetch: fetchAsset };
}

// ─── useTransactions ─────────────────────────────────────────────────
export function useTransactions(assetId?: string, page = 1) {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [total, setTotal]               = useState(0);
  const [hasMore, setHasMore]           = useState(false);
  const [loading, setLoading]           = useState(true);
  const [error, setError]               = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams({ page: String(page), limit: '20' });
    if (assetId) params.set('assetId', assetId);

    fetch(`/api/transactions?${params}`)
      .then((r) => r.json())
      .then((json) => {
        if (!json.success) throw new Error(json.message);
        setTransactions(json.data);
        setTotal(json.total);
        setHasMore(json.hasMore);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [assetId, page]);

  return { transactions, total, hasMore, loading, error };
}
