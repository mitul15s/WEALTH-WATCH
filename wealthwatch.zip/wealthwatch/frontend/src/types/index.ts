// ─── Core Domain Types ───────────────────────────────────────────────

export type AssetType = 'crypto' | 'stocks' | 'gold' | 'cash';

export interface Asset {
  _id: string;
  userId: string;
  name: string;
  ticker: string;
  type: AssetType;
  quantity: number;
  avgBuyPrice: number;      // in INR
  currentPrice: number;     // in INR (updated by Python fetcher)
  currentValue: number;     // quantity × currentPrice
  costBasis: number;        // quantity × avgBuyPrice
  unrealizedPnL: number;
  unrealizedPnLPct: number;
  change24h: number;        // % price change in last 24h
  change24hAbs: number;     // absolute INR change in last 24h
  lastUpdated: string;
  createdAt: string;
  updatedAt: string;
}

export type TransactionType = 'BUY' | 'SELL' | 'DEPOSIT' | 'WITHDRAW' | 'TRANSFER';

export interface Transaction {
  _id: string;
  userId: string;
  assetId: string;
  assetName: string;
  assetTicker: string;
  assetType: AssetType;
  type: TransactionType;
  quantity: number;
  price: number;       // in INR
  total: number;       // in INR
  fee: number;         // in INR
  note: string;
  date: string;
  createdAt: string;
}

export interface User {
  _id: string;
  email: string;
  name: string;
  currency: string;    // 'INR'
  createdAt: string;
}

// ─── Aggregated Types ─────────────────────────────────────────────────

export interface PortfolioSnapshot {
  totalValue: number;         // INR
  totalCostBasis: number;     // INR
  totalUnrealizedPnL: number; // INR
  totalUnrealizedPnLPct: number;
  totalChange24h: number;     // INR
  totalChange24hPct: number;
  allocation: AllocationBreakdown;
  assets: Asset[];
}

export interface AllocationBreakdown {
  crypto: number;
  stocks: number;
  gold:   number;
  cash:   number;
}

export interface HistoryPoint {
  date: string;
  value: number;  // INR
}

// ─── API Wrappers ─────────────────────────────────────────────────────

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
}

export interface PaginatedResponse<T> {
  success: boolean;
  data: T[];
  total: number;
  page: number;
  limit: number;
  hasMore: boolean;
}

// ─── Form Input Types ─────────────────────────────────────────────────

export interface AddAssetInput {
  name: string;
  ticker: string;      // NSE ticker e.g. RELIANCE, or BTC, XAU
  type: AssetType;
  quantity: number;
  avgBuyPrice: number; // INR per unit
}

export interface AddTransactionInput {
  assetId: string;
  type: TransactionType;
  quantity: number;
  price: number;       // INR per unit
  fee?: number;        // INR
  note?: string;
  date?: string;
}

// ─── Chart Types ──────────────────────────────────────────────────────

export type TimeRange = '1D' | '1W' | '1M' | '3M' | '1Y' | 'ALL';

export interface ChartDataPoint {
  label: string;
  value: number;
  pnl?: number;
}
