'use client';

import { useState } from 'react';
import Topbar from '@/components/layout/Topbar';
import AssetsTable from '@/components/ui/AssetsTable';
import AddAssetModal from '@/components/ui/AddAssetModal';
import { usePortfolio } from '@/hooks/usePortfolio';
import { AssetType } from '@/types';
import { ASSET_META, formatCurrency } from '@/lib/utils';

const FILTER_TYPES: Array<AssetType | 'all'> = ['all', 'crypto', 'stocks', 'gold', 'cash'];

export default function AssetsPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [filter, setFilter] = useState<AssetType | 'all'>('all');
  const { portfolio, loading, refetch, lastRefreshed } = usePortfolio();

  const assets = (portfolio?.assets ?? []).filter(a => filter === 'all' || a.type === filter);

  return (
    <>
      <Topbar
        onAddAsset={() => setModalOpen(true)}
        lastRefreshed={lastRefreshed}
        onRefresh={refetch}
      />

      <div style={{ maxWidth: 1400, margin: '0 auto', padding: '24px 28px' }}>

        {/* Page header */}
        <div style={{ marginBottom: 24 }}>
          <h1 style={{ fontSize: 26, fontWeight: 700, marginBottom: 4 }}>Assets</h1>
          <p style={{ fontSize: 13, color: '#7a7a84', fontFamily: "'DM Mono', monospace" }}>
            {portfolio?.assets.length ?? 0} positions · {formatCurrency(portfolio?.portfolio.totalValue ?? 0, 0)} total
          </p>
        </div>

        {/* Filter pills */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
          {FILTER_TYPES.map(f => {
            const meta   = f !== 'all' ? ASSET_META[f] : null;
            const active = filter === f;
            return (
              <button
                key={f}
                onClick={() => setFilter(f)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  padding: '6px 14px', borderRadius: 8,
                  border: active
                    ? `1px solid ${meta?.color ?? '#d4952a'}`
                    : '0.5px solid rgba(255,255,255,0.1)',
                  background: active ? (meta?.dimColor ?? 'rgba(212,149,42,0.1)') : 'none',
                  color: active ? (meta?.color ?? '#d4952a') : '#7a7a84',
                  fontFamily: "'DM Mono', monospace", fontSize: 11,
                  letterSpacing: '0.06em', textTransform: 'uppercase',
                  cursor: 'pointer', transition: 'all 0.15s',
                }}
              >
                {meta && <span>{meta.icon}</span>}
                {f}
              </button>
            );
          })}
        </div>

        {/* Assets table */}
        <div style={{
          background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)',
          borderRadius: 12, padding: '6px 0',
        }}>
          {loading ? (
            <div style={{ padding: '32px', textAlign: 'center', color: '#44454d', fontFamily: "'DM Mono', monospace", fontSize: 12 }}>
              Loading assets…
            </div>
          ) : (
            <AssetsTable assets={assets} onRefresh={refetch} />
          )}
        </div>
      </div>

      <AddAssetModal open={modalOpen} onClose={() => setModalOpen(false)} onSuccess={refetch} />
    </>
  );
}
