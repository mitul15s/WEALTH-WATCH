'use client';

import { useState, useEffect, useMemo } from 'react';
import { useParams, useRouter } from 'next/navigation';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ReferenceLine,
} from 'recharts';
import TopbarV2 from '@/components/layout/TopbarV2';
import AddTransactionModal from '@/components/ui/AddTransactionModal';
import TransactionList from '@/components/ui/TransactionList';
import { useAsset, useTransactions } from '@/hooks/usePortfolio';
import { ASSET_META, formatCurrency, formatPercent, formatNumber, pnlColor, pnlBgColor } from '@/lib/utils';
import { TrendingUp, TrendingDown, Bell, BellOff, ArrowLeft, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';

// Generate simulated price history for the asset
function generateAssetHistory(currentPrice: number, change24h: number, days = 30) {
  const points = days;
  const vals: number[] = [currentPrice];
  for (let i = 1; i < points; i++) {
    const noise = (Math.random() - 0.49) * 0.022 * currentPrice;
    const drift = -change24h * 0.01 * currentPrice / points;
    vals.unshift(Math.max(0.01, vals[0] + noise + drift));
  }
  const now = new Date();
  return vals.map((v, i) => ({
    label: new Date(now.getTime() - (points - 1 - i) * 86_400_000)
      .toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    price: +v.toFixed(4),
  }));
}

const STAT = ({ label, value, sub, color }: { label: string; value: string; sub?: string; color?: string }) => (
  <div style={{ background: '#1f222a', borderRadius: 10, padding: '14px 18px', minWidth: 0 }}>
    <div style={{ fontSize: 11, fontFamily: "'DM Mono',monospace", color: '#7a7a84', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 6 }}>{label}</div>
    <div style={{ fontSize: 20, fontWeight: 700, fontFamily: "'DM Mono',monospace", color: color || '#e8e6e0' }}>{value}</div>
    {sub && <div style={{ fontSize: 11, fontFamily: "'DM Mono',monospace", color: '#44454d', marginTop: 2 }}>{sub}</div>}
  </div>
);

export default function AssetDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id     = params?.id as string;

  const { asset, loading, error, refetch } = useAsset(id);
  const { transactions, loading: txLoading } = useTransactions(id, 1);

  const [txModal,    setTxModal]    = useState(false);
  const [alertPrice, setAlertPrice] = useState('');
  const [alertCond,  setAlertCond]  = useState<'above' | 'below'>('above');
  const [alerts,     setAlerts]     = useState<any[]>([]);
  const [deleting,   setDeleting]   = useState(false);
  const [range,      setRange]      = useState(30);

  const history = useMemo(() =>
    asset ? generateAssetHistory(asset.currentPrice ?? 0, asset.change24h ?? 0, range) : [],
    [asset, range]
  );

  // Load existing alerts for this asset
  useEffect(() => {
    if (!id) return;
    fetch('/api/alerts?status=active')
      .then(r => r.json())
      .then(j => {
        if (j.success) setAlerts(j.data.filter((a: any) => a.assetId === id));
      });
  }, [id]);

  async function addAlert() {
    const val = parseFloat(alertPrice);
    if (isNaN(val) || val <= 0) { toast.error('Enter a valid price target'); return; }
    try {
      const res  = await fetch('/api/alerts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ assetId: id, condition: alertCond, targetValue: val }),
      });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      setAlerts(prev => [...prev, json.data]);
      setAlertPrice('');
      toast.success(`Alert set: ${alertCond} ${formatCurrency(val)}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to set alert');
    }
  }

  async function deleteAlert(alertId: string) {
    await fetch(`/api/alerts?id=${alertId}`, { method: 'DELETE' });
    setAlerts(prev => prev.filter(a => a._id !== alertId));
    toast.success('Alert removed');
  }

  async function deleteAsset() {
    if (!confirm(`Remove ${asset?.name} from your portfolio? This cannot be undone.`)) return;
    setDeleting(true);
    try {
      const res  = await fetch(`/api/assets/${id}`, { method: 'DELETE' });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);
      toast.success(`${asset?.name} removed`);
      router.replace('/assets');
    } catch {
      toast.error('Failed to remove asset');
      setDeleting(false);
    }
  }

  if (loading) return (
    <>
      <TopbarV2 />
      <div style={{ maxWidth: 1100, margin: '40px auto', padding: '0 28px', color: '#44454d', fontFamily: "'DM Mono',monospace", fontSize: 13 }}>
        Loading asset…
      </div>
    </>
  );

  if (error || !asset) return (
    <>
      <TopbarV2 />
      <div style={{ maxWidth: 1100, margin: '40px auto', padding: '0 28px', color: '#c45c5c', fontFamily: "'DM Mono',monospace", fontSize: 13 }}>
        {error || 'Asset not found'}
      </div>
    </>
  );

  const meta    = ASSET_META[asset.type];
  const pnl     = asset.unrealizedPnL    ?? 0;
  const pnlPct  = asset.unrealizedPnLPct ?? 0;
  const chg     = asset.change24h         ?? 0;
  const val     = asset.currentValue      ?? 0;
  const isPos   = chg >= 0;
  const lineColor = isPos ? '#d4952a' : '#c45c5c';
  const firstPrice = history[0]?.price ?? asset.currentPrice;
  const priceChgAbs = (asset.currentPrice ?? 0) - firstPrice;
  const priceChgPct = firstPrice > 0 ? (priceChgAbs / firstPrice) * 100 : 0;

  return (
    <>
      <TopbarV2
        onAddTransaction={() => setTxModal(true)}
        onRefresh={refetch}
      />

      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '24px 28px' }}>

        {/* Back + header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
          <button
            onClick={() => router.back()}
            style={{ background: 'none', border: '0.5px solid rgba(255,255,255,0.1)', borderRadius: 8, padding: '6px 10px', cursor: 'pointer', color: '#7a7a84', display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, fontFamily: "'DM Mono',monospace" }}
          >
            <ArrowLeft size={13} /> Back
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12, flex: 1 }}>
            <div style={{ width: 44, height: 44, borderRadius: 11, background: meta.dimColor, color: meta.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 500 }}>
              {meta.icon}
            </div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 700 }}>{asset.name}</div>
              <div style={{ fontSize: 12, fontFamily: "'DM Mono',monospace", color: '#7a7a84' }}>
                {asset.ticker} · <span style={{ color: meta.color, textTransform: 'uppercase', fontSize: 10 }}>{asset.type}</span>
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 8 }}>
            <button
              onClick={() => setTxModal(true)}
              style={{ background: '#d4952a', color: '#000', border: 'none', borderRadius: 8, padding: '8px 16px', fontFamily: "'Syne',sans-serif", fontSize: 13, fontWeight: 600, cursor: 'pointer' }}
            >
              + Transaction
            </button>
            <button
              onClick={deleteAsset}
              disabled={deleting}
              style={{ background: 'none', border: '0.5px solid rgba(196,92,92,0.3)', borderRadius: 8, padding: '8px 12px', cursor: 'pointer', color: '#c45c5c', display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, fontFamily: "'Syne',sans-serif" }}
            >
              <Trash2 size={13} /> Remove
            </button>
          </div>
        </div>

        {/* Current price hero */}
        <div style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 14, padding: '24px 28px', marginBottom: 16, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 20 }}>
          <div>
            <div style={{ fontSize: 11, fontFamily: "'DM Mono',monospace", color: '#7a7a84', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 6 }}>Current Price</div>
            <div style={{ fontSize: 44, fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1 }}>
              {formatCurrency(asset.currentPrice ?? 0, (asset.currentPrice ?? 0) < 1 ? 6 : 2)}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '3px 9px', borderRadius: 5, fontSize: 12, fontFamily: "'DM Mono',monospace", background: isPos ? 'rgba(90,171,126,0.1)' : 'rgba(196,92,92,0.1)', color: isPos ? '#5aab7e' : '#c45c5c' }}>
                {isPos ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                {isPos ? '+' : ''}{formatPercent(chg)} (24h)
              </span>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12, minWidth: 280 }}>
            <STAT label="Holdings" value={formatNumber(asset.quantity, 6)} sub={`${asset.ticker}`} />
            <STAT label="Position Value" value={formatCurrency(val, 0)} />
            <STAT
              label="Unrealized P&L"
              value={(pnl >= 0 ? '+' : '') + formatCurrency(pnl, 0)}
              sub={formatPercent(pnlPct)}
              color={pnlColor(pnl)}
            />
            <STAT label="Avg Buy Price" value={formatCurrency(asset.avgBuyPrice ?? 0, (asset.avgBuyPrice ?? 0) < 1 ? 4 : 2)} />
          </div>
        </div>

        {/* Price chart */}
        <div style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '22px 24px', marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: '0.04em' }}>Price History</div>
              <div style={{ fontSize: 11, fontFamily: "'DM Mono',monospace", marginTop: 4 }}>
                <span style={{ color: priceChgAbs >= 0 ? '#5aab7e' : '#c45c5c' }}>
                  {priceChgAbs >= 0 ? '+' : ''}{formatCurrency(priceChgAbs, 2)} ({formatPercent(priceChgPct)})
                </span>
                <span style={{ color: '#44454d', marginLeft: 6 }}>over {range}d</span>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 0 }}>
              {[7, 14, 30, 90].map((d, i, arr) => (
                <button key={d} onClick={() => setRange(d)} style={{ padding: '4px 10px', background: range === d ? '#1f222a' : 'none', border: '0.5px solid rgba(255,255,255,0.07)', borderLeft: i > 0 ? 'none' : undefined, borderRadius: i === 0 ? '6px 0 0 6px' : i === arr.length - 1 ? '0 6px 6px 0' : 0, color: range === d ? '#e8e6e0' : '#7a7a84', fontFamily: "'DM Mono',monospace", fontSize: 11, cursor: 'pointer' }}>
                  {d}D
                </button>
              ))}
            </div>
          </div>

          <div style={{ height: 200 }}>
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={history} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="assetGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%"   stopColor={lineColor} stopOpacity={0.2} />
                    <stop offset="100%" stopColor={lineColor} stopOpacity={0.01} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
                <XAxis dataKey="label" tick={{ fill: '#44454d', fontSize: 10, fontFamily: "'DM Mono',monospace" }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
                <YAxis
                  tick={{ fill: '#44454d', fontSize: 10, fontFamily: "'DM Mono',monospace" }}
                  tickLine={false} axisLine={false} width={60}
                  tickFormatter={v => formatCurrency(v, (asset.currentPrice ?? 0) < 10 ? 2 : 0)}
                />
                <Tooltip
                  content={({ active, payload, label }) => {
                    if (!active || !payload?.length) return null;
                    return (
                      <div style={{ background: '#1f222a', border: '0.5px solid rgba(255,255,255,0.13)', borderRadius: 9, padding: '10px 14px', fontFamily: "'DM Mono',monospace" }}>
                        <div style={{ fontSize: 11, color: '#7a7a84', marginBottom: 4 }}>{label}</div>
                        <div style={{ fontSize: 14, fontWeight: 500 }}>{formatCurrency(payload[0].value as number, 4)}</div>
                      </div>
                    );
                  }}
                  cursor={{ stroke: 'rgba(255,255,255,0.08)', strokeWidth: 1 }}
                />
                {/* Avg buy price reference line */}
                <ReferenceLine
                  y={asset.avgBuyPrice}
                  stroke="rgba(255,255,255,0.18)"
                  strokeDasharray="5 5"
                  label={{ value: 'avg buy', position: 'insideBottomRight', fontSize: 9, fill: '#44454d', fontFamily: "'DM Mono',monospace" }}
                />
                <Area type="monotone" dataKey="price" stroke={lineColor} strokeWidth={1.5} fill="url(#assetGrad)" dot={false} activeDot={{ r: 4, fill: lineColor, strokeWidth: 0 }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bottom grid: transactions + alerts */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16 }}>

          {/* Transaction history */}
          <div style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '22px 24px' }}>
            <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: '0.04em', marginBottom: 16 }}>Transaction History</div>
            <TransactionList transactions={transactions} loading={txLoading} />
          </div>

          {/* Price alerts */}
          <div style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '22px 24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <Bell size={14} color="#d4952a" />
              <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: '0.04em' }}>Price Alerts</div>
            </div>

            {/* Add alert form */}
            <div style={{ marginBottom: 20 }}>
              <div style={{ display: 'flex', gap: 0, marginBottom: 10 }}>
                {(['above', 'below'] as const).map((c, i) => (
                  <button key={c} onClick={() => setAlertCond(c)} style={{ flex: 1, padding: '7px 0', background: alertCond === c ? '#1f222a' : 'none', border: '0.5px solid rgba(255,255,255,0.1)', borderLeft: i > 0 ? 'none' : undefined, borderRadius: i === 0 ? '7px 0 0 7px' : '0 7px 7px 0', color: alertCond === c ? '#d4952a' : '#7a7a84', fontFamily: "'DM Mono',monospace", fontSize: 11, letterSpacing: '0.06em', cursor: 'pointer', transition: 'all 0.15s' }}>
                    {c.toUpperCase()}
                  </button>
                ))}
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input
                  type="number" min="0" step="any"
                  placeholder={`Target price (current: ${formatCurrency(asset.currentPrice ?? 0, 2)})`}
                  value={alertPrice}
                  onChange={e => setAlertPrice(e.target.value)}
                  style={{ flex: 1, background: '#1f222a', border: '0.5px solid rgba(255,255,255,0.13)', borderRadius: 8, padding: '9px 12px', color: '#e8e6e0', fontFamily: "'DM Mono',monospace", fontSize: 12, outline: 'none' }}
                  onKeyDown={e => e.key === 'Enter' && addAlert()}
                />
                <button onClick={addAlert} style={{ background: '#d4952a', color: '#000', border: 'none', borderRadius: 8, padding: '9px 14px', fontFamily: "'Syne',sans-serif", fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
                  Set
                </button>
              </div>
            </div>

            {/* Existing alerts */}
            <div>
              {alerts.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '20px 0', color: '#44454d', fontSize: 12, fontFamily: "'DM Mono',monospace" }}>
                  No active alerts
                </div>
              ) : (
                alerts.map(alert => (
                  <div key={alert._id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 10px', borderRadius: 8, background: '#1f222a', marginBottom: 6 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <Bell size={12} color={alert.condition === 'above' ? '#5aab7e' : '#c45c5c'} />
                      <div>
                        <div style={{ fontSize: 12, fontFamily: "'DM Mono',monospace", fontWeight: 500 }}>
                          {alert.condition === 'above' ? '≥' : '≤'} {formatCurrency(alert.targetValue, 2)}
                        </div>
                        <div style={{ fontSize: 10, color: '#7a7a84', fontFamily: "'DM Mono',monospace" }}>
                          {alert.condition}
                        </div>
                      </div>
                    </div>
                    <button onClick={() => deleteAlert(alert._id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#44454d', display: 'flex', alignItems: 'center', padding: 4, borderRadius: 5, transition: 'color 0.12s' }}
                      onMouseEnter={e => (e.currentTarget.style.color = '#c45c5c')}
                      onMouseLeave={e => (e.currentTarget.style.color = '#44454d')}
                    >
                      <BellOff size={13} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      <AddTransactionModal
        open={txModal}
        onClose={() => setTxModal(false)}
        onSuccess={() => { refetch(); setTxModal(false); }}
        assets={asset ? [asset as any] : []}
        defaultAssetId={id}
      />
    </>
  );
}
