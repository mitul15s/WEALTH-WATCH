import type { Metadata } from 'next';
import { Inter, JetBrains_Mono } from 'next/font/google';
import { Toaster } from 'react-hot-toast';
import SessionWrapper from '@/components/layout/SessionWrapper';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  weight: ['300', '400', '500'],
  variable: '--font-inter',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'WealthWatch — India Portfolio',
  description: 'Track NSE/BSE stocks, crypto, gold & cash in INR.',
  icons: { icon: '/favicon.ico' },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${jetbrainsMono.variable}`}>
      <body style={{ fontFamily: "'Inter', system-ui, sans-serif" }}>
        <SessionWrapper>{children}</SessionWrapper>
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: '#1c1d23',
              color: '#d4d8e0',
              border: '0.5px solid rgba(255,255,255,0.11)',
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: '12px',
              borderRadius: '8px',
            },
            success: { iconTheme: { primary: '#6dbf8a', secondary: '#0e0f11' } },
            error:   { iconTheme: { primary: '#d97070', secondary: '#0e0f11' } },
          }}
        />
      </body>
    </html>
  );
}
