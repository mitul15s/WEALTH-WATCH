'use client';

import { useState } from 'react';
import Topbar from '@/components/layout/Topbar';
import TransactionList from '@/components/ui/TransactionList';
import AddAssetModal from '@/components/ui/AddAssetModal';
import { useTransactions, usePortfolio } from '@/hooks/usePortfolio';
import { TransactionType } from '@/types';

const TX_FILTERS: Array<TransactionType | 'all'> = ['all', 'BUY', 'SELL', 'DEPOSIT', 'WITHDRAW'];

const TX_STYLE: Record<string, { color: string; bg: string }> = {
  BUY:      { color: '#5aab7e', bg: 'rgba(90,171,126,0.1)' },
  SELL:     { color: '#c45c5c', bg: 'rgba(196,92,92,0.1)'  },
  DEPOSIT:  { color: '#5a8fc2', bg: 'rgba(90,143,194,0.1)' },
  WITHDRAW: { color: '#c2a85a', bg: 'rgba(194,168,90,0.1)' },
};

export default function TransactionsPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [typeFilter, setTypeFilter] = useState<TransactionType | 'all'>('all');
  const [page, setPage] = useState(1);

  const { refetch: refetchPortfolio } = usePortfolio();
  const { transactions, total, hasMore, loading } = useTransactions(
    undefined,
    page
  );

  const filtered = typeFilter === 'all'
    ? transactions
    : transactions.filter(t => t.type === typeFilter);

  return (
    <>
      <Topbar onAddAsset={() => setModalOpen(true)} onRefresh={refetchPortfolio} />

      <div style={{ maxWidth: 1400, margin: '0 auto', padding: '24px 28px' }}>

        {/* Page header */}
        <div style={{ marginBottom: 24 }}>
          <h1 style={{ fontSize: 26, fontWeight: 700, marginBottom: 4 }}>Transactions</h1>
          <p style={{ fontSize: 13, color: '#7a7a84', fontFamily: "'DM Mono', monospace" }}>
            {total} total transactions
          </p>
        </div>

        {/* Filter row */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
          {TX_FILTERS.map(f => {
            const s      = f !== 'all' ? TX_STYLE[f] : null;
            const active = typeFilter === f;
            return (
              <button
                key={f}
                onClick={() => { setTypeFilter(f); setPage(1); }}
                style={{
                  padding: '5px 12px', borderRadius: 7,
                  border: active
                    ? `1px solid ${s?.color ?? '#d4952a'}`
                    : '0.5px solid rgba(255,255,255,0.1)',
                  background: active ? (s?.bg ?? 'rgba(212,149,42,0.1)') : 'none',
                  color: active ? (s?.color ?? '#d4952a') : '#7a7a84',
                  fontFamily: "'DM Mono', monospace", fontSize: 11,
                  letterSpacing: '0.06em', textTransform: 'uppercase',
                  cursor: 'pointer', transition: 'all 0.15s',
                }}
              >
                {f}
              </button>
            );
          })}
        </div>

        {/* Table panel */}
        <div style={{
          background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)',
          borderRadius: 12, padding: '6px 18px',
        }}>
          <TransactionList transactions={filtered} loading={loading} />
        </div>

        {/* Pagination */}
        {(hasMore || page > 1) && (
          <div style={{ display: 'flex', justifyContent: 'center', gap: 12, marginTop: 20 }}>
            <button
              disabled={page <= 1}
              onClick={() => setPage(p => p - 1)}
              style={{
                padding: '7px 18px', borderRadius: 8,
                border: '0.5px solid rgba(255,255,255,0.13)',
                background: 'none', color: page <= 1 ? '#44454d' : '#e8e6e0',
                fontFamily: "'DM Mono', monospace", fontSize: 12, cursor: page <= 1 ? 'not-allowed' : 'pointer',
              }}
            >
              ← Prev
            </button>
            <span style={{ padding: '7px 0', fontSize: 12, color: '#7a7a84', fontFamily: "'DM Mono', monospace" }}>
              Page {page}
            </span>
            <button
              disabled={!hasMore}
              onClick={() => setPage(p => p + 1)}
              style={{
                padding: '7px 18px', borderRadius: 8,
                border: '0.5px solid rgba(255,255,255,0.13)',
                background: 'none', color: !hasMore ? '#44454d' : '#e8e6e0',
                fontFamily: "'DM Mono', monospace", fontSize: 12, cursor: !hasMore ? 'not-allowed' : 'pointer',
              }}
            >
              Next →
            </button>
          </div>
        )}
      </div>

      <AddAssetModal open={modalOpen} onClose={() => setModalOpen(false)} onSuccess={refetchPortfolio} />
    </>
  );
}
