'use client';

import { useState, useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import TopbarV2 from '@/components/layout/TopbarV2';
import { formatCompact } from '@/lib/utils';
import { T, mono, card } from '@/lib/theme';

function Slider({ label, value, min, max, step, onChange, format }: {
  label: string; value: number; min: number; max: number;
  step: number; onChange: (v: number) => void; format: (v: number) => string;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 7 }}>
        <span style={{ fontSize: 11, color: T.steel, fontFamily: mono }}>{label}</span>
        <span style={{ fontSize: 12, fontWeight: 500, color: T.gold, fontFamily: mono }}>{format(value)}</span>
      </div>
      <div style={{ position: 'relative', height: 4, background: T.faint, borderRadius: 2 }}>
        <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', width: `${pct}%`, background: T.gold, borderRadius: 2 }} />
        <input type="range" min={min} max={max} step={step} value={value}
          onChange={e => onChange(Number(e.target.value))}
          style={{ position: 'absolute', inset: '-7px 0', opacity: 0, cursor: 'pointer', width: '100%' }} />
      </div>
    </div>
  );
}

function StatBox({ label, value, sub, color = T.platinum }: { label: string; value: string; sub?: string; color?: string }) {
  return (
    <div style={{ background: T.faint, borderRadius: 8, padding: '13px 15px' }}>
      <div style={{ fontSize: 10, fontFamily: mono, color: T.steel, letterSpacing: '0.07em', textTransform: 'uppercase' as const, marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 20, fontWeight: 400, fontFamily: mono, color }}>{value}</div>
      {sub && <div style={{ fontSize: 10, fontFamily: mono, color: T.iron, marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

function fmtINR(v: number) {
  if (v >= 1e7) return `${(v/1e7).toFixed(2)} Cr`;
  if (v >= 1e5) return `${(v/1e5).toFixed(2)} L`;
  return `${Math.round(v).toLocaleString('en-IN')}`;
}
function fmtINRFull(v: number) { return `₹${fmtINR(v)}`; }

const PRESETS = [
  { label: 'Starter',    monthly: 5_000,  rate: 10, years: 10 },
  { label: 'Balanced',   monthly: 10_000, rate: 12, years: 15 },
  { label: 'Aggressive', monthly: 25_000, rate: 15, years: 20 },
  { label: 'Retirement', monthly: 50_000, rate: 12, years: 30 },
];

const FUNDS = [
  { name: 'Mirae Asset Large Cap',    rate: 14.2, cat: 'Large Cap'  },
  { name: 'Axis Bluechip Fund',       rate: 13.8, cat: 'Large Cap'  },
  { name: 'HDFC Mid-Cap Opportunities',rate:16.4, cat: 'Mid Cap'    },
  { name: 'SBI Small Cap Fund',       rate: 18.2, cat: 'Small Cap'  },
  { name: 'Navi Nifty 50 Index',      rate: 12.1, cat: 'Index Fund' },
  { name: 'Parag Parikh Flexi Cap',   rate: 17.1, cat: 'Flexi Cap'  },
];

function ChartTip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: T.surface2, border: `0.5px solid ${T.border2}`, borderRadius: 7, padding: '9px 13px', fontFamily: mono }}>
      <div style={{ fontSize: 10, color: T.steel, marginBottom: 5 }}>Year {label}</div>
      {payload.map((p: any) => (
        <div key={p.name} style={{ fontSize: 11, color: p.color || p.fill, marginBottom: 2 }}>{p.name}: ₹{fmtINR(p.value)}</div>
      ))}
    </div>
  );
}

export default function SIPCalculatorPage() {
  const [monthly,   setMonthly]   = useState(10_000);
  const [rate,      setRate]      = useState(12);
  const [years,     setYears]     = useState(15);
  const [stepUp,    setStepUp]    = useState(0);
  const [inflation, setInflation] = useState(6);

  const results = useMemo(() => {
    const data: { year: number; invested: number; corpus: number; gains: number }[] = [];
    let corpus = 0, invested = 0, monthlyAmt = monthly;
    const mr = rate / 100 / 12;
    for (let y = 1; y <= years; y++) {
      for (let m = 0; m < 12; m++) { corpus = (corpus + monthlyAmt) * (1 + mr); invested += monthlyAmt; }
      data.push({ year: y, invested: Math.round(invested), corpus: Math.round(corpus), gains: Math.round(corpus - invested) });
      if (stepUp > 0) monthlyAmt *= (1 + stepUp / 100);
    }
    return data;
  }, [monthly, rate, years, stepUp]);

  const fin      = results[results.length - 1] ?? { corpus: 0, invested: 0, gains: 0 };
  const wMult    = fin.invested > 0 ? fin.corpus / fin.invested : 0;
  const realVal  = fin.corpus / Math.pow(1 + inflation / 100, years);
  const milestones = results.filter((_, i) => (i + 1) % Math.ceil(years / 7) === 0 || i === results.length - 1);

  return (
    <>
      <TopbarV2 />
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '20px 24px' }}>

        <div style={{ marginBottom: 20 }}>
          <h1 style={{ fontSize: 22, fontWeight: 400, color: T.platinum, marginBottom: 4 }}>SIP Calculator</h1>
          <p style={{ fontSize: 12, color: T.steel, fontFamily: mono }}>
            Project corpus growth for your systematic investment plan
          </p>
        </div>

        {/* Presets */}
        <div style={{ display: 'flex', gap: 7, marginBottom: 20, flexWrap: 'wrap' as const }}>
          {PRESETS.map(p => (
            <button key={p.label} onClick={() => { setMonthly(p.monthly); setRate(p.rate); setYears(p.years); }}
              style={{ padding: '5px 13px', borderRadius: 6, border: `0.5px solid ${T.border2}`, background: 'none', color: T.silver, fontFamily: mono, fontSize: 11, cursor: 'pointer', transition: 'all 0.15s', letterSpacing: '0.03em' }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = T.gold; (e.currentTarget as HTMLElement).style.color = T.gold; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = T.border2; (e.currentTarget as HTMLElement).style.color = T.silver; }}>
              {p.label}
            </button>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: 14 }}>

          {/* Controls panel */}
          <div>
            <div style={{ ...card, marginBottom: 12 }}>
              <div style={{ fontSize: 12, fontWeight: 500, color: T.silver, marginBottom: 18 }}>Parameters</div>
              <Slider label="Monthly SIP (₹)" value={monthly} min={500} max={200_000} step={500} onChange={setMonthly} format={v => `₹${v.toLocaleString('en-IN')}`} />
              <Slider label="Annual return (%)" value={rate} min={4} max={30} step={0.5} onChange={setRate} format={v => `${v.toFixed(1)}%`} />
              <Slider label="Tenure (years)" value={years} min={1} max={40} step={1} onChange={setYears} format={v => `${v} yr`} />
              <Slider label="Annual step-up (%)" value={stepUp} min={0} max={30} step={1} onChange={setStepUp} format={v => `${v}%`} />
              <Slider label="Inflation (%)" value={inflation} min={2} max={12} step={0.5} onChange={setInflation} format={v => `${v.toFixed(1)}%`} />
            </div>

            <div style={card}>
              <div style={{ fontSize: 12, fontWeight: 500, color: T.silver, marginBottom: 13 }}>Fund benchmarks</div>
              <div style={{ fontSize: 9, color: T.steel, fontFamily: mono, marginBottom: 10 }}>Click to apply return rate</div>
              {FUNDS.map((f, i) => (
                <div key={f.name} onClick={() => setRate(f.rate)}
                  style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 6px', borderBottom: i < FUNDS.length - 1 ? `0.5px solid ${T.border}` : 'none', cursor: 'pointer', borderRadius: 5, transition: 'background 0.12s' }}
                  onMouseEnter={e => (e.currentTarget.style.background = T.faint)}
                  onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 500, color: T.platinum }}>{f.name}</div>
                    <div style={{ fontSize: 9, fontFamily: mono, color: T.steel, marginTop: 1 }}>{f.cat}</div>
                  </div>
                  <span style={{ fontSize: 12, fontFamily: mono, color: T.gold, fontWeight: 500 }}>{f.rate}%</span>
                </div>
              ))}
              <div style={{ fontSize: 9, color: T.iron, fontFamily: mono, marginTop: 10, lineHeight: 1.5 }}>
                Past performance does not guarantee future results. Consult a SEBI-registered advisor.
              </div>
            </div>
          </div>

          {/* Results */}
          <div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, marginBottom: 10 }}>
              <StatBox label="Final corpus" value={fmtINRFull(fin.corpus)} sub={`after ${years} years`} color={T.gold} />
              <StatBox label="Total invested" value={fmtINRFull(fin.invested)} sub={`₹${monthly.toLocaleString('en-IN')}/mo`} />
              <StatBox label="Total gains" value={fmtINRFull(fin.gains)} sub={`${((wMult - 1)*100).toFixed(0)}% growth`} color={T.gain} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, marginBottom: 13 }}>
              <StatBox label="Wealth multiplier" value={`${wMult.toFixed(1)}x`} color={T.silver} />
              <StatBox label="Inflation-adj. value" value={fmtINRFull(realVal)} sub={`at ${inflation}% inflation`} />
              <StatBox label="XIRR (est.)" value={`${rate}% p.a.`} color={T.copper} />
            </div>

            {/* Growth chart */}
            <div style={{ ...card, marginBottom: 12 }}>
              <div style={{ fontSize: 12, fontWeight: 500, color: T.silver, marginBottom: 14 }}>Corpus growth</div>
              <div style={{ height: 210 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={results} margin={{ top: 4, right: 2, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="cg1" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={T.gold} stopOpacity={0.18} />
                        <stop offset="100%" stopColor={T.gold} stopOpacity={0.01} />
                      </linearGradient>
                      <linearGradient id="cg2" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={T.silver} stopOpacity={0.1} />
                        <stop offset="100%" stopColor={T.silver} stopOpacity={0.01} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" vertical={false} />
                    <XAxis dataKey="year" tick={{ fill: T.iron, fontSize: 9, fontFamily: mono }} tickLine={false} axisLine={false} tickFormatter={v => `Y${v}`} interval={Math.floor(years / 6)} />
                    <YAxis tick={{ fill: T.iron, fontSize: 9, fontFamily: mono }} tickLine={false} axisLine={false} tickFormatter={v => `₹${fmtINR(v)}`} width={58} />
                    <Tooltip content={<ChartTip />} cursor={{ stroke: 'rgba(255,255,255,0.05)', strokeWidth: 1 }} />
                    <Area type="monotone" dataKey="invested" name="Invested" stroke={T.iron} strokeWidth={1} fill="url(#cg2)" dot={false} />
                    <Area type="monotone" dataKey="corpus" name="Corpus" stroke={T.gold} strokeWidth={1.3} fill="url(#cg1)" dot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Milestone bar chart */}
            <div style={card}>
              <div style={{ fontSize: 12, fontWeight: 500, color: T.silver, marginBottom: 14 }}>Invested vs gains at milestones</div>
              <div style={{ height: 160 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={milestones} margin={{ top: 4, right: 2, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" vertical={false} />
                    <XAxis dataKey="year" tick={{ fill: T.iron, fontSize: 9, fontFamily: mono }} tickLine={false} axisLine={false} tickFormatter={v => `Y${v}`} />
                    <YAxis tick={{ fill: T.iron, fontSize: 9, fontFamily: mono }} tickLine={false} axisLine={false} tickFormatter={v => `₹${fmtINR(v)}`} width={58} />
                    <Tooltip content={<ChartTip />} cursor={{ fill: 'rgba(255,255,255,0.02)' }} />
                    <Bar dataKey="invested" name="Invested" stackId="a" fill={T.iron}  radius={[0,0,0,0]} />
                    <Bar dataKey="gains"    name="Gains"    stackId="a" fill={T.gold}  radius={[3,3,0,0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div style={{ display: 'flex', gap: 14, marginTop: 10 }}>
                {[{ c: T.gold, l: 'Gains' }, { c: T.iron, l: 'Invested' }].map(x => (
                  <span key={x.l} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 10, fontFamily: mono, color: T.steel }}>
                    <span style={{ width: 8, height: 8, borderRadius: 2, background: x.c, display: 'inline-block' }} />{x.l}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
