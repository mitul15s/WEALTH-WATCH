import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb';
import Asset from '@/lib/models/Asset';

// Secret token to authenticate the Python price-fetcher (set in .env.local)
const PRICE_UPDATE_SECRET = process.env.PRICE_UPDATE_SECRET || 'dev-secret-change-me';

interface PricePayload {
  ticker: string;
  price: number;
  change24h: number;
}

// ─── POST /api/prices ─────────────────────────────────────────────────
// Called by the Python fetcher with a batch of ticker prices
export async function POST(req: NextRequest) {
  try {
    const secret = req.headers.get('x-price-secret');
    if (secret !== PRICE_UPDATE_SECRET) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });
    }

    await connectDB();
    const body: { prices: PricePayload[] } = await req.json();

    if (!Array.isArray(body.prices) || body.prices.length === 0) {
      return NextResponse.json({ success: false, message: 'prices array required' }, { status: 400 });
    }

    const results: Array<{ ticker: string; updated: boolean; newPrice?: number }> = [];

    await Promise.all(
      body.prices.map(async ({ ticker, price, change24h }) => {
        if (!ticker || price == null) return;

        const result = await Asset.updateMany(
          { ticker: ticker.toUpperCase() },
          {
            $set: {
              currentPrice: price,
              change24h: change24h ?? 0,
              lastUpdated: new Date(),
            },
          }
        );

        results.push({
          ticker: ticker.toUpperCase(),
          updated: result.modifiedCount > 0,
          newPrice: price,
        });
      })
    );

    const updatedCount = results.filter((r) => r.updated).length;
    return NextResponse.json({
      success: true,
      message: `Updated prices for ${updatedCount}/${body.prices.length} tickers`,
      data: results,
    });
  } catch (err) {
    console.error('[POST /api/prices]', err);
    return NextResponse.json({ success: false, message: 'Failed to update prices' }, { status: 500 });
  }
}

// ─── GET /api/prices ──────────────────────────────────────────────────
// Returns last-known prices and timestamps for all tracked assets
export async function GET() {
  try {
    await connectDB();
    const assets = await Asset.find({}, 'ticker currentPrice change24h lastUpdated').lean();
    return NextResponse.json({ success: true, data: assets });
  } catch (err) {
    console.error('[GET /api/prices]', err);
    return NextResponse.json({ success: false, message: 'Failed to fetch prices' }, { status: 500 });
  }
}
