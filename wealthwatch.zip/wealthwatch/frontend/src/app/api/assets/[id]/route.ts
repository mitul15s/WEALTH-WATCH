import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb';
import Asset from '@/lib/models/Asset';

const DEMO_USER_ID = 'demo-user-001';

// ─── GET /api/assets/[id] ─────────────────────────────────────────────
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB();
    const asset = await Asset.findOne({ _id: params.id, userId: DEMO_USER_ID }).lean({ virtuals: true });
    if (!asset) return NextResponse.json({ success: false, message: 'Asset not found' }, { status: 404 });
    return NextResponse.json({ success: true, data: asset });
  } catch (err) {
    console.error('[GET /api/assets/[id]]', err);
    return NextResponse.json({ success: false, message: 'Failed to fetch asset' }, { status: 500 });
  }
}

// ─── PATCH /api/assets/[id] ───────────────────────────────────────────
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB();
    const body = await req.json();
    const allowed = ['name', 'quantity', 'avgBuyPrice', 'currentPrice', 'change24h'];
    const update: Record<string, unknown> = {};
    for (const key of allowed) {
      if (body[key] !== undefined) update[key] = body[key];
    }

    const asset = await Asset.findOneAndUpdate(
      { _id: params.id, userId: DEMO_USER_ID },
      { $set: { ...update, lastUpdated: new Date() } },
      { new: true, runValidators: true }
    ).lean({ virtuals: true });

    if (!asset) return NextResponse.json({ success: false, message: 'Asset not found' }, { status: 404 });
    return NextResponse.json({ success: true, data: asset });
  } catch (err) {
    console.error('[PATCH /api/assets/[id]]', err);
    return NextResponse.json({ success: false, message: 'Failed to update asset' }, { status: 500 });
  }
}

// ─── DELETE /api/assets/[id] ──────────────────────────────────────────
export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await connectDB();
    const asset = await Asset.findOneAndDelete({ _id: params.id, userId: DEMO_USER_ID });
    if (!asset) return NextResponse.json({ success: false, message: 'Asset not found' }, { status: 404 });
    return NextResponse.json({ success: true, message: 'Asset deleted successfully' });
  } catch (err) {
    console.error('[DELETE /api/assets/[id]]', err);
    return NextResponse.json({ success: false, message: 'Failed to delete asset' }, { status: 500 });
  }
}
