import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb';
import Asset from '@/lib/models/Asset';

// Hardcoded userId for demo — replace with session/auth in production
const DEMO_USER_ID = 'demo-user-001';

// ─── GET /api/assets ──────────────────────────────────────────────────
export async function GET(req: NextRequest) {
  try {
    await connectDB();
    const { searchParams } = new URL(req.url);
    const type = searchParams.get('type');

    const filter: Record<string, string> = { userId: DEMO_USER_ID };
    if (type) filter.type = type;

    const assets = await Asset.find(filter).sort({ currentValue: -1 }).lean({ virtuals: true });

    // Compute portfolio totals
    const totalValue     = assets.reduce((s, a) => s + (a as any).currentValue, 0);
    const totalCostBasis = assets.reduce((s, a) => s + (a as any).costBasis, 0);
    const totalPnL       = totalValue - totalCostBasis;
    const totalPnLPct    = totalCostBasis > 0 ? (totalPnL / totalCostBasis) * 100 : 0;

    const change24hAbs = assets.reduce((s, a) => {
      const prev = (a as any).currentPrice / (1 + (a.change24h || 0) / 100);
      return s + ((a as any).currentPrice - prev) * a.quantity;
    }, 0);
    const change24hPct = totalValue > 0 ? (change24hAbs / (totalValue - change24hAbs)) * 100 : 0;

    // Allocation by type
    const allocation = { crypto: 0, stocks: 0, gold: 0, cash: 0 };
    for (const a of assets) {
      allocation[a.type as keyof typeof allocation] += (a as any).currentValue;
    }

    return NextResponse.json({
      success: true,
      data: {
        assets,
        portfolio: {
          totalValue,
          totalCostBasis,
          totalUnrealizedPnL: totalPnL,
          totalUnrealizedPnLPct: totalPnLPct,
          totalChange24h: change24hAbs,
          totalChange24hPct: change24hPct,
          allocation,
        },
      },
    });
  } catch (err) {
    console.error('[GET /api/assets]', err);
    return NextResponse.json({ success: false, message: 'Failed to fetch assets' }, { status: 500 });
  }
}

// ─── POST /api/assets ─────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    await connectDB();
    const body = await req.json();
    const { name, ticker, type, quantity, avgBuyPrice } = body;

    if (!name || !ticker || !type || quantity == null || avgBuyPrice == null) {
      return NextResponse.json({ success: false, message: 'Missing required fields' }, { status: 400 });
    }

    // Check if asset with same ticker already exists for this user
    const existing = await Asset.findOne({ userId: DEMO_USER_ID, ticker: ticker.toUpperCase() });
    if (existing) {
      // Update quantity and recalculate average cost basis (weighted average)
      const totalQty   = existing.quantity + quantity;
      const newAvg     = (existing.quantity * existing.avgBuyPrice + quantity * avgBuyPrice) / totalQty;
      existing.quantity     = totalQty;
      existing.avgBuyPrice  = newAvg;
      existing.currentPrice = existing.currentPrice || avgBuyPrice;
      await existing.save();
      return NextResponse.json({ success: true, data: existing, message: 'Asset updated (position merged)' });
    }

    const asset = await Asset.create({
      userId: DEMO_USER_ID,
      name,
      ticker: ticker.toUpperCase(),
      type,
      quantity,
      avgBuyPrice,
      currentPrice: avgBuyPrice, // seed with buy price until fetcher runs
      change24h: 0,
    });

    return NextResponse.json({ success: true, data: asset }, { status: 201 });
  } catch (err) {
    console.error('[POST /api/assets]', err);
    return NextResponse.json({ success: false, message: 'Failed to create asset' }, { status: 500 });
  }
}
