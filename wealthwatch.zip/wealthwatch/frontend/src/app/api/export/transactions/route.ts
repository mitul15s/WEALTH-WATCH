import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb';
import Transaction from '@/lib/models/Transaction';
import { requireAuth } from '@/lib/auth';

// ─── GET /api/export/transactions ────────────────────────────────────
export async function GET(req: NextRequest) {
  const { userId, error } = await requireAuth();
  if (error) return error;

  await connectDB();
  const { searchParams } = new URL(req.url);
  const format  = searchParams.get('format') || 'csv';
  const assetId = searchParams.get('assetId');

  const filter: Record<string, unknown> = { userId };
  if (assetId) filter.assetId = assetId;

  const txs = await Transaction.find(filter).sort({ date: -1 }).lean();

  if (format === 'csv') {
    const headers = ['Date', 'Asset', 'Ticker', 'Type', 'Category', 'Quantity', 'Price (USD)', 'Total (USD)', 'Fee (USD)', 'Note'];
    const rows = txs.map(tx => [
      new Date(tx.date).toISOString().split('T')[0],
      `"${tx.assetName}"`,
      tx.assetTicker,
      tx.type,
      tx.assetType,
      tx.quantity.toString(),
      tx.price.toFixed(4),
      tx.total.toFixed(2),
      (tx.fee ?? 0).toFixed(2),
      `"${(tx.note ?? '').replace(/"/g, '""')}"`,
    ]);

    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const filename = `wealthwatch-transactions-${new Date().toISOString().split('T')[0]}.csv`;

    return new NextResponse(csv, {
      headers: {
        'Content-Type':        'text/csv',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Cache-Control':       'no-store',
      },
    });
  }

  // JSON fallback
  return NextResponse.json({ success: true, data: txs, total: txs.length });
}
