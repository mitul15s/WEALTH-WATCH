import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb';
import Snapshot from '@/lib/models/Snapshot';
import Asset from '@/lib/models/Asset';
import { requireAuth } from '@/lib/auth';

// ─── GET /api/snapshots?range=1M ────────────────────────────────────
export async function GET(req: NextRequest) {
  const { userId, error } = await requireAuth();
  if (error) return error;

  await connectDB();
  const { searchParams } = new URL(req.url);
  const range = searchParams.get('range') || '3M';

  const daysMap: Record<string, number> = {
    '1W': 7, '1M': 30, '3M': 90, '6M': 180, '1Y': 365, 'ALL': 3650,
  };
  const days  = daysMap[range] ?? 90;
  const since = new Date(Date.now() - days * 86_400_000);

  const snapshots = await Snapshot.find({ userId, date: { $gte: since } })
    .sort({ date: 1 })
    .lean();

  return NextResponse.json({ success: true, data: snapshots });
}

// ─── POST /api/snapshots ─────────────────────────────────────────────
// Write today's snapshot. Idempotent — safe to call multiple times per day.
// Call this from a Vercel Cron job or the Python fetcher after price updates.
export async function POST(req: NextRequest) {
  // Allow both authenticated users AND the price-fetcher service token
  const secret = req.headers.get('x-price-secret');
  const isService = secret === (process.env.PRICE_UPDATE_SECRET || 'dev-secret-change-me');

  let userId: string;

  if (isService) {
    // Service call: snapshot all users
    await connectDB();
    const userIds = await Asset.distinct('userId');
    const results = await Promise.all(userIds.map(uid => takeSnapshot(uid)));
    return NextResponse.json({ success: true, message: `Snapshotted ${results.length} users` });
  }

  const auth = await requireAuth();
  if (auth.error) return auth.error;
  userId = auth.userId;

  await connectDB();
  const snapshot = await takeSnapshot(userId);
  return NextResponse.json({ success: true, data: snapshot });
}

// ── Helper ────────────────────────────────────────────────────────────
async function takeSnapshot(userId: string) {
  const assets = await Asset.find({ userId }).lean({ virtuals: true });

  const breakdown = { crypto: 0, stocks: 0, gold: 0, cash: 0 };
  let totalValue = 0;

  for (const a of assets) {
    const val = (a as any).currentValue ?? 0;
    totalValue += val;
    breakdown[a.type as keyof typeof breakdown] += val;
  }

  // Start-of-day UTC so we get exactly one doc per day
  const today = new Date();
  today.setUTCHours(0, 0, 0, 0);

  return Snapshot.findOneAndUpdate(
    { userId, date: today },
    { $set: { totalValue, breakdown } },
    { upsert: true, new: true }
  );
}
