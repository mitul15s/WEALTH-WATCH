import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb';
import Transaction from '@/lib/models/Transaction';
import Asset from '@/lib/models/Asset';

const DEMO_USER_ID = 'demo-user-001';

// ─── GET /api/transactions ────────────────────────────────────────────
export async function GET(req: NextRequest) {
  try {
    await connectDB();
    const { searchParams } = new URL(req.url);
    const page     = parseInt(searchParams.get('page')  || '1');
    const limit    = parseInt(searchParams.get('limit') || '20');
    const assetId  = searchParams.get('assetId');
    const type     = searchParams.get('type');

    const filter: Record<string, unknown> = { userId: DEMO_USER_ID };
    if (assetId) filter.assetId = assetId;
    if (type)    filter.type    = type;

    const [transactions, total] = await Promise.all([
      Transaction.find(filter)
        .sort({ date: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      Transaction.countDocuments(filter),
    ]);

    return NextResponse.json({
      success: true,
      data: transactions,
      total,
      page,
      limit,
      hasMore: page * limit < total,
    });
  } catch (err) {
    console.error('[GET /api/transactions]', err);
    return NextResponse.json({ success: false, message: 'Failed to fetch transactions' }, { status: 500 });
  }
}

// ─── POST /api/transactions ───────────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    await connectDB();
    const body = await req.json();
    const { assetId, type, quantity, price, fee = 0, note = '', date } = body;

    if (!assetId || !type || !quantity || !price) {
      return NextResponse.json({ success: false, message: 'Missing required fields' }, { status: 400 });
    }

    const asset = await Asset.findOne({ _id: assetId, userId: DEMO_USER_ID });
    if (!asset) return NextResponse.json({ success: false, message: 'Asset not found' }, { status: 404 });

    const total = type === 'BUY'
      ? quantity * price + fee
      : quantity * price - fee;

    const tx = await Transaction.create({
      userId:      DEMO_USER_ID,
      assetId,
      assetName:   asset.name,
      assetTicker: asset.ticker,
      assetType:   asset.type,
      type,
      quantity,
      price,
      total,
      fee,
      note,
      date: date ? new Date(date) : new Date(),
    });

    // ── Update asset quantity and avgBuyPrice on BUY/SELL ────────────
    if (type === 'BUY') {
      const newQty  = asset.quantity + quantity;
      const newAvg  = (asset.quantity * asset.avgBuyPrice + quantity * price) / newQty;
      asset.quantity     = newQty;
      asset.avgBuyPrice  = newAvg;
      await asset.save();
    } else if (type === 'SELL') {
      asset.quantity = Math.max(0, asset.quantity - quantity);
      await asset.save();
    }

    return NextResponse.json({ success: true, data: tx }, { status: 201 });
  } catch (err) {
    console.error('[POST /api/transactions]', err);
    return NextResponse.json({ success: false, message: 'Failed to create transaction' }, { status: 500 });
  }
}
