import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb';
import Alert from '@/lib/models/Alert';
import Asset from '@/lib/models/Asset';
import { requireAuth } from '@/lib/auth';

// ─── GET /api/alerts ──────────────────────────────────────────────────
export async function GET(req: NextRequest) {
  const { userId, error } = await requireAuth();
  if (error) return error;

  await connectDB();
  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status') || 'active';

  const filter: Record<string, unknown> = { userId };
  if (status !== 'all') filter.status = status;

  const alerts = await Alert.find(filter).sort({ createdAt: -1 }).lean();
  return NextResponse.json({ success: true, data: alerts });
}

// ─── POST /api/alerts ─────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  const { userId, error } = await requireAuth();
  if (error) return error;

  await connectDB();
  const body = await req.json();
  const { assetId, condition, targetValue, notifyEmail = false } = body;

  if (!assetId || !condition || targetValue == null) {
    return NextResponse.json({ success: false, message: 'Missing required fields' }, { status: 400 });
  }

  const asset = await Asset.findOne({ _id: assetId, userId });
  if (!asset) return NextResponse.json({ success: false, message: 'Asset not found' }, { status: 404 });

  const alert = await Alert.create({
    userId,
    assetId,
    assetName:   asset.name,
    assetTicker: asset.ticker,
    condition,
    targetValue,
    notifyEmail,
    status: 'active',
  });

  return NextResponse.json({ success: true, data: alert }, { status: 201 });
}

// ─── DELETE /api/alerts?id=xxx ────────────────────────────────────────
export async function DELETE(req: NextRequest) {
  const { userId, error } = await requireAuth();
  if (error) return error;

  await connectDB();
  const { searchParams } = new URL(req.url);
  const id = searchParams.get('id');
  if (!id) return NextResponse.json({ success: false, message: 'id required' }, { status: 400 });

  const deleted = await Alert.findOneAndDelete({ _id: id, userId });
  if (!deleted) return NextResponse.json({ success: false, message: 'Alert not found' }, { status: 404 });

  return NextResponse.json({ success: true, message: 'Alert deleted' });
}
