import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/mongodb';
import Alert from '@/lib/models/Alert';
import Asset from '@/lib/models/Asset';

const PRICE_UPDATE_SECRET = process.env.PRICE_UPDATE_SECRET || 'dev-secret-change-me';

// ─── POST /api/alerts/evaluate ───────────────────────────────────────
// Called by the Python fetcher after prices are updated.
// Checks all active alerts and fires any that have been crossed.
export async function POST(req: NextRequest) {
  const secret = req.headers.get('x-price-secret');
  if (secret !== PRICE_UPDATE_SECRET) {
    return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });
  }

  await connectDB();

  const activeAlerts = await Alert.find({ status: 'active' }).lean();
  if (activeAlerts.length === 0) {
    return NextResponse.json({ success: true, message: 'No active alerts', triggered: 0 });
  }

  // Fetch all relevant assets in one query
  const assetIds = [...new Set(activeAlerts.map(a => a.assetId.toString()))];
  const assets   = await Asset.find({ _id: { $in: assetIds } }).lean({ virtuals: true });
  const assetMap = Object.fromEntries(assets.map(a => [a._id.toString(), a]));

  const triggered: string[] = [];

  await Promise.all(
    activeAlerts.map(async alert => {
      const asset = assetMap[alert.assetId.toString()];
      if (!asset) return;

      const currentPrice = asset.currentPrice ?? 0;
      const change24h    = asset.change24h    ?? 0;
      let shouldTrigger  = false;

      switch (alert.condition) {
        case 'above':
          shouldTrigger = currentPrice >= alert.targetValue;
          break;
        case 'below':
          shouldTrigger = currentPrice <= alert.targetValue;
          break;
        case 'change_pct_up':
          shouldTrigger = change24h >= alert.targetValue;
          break;
        case 'change_pct_down':
          shouldTrigger = change24h <= -Math.abs(alert.targetValue);
          break;
      }

      if (shouldTrigger) {
        await Alert.findByIdAndUpdate(alert._id, {
          $set: {
            status:       'triggered',
            triggeredAt:  new Date(),
            currentValue: currentPrice,
          },
        });
        triggered.push(alert._id.toString());

        // TODO: Send email notification if alert.notifyEmail is true
        // await sendAlertEmail(alert, asset, currentPrice);
      }
    })
  );

  return NextResponse.json({
    success:   true,
    evaluated: activeAlerts.length,
    triggered: triggered.length,
    alertIds:  triggered,
  });
}
