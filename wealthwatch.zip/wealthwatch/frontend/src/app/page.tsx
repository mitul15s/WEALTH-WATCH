'use client';

import { useState } from 'react';
import TopbarV2 from '@/components/layout/TopbarV2';
import NetWorthHero from '@/components/ui/NetWorthHero';
import AssetCards from '@/components/ui/AssetCards';
import PortfolioChart from '@/components/charts/PortfolioChart';
import AllocationChart from '@/components/charts/AllocationChart';
import TransactionList from '@/components/ui/TransactionList';
import AddAssetModal from '@/components/ui/AddAssetModal';
import AddTransactionModal from '@/components/ui/AddTransactionModal';
import { usePortfolio, useTransactions } from '@/hooks/usePortfolio';
import { T, mono } from '@/lib/theme';
import Link from 'next/link';

export default function DashboardPage() {
  const [assetModal, setAssetModal]  = useState(false);
  const [txModal,    setTxModal]     = useState(false);
  const { portfolio, loading, refetch, lastRefreshed } = usePortfolio(60_000);
  const { transactions, loading: txLoading } = useTransactions(undefined, 1);

  const alloc      = portfolio?.allocation ?? { crypto: 0, stocks: 0, gold: 0, cash: 0 };
  const totalValue = portfolio?.portfolio?.totalValue ?? 0;
  const assets     = portfolio?.assets ?? [];

  return (
    <>
      <TopbarV2
        onAddAsset={() => setAssetModal(true)}
        onAddTransaction={() => setTxModal(true)}
        lastRefreshed={lastRefreshed}
        onRefresh={refetch}
      />

      <div style={{ maxWidth: 1400, margin: '0 auto', padding: '20px 24px' }}>
        <NetWorthHero portfolio={portfolio ? { ...portfolio.portfolio, assets } : null} loading={loading} />
        <AssetCards assets={assets} allocation={alloc} totalValue={totalValue} loading={loading} />

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 12, marginBottom: 12 }}>
          <PortfolioChart currentValue={totalValue} />
          <AllocationChart allocation={alloc} totalValue={totalValue} />
        </div>

        {/* Recent activity */}
        <div style={{ background: T.surface, border: `0.5px solid ${T.border}`, borderRadius: 10, padding: '18px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
            <div style={{ fontSize: 12, fontWeight: 500, color: T.silver, letterSpacing: '0.03em' }}>Recent activity</div>
            <Link href="/transactions" style={{ fontSize: 10, fontFamily: mono, color: T.gold, textDecoration: 'none', letterSpacing: '0.06em' }}>
              View all →
            </Link>
          </div>
          <TransactionList transactions={transactions} loading={txLoading} limit={6} />
        </div>
      </div>

      <AddAssetModal open={assetModal} onClose={() => setAssetModal(false)} onSuccess={refetch} />
      <AddTransactionModal open={txModal} onClose={() => setTxModal(false)} onSuccess={refetch} assets={assets} />
    </>
  );
}
