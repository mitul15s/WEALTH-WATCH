'use client';

import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import toast from 'react-hot-toast';

const INPUT: React.CSSProperties = {
  width: '100%', background: '#1f222a',
  border: '0.5px solid rgba(255,255,255,0.13)', borderRadius: 9,
  padding: '11px 14px', color: '#e8e6e0',
  fontFamily: "'DM Mono', monospace", fontSize: 13, outline: 'none',
};

export default function RegisterPage() {
  const router = useRouter();
  const [name,     setName]     = useState('');
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [confirm,  setConfirm]  = useState('');
  const [loading,  setLoading]  = useState(false);
  const [errors,   setErrors]   = useState<Record<string, string>>({});

  function validate() {
    const e: Record<string, string> = {};
    if (!name.trim())        e.name     = 'Name is required';
    if (!email.trim())       e.email    = 'Email is required';
    if (password.length < 8) e.password = 'Password must be at least 8 characters';
    if (password !== confirm) e.confirm  = 'Passwords do not match';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      const res  = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });
      const json = await res.json();
      if (!json.success) throw new Error(json.message);

      toast.success('Account created! Signing you in…');
      await signIn('credentials', { email, password, callbackUrl: '/' });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Registration failed');
    } finally {
      setLoading(false);
    }
  }

  const Field = ({ label, id, error, children }: any) => (
    <div style={{ marginBottom: 14 }}>
      <label style={{ fontSize: 11, fontFamily: "'DM Mono', monospace", color: '#7a7a84', letterSpacing: '0.08em', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>
        {label}
      </label>
      {children}
      {error && <div style={{ fontSize: 10, color: '#c45c5c', marginTop: 4, fontFamily: "'DM Mono', monospace" }}>{error}</div>}
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', background: '#0c0d0f', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
      <div style={{ width: '100%', maxWidth: 400 }}>
        <div style={{ textAlign: 'center', marginBottom: 36 }}>
          <div style={{ width: 44, height: 44, background: '#d4952a', borderRadius: 11, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'DM Mono', monospace", fontSize: 20, fontWeight: 700, color: '#000', margin: '0 auto 14px' }}>W</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: '#e8e6e0' }}>Create account</div>
          <div style={{ fontSize: 13, color: '#7a7a84', marginTop: 4, fontFamily: "'DM Mono', monospace" }}>Start tracking your wealth</div>
        </div>

        <div style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.1)', borderRadius: 16, padding: '28px 28px' }}>
          {/* Google */}
          <button
            onClick={() => signIn('google', { callbackUrl: '/' })}
            style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, padding: '11px 0', borderRadius: 9, border: '0.5px solid rgba(255,255,255,0.15)', background: '#1f222a', color: '#e8e6e0', fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 500, cursor: 'pointer', marginBottom: 20 }}
          >
            <svg width="18" height="18" viewBox="0 0 18 18">
              <path fill="#4285F4" d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.874 2.684-6.615z"/>
              <path fill="#34A853" d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.909-2.259c-.805.54-1.836.86-3.047.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z"/>
              <path fill="#FBBC05" d="M3.964 10.71A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"/>
              <path fill="#EA4335" d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z"/>
            </svg>
            Continue with Google
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
            <div style={{ flex: 1, height: '0.5px', background: 'rgba(255,255,255,0.08)' }} />
            <span style={{ fontSize: 11, color: '#44454d', fontFamily: "'DM Mono', monospace" }}>OR</span>
            <div style={{ flex: 1, height: '0.5px', background: 'rgba(255,255,255,0.08)' }} />
          </div>

          <form onSubmit={handleSubmit}>
            <Field label="Full Name" error={errors.name}>
              <input style={{ ...INPUT, borderColor: errors.name ? '#c45c5c' : undefined }} placeholder="Ada Lovelace" value={name} onChange={e => setName(e.target.value)} />
            </Field>
            <Field label="Email" error={errors.email}>
              <input type="email" style={{ ...INPUT, borderColor: errors.email ? '#c45c5c' : undefined }} placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
            </Field>
            <Field label="Password" error={errors.password}>
              <input type="password" style={{ ...INPUT, borderColor: errors.password ? '#c45c5c' : undefined }} placeholder="Min. 8 characters" value={password} onChange={e => setPassword(e.target.value)} />
            </Field>
            <Field label="Confirm Password" error={errors.confirm}>
              <input type="password" style={{ ...INPUT, borderColor: errors.confirm ? '#c45c5c' : undefined }} placeholder="Repeat password" value={confirm} onChange={e => setConfirm(e.target.value)} />
            </Field>

            <button
              type="submit" disabled={loading}
              style={{ width: '100%', background: loading ? 'rgba(212,149,42,0.5)' : '#d4952a', color: '#000', border: 'none', borderRadius: 9, padding: '12px 0', fontFamily: "'Syne', sans-serif", fontSize: 14, fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer', marginTop: 6 }}
            >
              {loading ? 'Creating account…' : 'Create Account'}
            </button>
          </form>
        </div>

        <p style={{ textAlign: 'center', marginTop: 20, fontSize: 13, color: '#7a7a84', fontFamily: "'DM Mono', monospace" }}>
          Already have an account?{' '}
          <Link href="/auth/signin" style={{ color: '#d4952a', textDecoration: 'none' }}>Sign in →</Link>
        </p>
      </div>
    </div>
  );
}
