'use client';

import { useState, useEffect } from 'react';
import { signIn, useSession } from 'next-auth/react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { T, mono } from '@/lib/theme';

const INPUT: React.CSSProperties = {
  width: '100%', background: T.surface2, border: `0.5px solid ${T.border2}`,
  borderRadius: 8, padding: '10px 12px', color: T.platinum,
  fontFamily: mono, fontSize: 12, outline: 'none', transition: 'border-color 0.15s',
};

export default function SignInPage() {
  const router = useRouter();
  const params = useSearchParams();
  const { status } = useSession();
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState('');
  const callbackUrl = params.get('callbackUrl') || '/';

  useEffect(() => { if (status === 'authenticated') router.replace(callbackUrl); }, [status, router, callbackUrl]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(''); setLoading(true);
    const res = await signIn('credentials', { email, password, redirect: false, callbackUrl });
    setLoading(false);
    if (res?.error) setError('Invalid email or password');
    else if (res?.ok) router.replace(callbackUrl);
  }

  return (
    <div style={{ minHeight: '100vh', background: T.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
      <div style={{ width: '100%', maxWidth: 380 }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{ width: 40, height: 40, border: `1px solid ${T.gold}`, borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: mono, fontSize: 17, fontWeight: 500, color: T.gold, margin: '0 auto 14px' }}>W</div>
          <div style={{ fontSize: 20, fontWeight: 400, color: T.platinum }}>Welcome back</div>
          <div style={{ fontSize: 12, color: T.steel, marginTop: 4, fontFamily: mono }}>WealthWatch India</div>
        </div>

        <div style={{ background: T.surface, border: `0.5px solid ${T.border2}`, borderRadius: 12, padding: '24px 26px' }}>
          <button onClick={() => signIn('google', { callbackUrl })} disabled={loading}
            style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9, padding: '10px 0', borderRadius: 8, border: `0.5px solid ${T.border2}`, background: T.surface2, color: T.silver, fontFamily: "'Inter', sans-serif", fontSize: 12, fontWeight: 500, cursor: 'pointer', marginBottom: 18, transition: 'border-color 0.15s' }}>
            <svg width="16" height="16" viewBox="0 0 18 18">
              <path fill="#4285F4" d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.874 2.684-6.615z"/>
              <path fill="#34A853" d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.909-2.259c-.805.54-1.836.86-3.047.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z"/>
              <path fill="#FBBC05" d="M3.964 10.71A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"/>
              <path fill="#EA4335" d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z"/>
            </svg>
            Continue with Google
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
            <div style={{ flex: 1, height: '0.5px', background: T.border }} />
            <span style={{ fontSize: 10, color: T.iron, fontFamily: mono }}>or</span>
            <div style={{ flex: 1, height: '0.5px', background: T.border }} />
          </div>

          <form onSubmit={handleSubmit}>
            {error && <div style={{ background: 'rgba(217,112,112,0.08)', border: `0.5px solid rgba(217,112,112,0.3)`, borderRadius: 7, padding: '8px 12px', fontSize: 11, color: T.loss, fontFamily: mono, marginBottom: 14 }}>{error}</div>}
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 10, fontFamily: mono, color: T.steel, letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 5 }}>Email</div>
              <input type="email" required style={INPUT} placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" />
            </div>
            <div style={{ marginBottom: 18 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                <span style={{ fontSize: 10, fontFamily: mono, color: T.steel, letterSpacing: '0.07em', textTransform: 'uppercase' }}>Password</span>
              </div>
              <input type="password" required style={INPUT} placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" />
            </div>
            <button type="submit" disabled={loading} style={{ width: '100%', background: 'transparent', border: `0.5px solid ${T.gold}`, color: T.gold, borderRadius: 8, padding: '11px 0', fontFamily: "'Inter', sans-serif", fontSize: 13, fontWeight: 500, cursor: loading ? 'not-allowed' : 'pointer', transition: 'all 0.15s', letterSpacing: '0.02em' }}
              onMouseEnter={e => !loading && ((e.currentTarget as HTMLElement).style.background = 'rgba(201,170,113,0.08)')}
              onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'transparent'}>
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>
        </div>
        <p style={{ textAlign: 'center', marginTop: 18, fontSize: 12, color: T.steel, fontFamily: mono }}>
          No account? <Link href="/auth/register" style={{ color: T.gold, textDecoration: 'none' }}>Create one →</Link>
        </p>
      </div>
    </div>
  );
}
