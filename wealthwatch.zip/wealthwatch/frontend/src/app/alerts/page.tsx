'use client';

import { useState, useEffect } from 'react';
import TopbarV2 from '@/components/layout/TopbarV2';
import { formatCurrency, formatDateTime, ASSET_META } from '@/lib/utils';
import { Bell, BellOff, CheckCircle, Clock } from 'lucide-react';
import toast from 'react-hot-toast';

type AlertStatus = 'active' | 'triggered' | 'all';

const STATUS_STYLE: Record<string, { color: string; bg: string; icon: any; label: string }> = {
  active:    { color: '#d4952a', bg: 'rgba(212,149,42,0.1)',  icon: Clock,        label: 'Active'    },
  triggered: { color: '#5aab7e', bg: 'rgba(90,171,126,0.1)', icon: CheckCircle,  label: 'Triggered' },
  dismissed: { color: '#7a7a84', bg: 'rgba(255,255,255,0.05)', icon: BellOff,    label: 'Dismissed' },
};

export default function AlertsPage() {
  const [alerts,  setAlerts]  = useState<any[]>([]);
  const [filter,  setFilter]  = useState<AlertStatus>('active');
  const [loading, setLoading] = useState(true);

  async function fetchAlerts() {
    setLoading(true);
    try {
      const res  = await fetch(`/api/alerts?status=${filter === 'all' ? 'all' : filter}`);
      const json = await res.json();
      if (json.success) setAlerts(json.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { fetchAlerts(); }, [filter]);

  async function deleteAlert(id: string) {
    await fetch(`/api/alerts?id=${id}`, { method: 'DELETE' });
    setAlerts(prev => prev.filter(a => a._id !== id));
    toast.success('Alert removed');
  }

  const active    = alerts.filter(a => a.status === 'active').length;
  const triggered = alerts.filter(a => a.status === 'triggered').length;

  return (
    <>
      <TopbarV2 />
      <div style={{ maxWidth: 800, margin: '0 auto', padding: '24px 28px' }}>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
          <div>
            <h1 style={{ fontSize: 26, fontWeight: 700, marginBottom: 4 }}>Price Alerts</h1>
            <p style={{ fontSize: 13, color: '#7a7a84', fontFamily: "'DM Mono',monospace" }}>
              {active} active · {triggered} triggered
            </p>
          </div>
          <div style={{ display: 'flex', gap: 8, fontSize: 12 }}>
            {(['active', 'triggered', 'all'] as AlertStatus[]).map((f, i, arr) => (
              <button key={f} onClick={() => setFilter(f)} style={{ padding: '6px 14px', borderRadius: 8, border: filter === f ? '1px solid #d4952a' : '0.5px solid rgba(255,255,255,0.1)', background: filter === f ? 'rgba(212,149,42,0.1)' : 'none', color: filter === f ? '#d4952a' : '#7a7a84', fontFamily: "'DM Mono',monospace", fontSize: 11, letterSpacing: '0.06em', cursor: 'pointer', textTransform: 'uppercase' }}>
                {f}
              </button>
            ))}
          </div>
        </div>

        <div style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, overflow: 'hidden' }}>
          {loading ? (
            <div style={{ padding: '48px', textAlign: 'center', color: '#44454d', fontFamily: "'DM Mono',monospace", fontSize: 12 }}>Loading alerts…</div>
          ) : alerts.length === 0 ? (
            <div style={{ padding: '64px', textAlign: 'center' }}>
              <Bell size={32} color="#44454d" style={{ marginBottom: 12 }} />
              <div style={{ fontSize: 14, fontFamily: "'DM Mono',monospace", color: '#44454d' }}>No {filter !== 'all' ? filter : ''} alerts</div>
              <div style={{ fontSize: 12, color: '#2c2d32', fontFamily: "'DM Mono',monospace", marginTop: 6 }}>
                Open an asset's detail page to add a price alert
              </div>
            </div>
          ) : (
            <div>
              {alerts.map((alert, i) => {
                const meta    = ASSET_META[alert.assetType] ?? ASSET_META.crypto;
                const s       = STATUS_STYLE[alert.status]  ?? STATUS_STYLE.active;
                const Icon    = s.icon;
                return (
                  <div
                    key={alert._id}
                    style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      padding: '16px 20px',
                      borderBottom: i < alerts.length - 1 ? '0.5px solid rgba(255,255,255,0.05)' : 'none',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                      {/* Asset icon */}
                      <div style={{ width: 36, height: 36, borderRadius: 9, background: meta.dimColor, color: meta.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, flexShrink: 0 }}>
                        {meta.icon}
                      </div>

                      {/* Alert info */}
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 500 }}>{alert.assetName}</div>
                        <div style={{ fontSize: 12, fontFamily: "'DM Mono',monospace", color: '#7a7a84', marginTop: 2 }}>
                          Price {alert.condition === 'above' ? '≥' : '≤'} <span style={{ color: '#e8e6e0' }}>{formatCurrency(alert.targetValue, 2)}</span>
                          {alert.currentValue && (
                            <span style={{ marginLeft: 8, color: '#44454d' }}>
                              · hit {formatCurrency(alert.currentValue, 2)} on {formatDateTime(alert.triggeredAt)}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      {/* Status badge */}
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 10, fontFamily: "'DM Mono',monospace", padding: '3px 9px', borderRadius: 5, background: s.bg, color: s.color, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                        <Icon size={10} />
                        {s.label}
                      </span>

                      {/* Created date */}
                      <span style={{ fontSize: 10, color: '#44454d', fontFamily: "'DM Mono',monospace" }}>
                        {formatDateTime(alert.createdAt)}
                      </span>

                      {/* Delete */}
                      <button
                        onClick={() => deleteAlert(alert._id)}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#44454d', display: 'flex', alignItems: 'center', padding: 4, borderRadius: 5, transition: 'color 0.12s' }}
                        onMouseEnter={e => (e.currentTarget.style.color = '#c45c5c')}
                        onMouseLeave={e => (e.currentTarget.style.color = '#44454d')}
                      >
                        <BellOff size={14} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
