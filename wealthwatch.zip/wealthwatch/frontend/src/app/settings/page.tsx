'use client';

import { useState } from 'react';
import { useSession, signOut } from 'next-auth/react';
import TopbarV2 from '@/components/layout/TopbarV2';
import { Download, Trash2, Bell, User, Shield } from 'lucide-react';
import toast from 'react-hot-toast';

const SECTION = ({ title, icon: Icon, children }: any) => (
  <div style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '22px 24px', marginBottom: 16 }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20, paddingBottom: 14, borderBottom: '0.5px solid rgba(255,255,255,0.07)' }}>
      <Icon size={15} color="#d4952a" />
      <div style={{ fontSize: 14, fontWeight: 600, letterSpacing: '0.02em' }}>{title}</div>
    </div>
    {children}
  </div>
);

const ROW = ({ label, sub, children }: any) => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: '0.5px solid rgba(255,255,255,0.05)' }}>
    <div>
      <div style={{ fontSize: 13, fontWeight: 500 }}>{label}</div>
      {sub && <div style={{ fontSize: 12, color: '#7a7a84', fontFamily: "'DM Mono',monospace", marginTop: 2 }}>{sub}</div>}
    </div>
    <div>{children}</div>
  </div>
);

const TOGGLE = ({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) => (
  <button
    onClick={() => onChange(!value)}
    style={{
      width: 40, height: 22, borderRadius: 11,
      background: value ? '#d4952a' : 'rgba(255,255,255,0.1)',
      border: 'none', cursor: 'pointer', position: 'relative',
      transition: 'background 0.2s', flexShrink: 0,
    }}
  >
    <span style={{
      position: 'absolute', top: 3, left: value ? 21 : 3,
      width: 16, height: 16, borderRadius: '50%',
      background: '#fff', transition: 'left 0.2s',
    }} />
  </button>
);

const INPUT_STYLE: React.CSSProperties = {
  background: '#1f222a', border: '0.5px solid rgba(255,255,255,0.13)',
  borderRadius: 8, padding: '9px 12px', color: '#e8e6e0',
  fontFamily: "'DM Mono',monospace", fontSize: 13, outline: 'none',
};

export default function SettingsPage() {
  const { data: session } = useSession();

  const [name,          setName]          = useState(session?.user?.name || '');
  const [currency,      setCurrency]      = useState('USD');
  const [emailAlerts,   setEmailAlerts]   = useState(false);
  const [priceAlerts,   setPriceAlerts]   = useState(true);
  const [dailySummary,  setDailySummary]  = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);

  async function saveProfile() {
    setSavingProfile(true);
    await new Promise(r => setTimeout(r, 600)); // Simulate API call
    toast.success('Profile updated');
    setSavingProfile(false);
  }

  function exportCSV() {
    window.open('/api/export/transactions?format=csv', '_blank');
    toast.success('CSV download started');
  }

  async function deleteAccount() {
    if (!confirm('Delete your account and ALL data? This is permanent and cannot be undone.')) return;
    const confirm2 = prompt('Type "DELETE" to confirm:');
    if (confirm2 !== 'DELETE') { toast.error('Account deletion cancelled'); return; }
    toast.error('Account deletion: implement this in your auth flow');
  }

  return (
    <>
      <TopbarV2 />
      <div style={{ maxWidth: 760, margin: '0 auto', padding: '24px 28px' }}>

        <div style={{ marginBottom: 28 }}>
          <h1 style={{ fontSize: 26, fontWeight: 700, marginBottom: 4 }}>Settings</h1>
          <p style={{ fontSize: 13, color: '#7a7a84', fontFamily: "'DM Mono',monospace" }}>Manage your account and preferences</p>
        </div>

        {/* Profile */}
        <SECTION title="Profile" icon={User}>
          <ROW label="Display name" sub="Shown in the dashboard header">
            <input value={name} onChange={e => setName(e.target.value)} style={{ ...INPUT_STYLE, width: 200 }} />
          </ROW>
          <ROW label="Email" sub={session?.user?.email || 'Not set'}>
            <span style={{ fontSize: 12, fontFamily: "'DM Mono',monospace", color: '#7a7a84', padding: '4px 10px', background: 'rgba(255,255,255,0.05)', borderRadius: 6 }}>
              {session?.user?.image ? 'Google OAuth' : 'Credentials'}
            </span>
          </ROW>
          <ROW label="Base currency" sub="Used for all portfolio calculations">
            <select
              value={currency}
              onChange={e => setCurrency(e.target.value)}
              style={{ ...INPUT_STYLE, width: 100, appearance: 'none' }}
            >
              {['USD', 'EUR', 'GBP', 'JPY', 'INR', 'AUD', 'CAD'].map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </ROW>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 16 }}>
            <button
              onClick={saveProfile}
              disabled={savingProfile}
              style={{ background: '#d4952a', color: '#000', border: 'none', borderRadius: 8, padding: '9px 20px', fontFamily: "'Syne',sans-serif", fontSize: 13, fontWeight: 600, cursor: 'pointer' }}
            >
              {savingProfile ? 'Saving…' : 'Save Profile'}
            </button>
          </div>
        </SECTION>

        {/* Notifications */}
        <SECTION title="Notifications" icon={Bell}>
          <ROW label="Email alerts" sub="Receive email when price alerts trigger">
            <TOGGLE value={emailAlerts} onChange={setEmailAlerts} />
          </ROW>
          <ROW label="Price alerts" sub="In-app badge when alerts are triggered">
            <TOGGLE value={priceAlerts} onChange={setPriceAlerts} />
          </ROW>
          <ROW label="Daily portfolio summary" sub="Morning email with your portfolio snapshot">
            <TOGGLE value={dailySummary} onChange={setDailySummary} />
          </ROW>
        </SECTION>

        {/* Data */}
        <SECTION title="Data & Privacy" icon={Shield}>
          <ROW label="Export transactions" sub="Download all transactions as a CSV file">
            <button
              onClick={exportCSV}
              style={{ display: 'flex', alignItems: 'center', gap: 7, background: 'rgba(255,255,255,0.05)', border: '0.5px solid rgba(255,255,255,0.13)', borderRadius: 8, padding: '8px 14px', color: '#e8e6e0', fontFamily: "'Syne',sans-serif", fontSize: 13, cursor: 'pointer' }}
            >
              <Download size={13} /> Export CSV
            </button>
          </ROW>
          <ROW label="Price refresh interval" sub="How often prices are fetched by the Python fetcher">
            <span style={{ fontSize: 12, fontFamily: "'DM Mono',monospace", color: '#7a7a84' }}>Every 15 min</span>
          </ROW>
          <ROW label="Data retention" sub="Portfolio snapshots are kept indefinitely">
            <span style={{ fontSize: 12, fontFamily: "'DM Mono',monospace", color: '#7a7a84' }}>Unlimited</span>
          </ROW>
        </SECTION>

        {/* Danger zone */}
        <div style={{ background: 'rgba(196,92,92,0.06)', border: '0.5px solid rgba(196,92,92,0.2)', borderRadius: 12, padding: '22px 24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16, paddingBottom: 14, borderBottom: '0.5px solid rgba(196,92,92,0.15)' }}>
            <Trash2 size={15} color="#c45c5c" />
            <div style={{ fontSize: 14, fontWeight: 600, color: '#c45c5c' }}>Danger Zone</div>
          </div>

          <ROW label="Sign out" sub="Sign out of this device">
            <button
              onClick={() => signOut({ callbackUrl: '/auth/signin' })}
              style={{ background: 'none', border: '0.5px solid rgba(196,92,92,0.4)', borderRadius: 8, padding: '8px 14px', color: '#c45c5c', fontFamily: "'Syne',sans-serif", fontSize: 13, cursor: 'pointer' }}
            >
              Sign Out
            </button>
          </ROW>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0' }}>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Delete account</div>
              <div style={{ fontSize: 12, color: '#7a7a84', fontFamily: "'DM Mono',monospace", marginTop: 2 }}>
                Permanently delete your account and all portfolio data
              </div>
            </div>
            <button
              onClick={deleteAccount}
              style={{ background: 'rgba(196,92,92,0.1)', border: '0.5px solid rgba(196,92,92,0.4)', borderRadius: 8, padding: '8px 16px', color: '#c45c5c', fontFamily: "'Syne',sans-serif", fontSize: 13, fontWeight: 500, cursor: 'pointer' }}
            >
              Delete Account
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
