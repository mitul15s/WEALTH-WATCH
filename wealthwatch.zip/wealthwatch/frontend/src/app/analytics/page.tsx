'use client';

import { useMemo, useState } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell, PieChart, Pie,
} from 'recharts';
import TopbarV2 from '@/components/layout/TopbarV2';
import { usePortfolio } from '@/hooks/usePortfolio';
import { formatCurrency, formatPercent, ASSET_META, pnlColor, pnlBgColor } from '@/lib/utils';
import { TrendingUp, TrendingDown, DollarSign, Target } from 'lucide-react';

const METRIC = ({ icon: Icon, label, value, sub, color }: any) => (
  <div style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '18px 20px' }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
      <div style={{ width: 30, height: 30, borderRadius: 8, background: `${color}18`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon size={14} color={color} />
      </div>
      <div style={{ fontSize: 11, fontFamily: "'DM Mono',monospace", color: '#7a7a84', letterSpacing: '0.06em', textTransform: 'uppercase' }}>{label}</div>
    </div>
    <div style={{ fontSize: 24, fontWeight: 700, fontFamily: "'DM Mono',monospace", color: color || '#e8e6e0' }}>{value}</div>
    {sub && <div style={{ fontSize: 11, fontFamily: "'DM Mono',monospace", color: '#44454d', marginTop: 3 }}>{sub}</div>}
  </div>
);

export default function AnalyticsPage() {
  const { portfolio, loading } = usePortfolio();
  const [sortBy, setSortBy] = useState<'pnl' | 'pnlPct' | 'value'>('pnl');

  const assets = portfolio?.assets ?? [];

  const stats = useMemo(() => {
    if (!assets.length) return null;
    const totalPnL      = assets.reduce((s, a) => s + (a.unrealizedPnL ?? 0), 0);
    const totalCost     = assets.reduce((s, a) => s + (a.costBasis    ?? 0), 0);
    const totalValue    = assets.reduce((s, a) => s + (a.currentValue ?? 0), 0);
    const totalPnLPct   = totalCost > 0 ? (totalPnL / totalCost) * 100 : 0;
    const winners       = assets.filter(a => (a.unrealizedPnL ?? 0) > 0);
    const losers        = assets.filter(a => (a.unrealizedPnL ?? 0) < 0);
    const winRate       = assets.length > 0 ? (winners.length / assets.length) * 100 : 0;
    const best          = [...assets].sort((a, b) => (b.unrealizedPnLPct ?? 0) - (a.unrealizedPnLPct ?? 0))[0];
    const worst         = [...assets].sort((a, b) => (a.unrealizedPnLPct ?? 0) - (b.unrealizedPnLPct ?? 0))[0];
    const best24h       = [...assets].sort((a, b) => (b.change24h ?? 0) - (a.change24h ?? 0))[0];
    const worst24h      = [...assets].sort((a, b) => (a.change24h ?? 0) - (b.change24h ?? 0))[0];

    // 24h P&L
    const change24hAbs  = assets.reduce((s, a) => s + (a.change24hAbs ?? 0), 0);

    return { totalPnL, totalCost, totalValue, totalPnLPct, winRate, winners, losers, best, worst, best24h, worst24h, change24hAbs };
  }, [assets]);

  // Sort assets for bar chart
  const sortedAssets = useMemo(() =>
    [...assets].sort((a, b) => {
      if (sortBy === 'pnl')    return (b.unrealizedPnL    ?? 0) - (a.unrealizedPnL    ?? 0);
      if (sortBy === 'pnlPct') return (b.unrealizedPnLPct ?? 0) - (a.unrealizedPnLPct ?? 0);
      return (b.currentValue ?? 0) - (a.currentValue ?? 0);
    }),
    [assets, sortBy]
  );

  // Data for P&L bar chart
  const barData = sortedAssets.slice(0, 10).map(a => ({
    name:   a.ticker,
    pnl:    +(a.unrealizedPnL    ?? 0).toFixed(2),
    pnlPct: +(a.unrealizedPnLPct ?? 0).toFixed(2),
    value:  +(a.currentValue     ?? 0).toFixed(2),
    color:  (a.unrealizedPnL ?? 0) >= 0 ? '#5aab7e' : '#c45c5c',
  }));

  // Donut: winners vs losers
  const winLoseData = [
    { name: 'Profitable', value: stats?.winners.length ?? 0, color: '#5aab7e' },
    { name: 'At a Loss',  value: stats?.losers.length  ?? 0, color: '#c45c5c' },
  ].filter(d => d.value > 0);

  return (
    <>
      <TopbarV2 />
      <div style={{ maxWidth: 1400, margin: '0 auto', padding: '24px 28px' }}>

        {/* Header */}
        <div style={{ marginBottom: 24 }}>
          <h1 style={{ fontSize: 26, fontWeight: 700, marginBottom: 4 }}>P&amp;L Analytics</h1>
          <p style={{ fontSize: 13, color: '#7a7a84', fontFamily: "'DM Mono',monospace" }}>
            Unrealized gains, performance breakdown, and position analysis
          </p>
        </div>

        {loading ? (
          <div style={{ color: '#44454d', fontFamily: "'DM Mono',monospace", fontSize: 13 }}>Loading analytics…</div>
        ) : !stats ? (
          <div style={{ color: '#44454d', fontFamily: "'DM Mono',monospace", fontSize: 13, textAlign: 'center', padding: '60px 0' }}>
            Add assets to see your P&L analytics
          </div>
        ) : (
          <>
            {/* Summary metrics */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
              <METRIC icon={DollarSign} label="Total Unrealized P&L"
                value={(stats.totalPnL >= 0 ? '+' : '') + formatCurrency(stats.totalPnL, 0)}
                sub={formatPercent(stats.totalPnLPct) + ' vs cost basis'}
                color={pnlColor(stats.totalPnL)}
              />
              <METRIC icon={TrendingUp} label="24h P&L"
                value={(stats.change24hAbs >= 0 ? '+' : '') + formatCurrency(stats.change24hAbs, 0)}
                sub="today's change"
                color={pnlColor(stats.change24hAbs)}
              />
              <METRIC icon={Target} label="Win Rate"
                value={`${stats.winRate.toFixed(0)}%`}
                sub={`${stats.winners.length} winners · ${stats.losers.length} losers`}
                color="#d4952a"
              />
              <METRIC icon={DollarSign} label="Total Cost Basis"
                value={formatCurrency(stats.totalCost, 0)}
                sub={`${assets.length} positions`}
                color="#5a8fc2"
              />
            </div>

            {/* Best / Worst performers */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 20 }}>
              {[
                { label: 'Best performer', asset: stats.best,   metric: stats.best?.unrealizedPnLPct,  pos: true,  sub: 'all-time P&L %' },
                { label: 'Worst performer', asset: stats.worst, metric: stats.worst?.unrealizedPnLPct, pos: false, sub: 'all-time P&L %' },
                { label: 'Best today',     asset: stats.best24h,  metric: stats.best24h?.change24h,  pos: true,  sub: '24h change' },
                { label: 'Worst today',    asset: stats.worst24h, metric: stats.worst24h?.change24h, pos: false, sub: '24h change' },
              ].map(({ label, asset: a, metric, pos, sub }) => {
                if (!a) return null;
                const meta = ASSET_META[a.type];
                const val  = metric ?? 0;
                return (
                  <div key={label} style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '16px 18px' }}>
                    <div style={{ fontSize: 11, fontFamily: "'DM Mono',monospace", color: '#7a7a84', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 10 }}>{label}</div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                      <div style={{ width: 28, height: 28, borderRadius: 7, background: meta.dimColor, color: meta.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13 }}>{meta.icon}</div>
                      <div style={{ fontSize: 14, fontWeight: 600 }}>{a.name}</div>
                    </div>
                    <div style={{ fontSize: 20, fontWeight: 700, fontFamily: "'DM Mono',monospace", color: pos ? '#5aab7e' : '#c45c5c' }}>
                      {val >= 0 ? '+' : ''}{val.toFixed(2)}%
                    </div>
                    <div style={{ fontSize: 11, color: '#44454d', fontFamily: "'DM Mono',monospace", marginTop: 2 }}>{sub}</div>
                  </div>
                );
              })}
            </div>

            {/* P&L bar chart */}
            <div style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '22px 24px', marginBottom: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
                <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: '0.04em' }}>Position Breakdown</div>
                <div style={{ display: 'flex', gap: 0 }}>
                  {[
                    { k: 'pnl',    label: 'P&L $'  },
                    { k: 'pnlPct', label: 'P&L %'  },
                    { k: 'value',  label: 'Value'   },
                  ].map(({ k, label }, i, arr) => (
                    <button key={k} onClick={() => setSortBy(k as any)} style={{ padding: '4px 12px', background: sortBy === k ? '#1f222a' : 'none', border: '0.5px solid rgba(255,255,255,0.07)', borderLeft: i > 0 ? 'none' : undefined, borderRadius: i === 0 ? '6px 0 0 6px' : i === arr.length - 1 ? '0 6px 6px 0' : 0, color: sortBy === k ? '#e8e6e0' : '#7a7a84', fontFamily: "'DM Mono',monospace", fontSize: 11, cursor: 'pointer' }}>
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ height: 240 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={barData} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
                    <XAxis dataKey="name" tick={{ fill: '#44454d', fontSize: 11, fontFamily: "'DM Mono',monospace" }} tickLine={false} axisLine={false} />
                    <YAxis
                      tick={{ fill: '#44454d', fontSize: 10, fontFamily: "'DM Mono',monospace" }}
                      tickLine={false} axisLine={false} width={56}
                      tickFormatter={v =>
                        sortBy === 'pnlPct' ? `${v.toFixed(0)}%` : `$${(Math.abs(v) >= 1000 ? (v / 1000).toFixed(0) + 'k' : v.toFixed(0))}`
                      }
                    />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (!active || !payload?.length) return null;
                        const d = payload[0].payload;
                        return (
                          <div style={{ background: '#1f222a', border: '0.5px solid rgba(255,255,255,0.13)', borderRadius: 9, padding: '10px 14px', fontFamily: "'DM Mono',monospace" }}>
                            <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 6 }}>{d.name}</div>
                            <div style={{ fontSize: 12, color: d.color }}>P&L: {d.pnl >= 0 ? '+' : ''}{formatCurrency(d.pnl, 0)}</div>
                            <div style={{ fontSize: 11, color: '#7a7a84' }}>Return: {d.pnlPct >= 0 ? '+' : ''}{d.pnlPct.toFixed(2)}%</div>
                            <div style={{ fontSize: 11, color: '#7a7a84' }}>Value: {formatCurrency(d.value, 0)}</div>
                          </div>
                        );
                      }}
                      cursor={{ fill: 'rgba(255,255,255,0.03)' }}
                    />
                    <Bar dataKey={sortBy === 'value' ? 'value' : sortBy === 'pnlPct' ? 'pnlPct' : 'pnl'} radius={[4, 4, 0, 0]}>
                      {barData.map((entry, i) => (
                        <Cell key={i} fill={sortBy === 'value' ? '#5a8fc2' : entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Bottom: Winner/loser donut + full position table */}
            <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 16 }}>

              {/* Win/lose donut */}
              <div style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '22px 24px' }}>
                <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: '0.04em', marginBottom: 16 }}>Win / Loss Split</div>
                <div style={{ height: 160, position: 'relative' }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={winLoseData} cx="50%" cy="50%" innerRadius={50} outerRadius={72} paddingAngle={2} dataKey="value" strokeWidth={0}>
                        {winLoseData.map((entry) => (
                          <Cell key={entry.name} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', textAlign: 'center', pointerEvents: 'none' }}>
                    <div style={{ fontSize: 18, fontWeight: 700, fontFamily: "'DM Mono',monospace", color: '#5aab7e' }}>{stats.winRate.toFixed(0)}%</div>
                    <div style={{ fontSize: 9, color: '#7a7a84', fontFamily: "'DM Mono',monospace", textTransform: 'uppercase' }}>win rate</div>
                  </div>
                </div>
                <div style={{ marginTop: 8 }}>
                  {winLoseData.map(d => (
                    <div key={d.name} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 0', borderBottom: '0.5px solid rgba(255,255,255,0.05)' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ width: 8, height: 8, borderRadius: 2, background: d.color }} />
                        <span style={{ fontSize: 12, color: '#7a7a84' }}>{d.name}</span>
                      </div>
                      <span style={{ fontSize: 12, fontFamily: "'DM Mono',monospace", color: d.color }}>{d.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Full position table */}
              <div style={{ background: '#181a1f', border: '0.5px solid rgba(255,255,255,0.07)', borderRadius: 12, padding: '6px 0', overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr>
                      {['Asset', 'Value', 'Cost Basis', 'P&L ($)', 'P&L (%)', '24h'].map((h, i) => (
                        <th key={h} style={{ padding: '10px 16px', textAlign: i > 0 ? 'right' : 'left', fontSize: 11, fontFamily: "'DM Mono',monospace", color: '#7a7a84', letterSpacing: '0.08em', textTransform: 'uppercase', borderBottom: '0.5px solid rgba(255,255,255,0.07)', whiteSpace: 'nowrap' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {sortedAssets.map((a, i) => {
                      const meta   = ASSET_META[a.type];
                      const pnl    = a.unrealizedPnL    ?? 0;
                      const pnlPct = a.unrealizedPnLPct ?? 0;
                      const chg    = a.change24h         ?? 0;
                      return (
                        <tr key={a._id}
                          style={{ borderBottom: i < sortedAssets.length - 1 ? '0.5px solid rgba(255,255,255,0.04)' : 'none', transition: 'background 0.12s', cursor: 'pointer' }}
                          onMouseEnter={e => (e.currentTarget.style.background = '#1a1c22')}
                          onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                          onClick={() => window.location.href = `/assets/${a._id}`}
                        >
                          <td style={{ padding: '12px 16px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                              <div style={{ width: 26, height: 26, borderRadius: 7, background: meta.dimColor, color: meta.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12 }}>{meta.icon}</div>
                              <div>
                                <div style={{ fontSize: 13, fontWeight: 500 }}>{a.name}</div>
                                <div style={{ fontSize: 10, color: '#7a7a84', fontFamily: "'DM Mono',monospace" }}>{a.ticker}</div>
                              </div>
                            </div>
                          </td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontSize: 13, fontFamily: "'DM Mono',monospace" }}>{formatCurrency(a.currentValue ?? 0, 0)}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontSize: 13, fontFamily: "'DM Mono',monospace", color: '#7a7a84' }}>{formatCurrency(a.costBasis ?? 0, 0)}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontSize: 13, fontFamily: "'DM Mono',monospace", fontWeight: 500, color: pnlColor(pnl) }}>{pnl >= 0 ? '+' : ''}{formatCurrency(pnl, 0)}</td>
                          <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                            <span style={{ fontSize: 12, fontFamily: "'DM Mono',monospace", padding: '3px 7px', borderRadius: 4, background: pnlBgColor(pnl), color: pnlColor(pnl) }}>
                              {pnlPct >= 0 ? '+' : ''}{pnlPct.toFixed(1)}%
                            </span>
                          </td>
                          <td style={{ padding: '12px 16px', textAlign: 'right', fontSize: 12, fontFamily: "'DM Mono',monospace", color: chg >= 0 ? '#5aab7e' : '#c45c5c', fontWeight: 500 }}>
                            {chg >= 0 ? '+' : ''}{chg.toFixed(2)}%
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
}
