/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        bg:       '#0e0f11',
        surface:  '#15161a',
        surface2: '#1c1d23',
        platinum: '#c8cdd6',
        silver:   '#9ba3af',
        steel:    '#6b7280',
        iron:     '#3d4249',
        gold:     '#c9aa71',
        copper:   '#b87333',
        gain:     '#6dbf8a',
        loss:     '#d97070',
      },
      fontFamily: {
        sans: ['var(--font-inter)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
    },
  },
  plugins: [],
};
