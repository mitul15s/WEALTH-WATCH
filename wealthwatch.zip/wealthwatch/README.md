# WealthWatch 💰

A full-stack personal wealth & net-worth dashboard. Track Stocks, Crypto, Gold, and Cash with live prices, real authentication, P&L analytics, price alerts, and daily portfolio history snapshots.

## Tech Stack

| Layer      | Technology                                        |
|------------|---------------------------------------------------|
| Frontend   | Next.js 14 (App Router) + Tailwind CSS            |
| Auth       | NextAuth.js — Google OAuth + email/password       |
| Charts     | Recharts                                          |
| Backend    | Next.js API Routes (REST)                         |
| Database   | MongoDB + Mongoose                                |
| Prices     | Python (yfinance + CoinGecko + APScheduler)       |

---

## Pages

| Route           | Description                                         |
|-----------------|-----------------------------------------------------|
| `/`             | Dashboard — net worth hero, asset cards, charts     |
| `/assets`       | Asset list — sortable table with P&L, 24h change    |
| `/assets/[id]`  | Asset detail — price chart, alerts, tx history      |
| `/transactions` | Paginated transaction history with type filter      |
| `/analytics`    | P&L analytics — bar chart, win rate, best/worst     |
| `/alerts`       | Price alert management — active & triggered         |
| `/settings`     | Profile, notifications, CSV export, danger zone     |
| `/auth/signin`  | Sign in (credentials + Google)                      |
| `/auth/register`| Register new account                                |

---

## Project Structure

```
wealthwatch/
├── frontend/
│   └── src/
│       ├── app/
│       │   ├── page.tsx                         # Dashboard
│       │   ├── assets/page.tsx                  # Asset list
│       │   ├── assets/[id]/page.tsx             # Asset detail + alerts
│       │   ├── transactions/page.tsx            # Transaction history
│       │   ├── analytics/page.tsx               # P&L analytics
│       │   ├── alerts/page.tsx                  # Alert management
│       │   ├── settings/page.tsx                # User settings
│       │   ├── auth/signin/page.tsx             # Sign in
│       │   ├── auth/register/page.tsx           # Register
│       │   └── api/
│       │       ├── auth/[...nextauth]/route.ts  # NextAuth handler
│       │       ├── auth/register/route.ts       # User registration
│       │       ├── assets/route.ts              # GET, POST assets
│       │       ├── assets/[id]/route.ts         # GET, PATCH, DELETE
│       │       ├── transactions/route.ts        # GET, POST transactions
│       │       ├── prices/route.ts              # Price push endpoint
│       │       ├── snapshots/route.ts           # Portfolio history
│       │       ├── alerts/route.ts              # Alert CRUD
│       │       ├── alerts/evaluate/route.ts     # Alert evaluation
│       │       └── export/transactions/route.ts # CSV download
│       ├── components/
│       │   ├── layout/
│       │   │   ├── TopbarV2.tsx                 # Nav + auth + mobile
│       │   │   └── SessionWrapper.tsx           # NextAuth provider
│       │   ├── ui/
│       │   │   ├── NetWorthHero.tsx
│       │   │   ├── AssetCards.tsx
│       │   │   ├── AssetsTable.tsx
│       │   │   ├── TransactionList.tsx
│       │   │   ├── AddAssetModal.tsx
│       │   │   ├── AddTransactionModal.tsx
│       │   │   └── UserMenu.tsx                 # Avatar + dropdown
│       │   └── charts/
│       │       ├── PortfolioHistoryChart.tsx    # Real snapshot data
│       │       └── AllocationChart.tsx
│       ├── hooks/usePortfolio.ts
│       ├── lib/
│       │   ├── auth.ts                          # requireAuth() helper
│       │   ├── mongodb.ts                       # Mongoose connection
│       │   ├── mongodbClient.ts                 # Native client (NextAuth)
│       │   ├── utils.ts
│       │   └── models/
│       │       ├── User.ts
│       │       ├── Asset.ts
│       │       ├── Transaction.ts
│       │       ├── Snapshot.ts
│       │       └── Alert.ts
│       ├── middleware.ts                        # Route protection
│       └── types/index.ts
└── python/
    ├── price_fetcher.py                         # v2 — prices + alerts + snapshot
    └── requirements.txt
```

---

## Quick Start

### 1. Clone & install

```bash
git clone https://github.com/your-handle/wealthwatch.git
cd wealthwatch
cd frontend && npm install
```

### 2. Environment variables

```bash
cp .env.example frontend/.env.local
# Fill in:
#   MONGODB_URI          — from MongoDB Atlas
#   NEXTAUTH_SECRET      — openssl rand -base64 32
#   NEXTAUTH_URL         — http://localhost:3000
#   GOOGLE_CLIENT_ID     — from Google Cloud Console (optional)
#   GOOGLE_CLIENT_SECRET — from Google Cloud Console (optional)
#   PRICE_UPDATE_SECRET  — any long random string
```

### 3. Run dev server

```bash
cd frontend && npm run dev
# → http://localhost:3000
```

### 4. Start price fetcher

```bash
cd python
pip install -r requirements.txt
python price_fetcher.py
# Fetches prices every 15 min, evaluates alerts, takes daily snapshot
```

---

## API Reference

| Method | Endpoint                       | Auth            | Description                        |
|--------|--------------------------------|-----------------|------------------------------------|
| GET    | `/api/assets`                  | Session         | Portfolio snapshot                 |
| POST   | `/api/assets`                  | Session         | Add / merge asset position         |
| PATCH  | `/api/assets/:id`              | Session         | Edit asset                         |
| DELETE | `/api/assets/:id`              | Session         | Remove asset                       |
| GET    | `/api/transactions`            | Session         | Paginated transactions             |
| POST   | `/api/transactions`            | Session         | Log transaction                    |
| GET    | `/api/snapshots?range=3M`      | Session         | Portfolio history for chart        |
| POST   | `/api/snapshots`               | Session / Token | Take today's snapshot              |
| GET    | `/api/alerts`                  | Session         | List alerts                        |
| POST   | `/api/alerts`                  | Session         | Create alert                       |
| DELETE | `/api/alerts?id=xxx`           | Session         | Delete alert                       |
| POST   | `/api/alerts/evaluate`         | Token           | Evaluate all active alerts         |
| POST   | `/api/prices`                  | Token           | Push price batch (Python fetcher)  |
| GET    | `/api/export/transactions`     | Session         | Download CSV                       |

*Session = NextAuth JWT · Token = x-price-secret header*

---

## MongoDB Models

- **User** — name, email, passwordHash (bcrypt), currency
- **Asset** — userId, ticker, type, quantity, avgBuyPrice, currentPrice, change24h; virtual fields: currentValue, costBasis, unrealizedPnL
- **Transaction** — userId, assetId, type (BUY/SELL/DEPOSIT/WITHDRAW), quantity, price, total, fee, note, date
- **Snapshot** — userId, date (start-of-day UTC, unique per user/day), totalValue, breakdown {crypto, stocks, gold, cash}
- **Alert** — userId, assetId, condition (above/below/change_pct_up/down), targetValue, status (active/triggered/dismissed)

---

## Deployment

**Vercel (frontend + API)**
```bash
# Set all .env vars in Vercel dashboard
# vercel.json already configures daily snapshot cron at midnight UTC
vercel deploy
```

**Python fetcher (Railway / Render / VPS)**
```bash
# Set WEALTHWATCH_API_URL=https://your-app.vercel.app
# Set PRICE_UPDATE_SECRET to match Vercel env
python python/price_fetcher.py
```

---

## Roadmap — what's next

- [ ] Email notifications for triggered alerts (Resend / SendGrid)
- [ ] Realized P&L tracking (FIFO/LIFO cost basis calculation)
- [ ] Portfolio comparison vs S&P 500 benchmark
- [ ] Multi-currency support with FX conversion
- [ ] Mobile app (React Native / Expo)
- [ ] WebSocket live price streaming


A full-stack personal wealth & net-worth dashboard. Track Stocks, Crypto, Gold, and Cash with live price updates.

## Tech Stack

| Layer      | Technology                              |
|------------|-----------------------------------------|
| Frontend   | Next.js 14 (App Router) + Tailwind CSS  |
| Charts     | Recharts                                |
| Backend    | Next.js API Routes (REST)               |
| Database   | MongoDB + Mongoose                      |
| Prices     | Python (yfinance + CoinGecko)           |
| Scheduling | APScheduler (Python)                    |

---

## Project Structure

```
wealthwatch/
├── frontend/
│   └── src/
│       ├── app/
│       │   ├── page.tsx                  # Dashboard
│       │   ├── assets/page.tsx           # Assets management
│       │   ├── transactions/page.tsx     # Transaction history
│       │   └── api/
│       │       ├── assets/route.ts       # GET, POST assets
│       │       ├── assets/[id]/route.ts  # GET, PATCH, DELETE asset
│       │       ├── transactions/route.ts # GET, POST transactions
│       │       └── prices/route.ts       # Receive price updates
│       ├── components/
│       │   ├── layout/Topbar.tsx
│       │   ├── ui/
│       │   │   ├── NetWorthHero.tsx
│       │   │   ├── AssetCards.tsx
│       │   │   ├── AssetsTable.tsx
│       │   │   ├── TransactionList.tsx
│       │   │   └── AddAssetModal.tsx
│       │   └── charts/
│       │       ├── PortfolioChart.tsx    # Area chart (Recharts)
│       │       └── AllocationChart.tsx  # Donut chart (Recharts)
│       ├── hooks/
│       │   └── usePortfolio.ts           # Data fetching hooks
│       ├── lib/
│       │   ├── mongodb.ts                # DB connection singleton
│       │   ├── utils.ts                  # Formatters, helpers
│       │   └── models/
│       │       ├── Asset.ts              # Mongoose schema
│       │       └── Transaction.ts        # Mongoose schema
│       └── types/index.ts                # TypeScript types
└── python/
    ├── price_fetcher.py                  # Price fetch + push script
    └── requirements.txt
```

---

## Quick Start

### 1. Clone & install

```bash
git clone https://github.com/your-handle/wealthwatch.git
cd wealthwatch
npm install           # root dev tools
cd frontend && npm install
```

### 2. Set up environment variables

```bash
cp .env.example frontend/.env.local
# Edit frontend/.env.local with your MongoDB URI and secret
```

### 3. Start the dev server

```bash
# From project root
npm run dev
# → Frontend + API available at http://localhost:3000
```

### 4. Start the Python price fetcher (separate terminal)

```bash
cd python
pip install -r requirements.txt
cp ../.env.example .env
# Edit .env: set WEALTHWATCH_API_URL and PRICE_UPDATE_SECRET
python price_fetcher.py
```

---

## MongoDB Schema

### `assets` collection

```json
{
  "_id": "ObjectId",
  "userId": "demo-user-001",
  "name": "Bitcoin",
  "ticker": "BTC",
  "type": "crypto",
  "quantity": 0.5,
  "avgBuyPrice": 40000,
  "currentPrice": 65000,
  "change24h": 2.4,
  "lastUpdated": "ISODate",
  "createdAt": "ISODate",
  "updatedAt": "ISODate"
}
```

Virtuals (computed, not stored):
- `currentValue` = quantity × currentPrice
- `costBasis`    = quantity × avgBuyPrice
- `unrealizedPnL` / `unrealizedPnLPct`

### `transactions` collection

```json
{
  "_id": "ObjectId",
  "userId": "demo-user-001",
  "assetId": "ObjectId",
  "assetName": "Bitcoin",
  "assetTicker": "BTC",
  "assetType": "crypto",
  "type": "BUY",
  "quantity": 0.1,
  "price": 64000,
  "total": 6400,
  "fee": 0,
  "note": "",
  "date": "ISODate"
}
```

---

## API Reference

| Method | Endpoint                | Description                            |
|--------|-------------------------|----------------------------------------|
| GET    | `/api/assets`           | Portfolio snapshot with all assets     |
| POST   | `/api/assets`           | Add asset (merges duplicate tickers)   |
| PATCH  | `/api/assets/:id`       | Update asset quantity / price          |
| DELETE | `/api/assets/:id`       | Remove asset from portfolio            |
| GET    | `/api/transactions`     | Paginated transaction history          |
| POST   | `/api/transactions`     | Log new transaction                    |
| GET    | `/api/prices`           | Last-known prices for all tickers      |
| POST   | `/api/prices`           | Receive price batch (Python fetcher)   |

---

## Price Fetcher

The Python script runs on a configurable interval (default 15 min):

1. **CoinGecko** — fetches crypto spot prices + 24h change (free tier, no key)
2. **yfinance**  — batch-downloads stock / ETF prices from Yahoo Finance
3. **COMEX Gold** (GC=F) — gold spot price via yfinance futures feed

Prices are pushed to `/api/prices` with a shared secret (`x-price-secret` header) for lightweight auth.

---

## Deployment

### Frontend + API (Vercel)
```bash
npm run build   # build check
# Connect repo to Vercel → set MONGODB_URI and PRICE_UPDATE_SECRET in env vars
```

### Python Fetcher (Railway / Render / VPS)
```bash
# Dockerfile or procfile:
python python/price_fetcher.py
# Set env: WEALTHWATCH_API_URL=https://your-vercel-app.vercel.app
```

---

## Add Auth

The current version uses a hardcoded `demo-user-001` userId for simplicity.
To add real auth:
1. Install [NextAuth.js](https://next-auth.js.org/) or [Clerk](https://clerk.com/)
2. Replace `DEMO_USER_ID` in each API route with `session.user.id`
3. Protect all routes behind session middleware

---

## Roadmap

- [ ] Authentication (NextAuth / Clerk)
- [ ] Portfolio history snapshots (daily cron → store `HistoryPoint` docs)
- [ ] Add Transaction modal on Assets page
- [ ] CSV export of transactions
- [ ] Mobile-responsive layout
- [ ] Dark / light theme toggle
- [ ] Price alerts (email / push)
