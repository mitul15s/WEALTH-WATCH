# WealthWatch — VS Code Setup Guide

Complete step-by-step instructions to run this project locally.

---

## Prerequisites — install these first

| Tool | Version | Download |
|------|---------|----------|
| Node.js | 18 or 20 LTS | https://nodejs.org |
| Python | 3.10+ | https://python.org |
| Git | any | https://git-scm.com |
| VS Code | any | https://code.visualstudio.com |

Check you have them:
```bash
node -v      # should print v18.x or v20.x
npm -v       # should print 9.x or 10.x
python --version   # should print 3.10+
git --version
```

---

## Step 1 — Open the project in VS Code

1. Unzip `wealthwatch.zip` to a folder (e.g. `~/projects/wealthwatch`)
2. Open VS Code
3. **File → Open Folder** → select the `wealthwatch` folder
4. Open the integrated terminal: **Terminal → New Terminal** (or Ctrl+\`)

---

## Step 2 — MongoDB Atlas (free database)

1. Go to **https://cloud.mongodb.com** and create a free account
2. Click **Create** → choose **M0 Free** tier → any region → Create
3. **Database Access** (left sidebar) → Add New Database User
   - Username: `wealthwatch`
   - Password: click "Autogenerate" and copy it
   - Role: `Atlas Admin`
4. **Network Access** → Add IP Address → **Allow Access from Anywhere** (0.0.0.0/0)
5. **Database** → Connect → **Drivers** → copy the connection string

It looks like:
```
mongodb+srv://wealthwatch:<password>@cluster0.abc12.mongodb.net/?retryWrites=true&w=majority
```

Replace `<password>` with the password you copied, and add `/wealthwatch` before the `?`:
```
mongodb+srv://wealthwatch:mypassword@cluster0.abc12.mongodb.net/wealthwatch?retryWrites=true&w=majority
```

---

## Step 3 — Environment variables

In the VS Code terminal, navigate to the frontend folder:
```bash
cd frontend
```

Copy the example env file:
```bash
# macOS / Linux
cp ../.env.example .env.local

# Windows PowerShell
copy ..\\.env.example .env.local
```

Open `.env.local` in VS Code and fill in:

```env
MONGODB_URI=mongodb+srv://wealthwatch:yourpassword@cluster0.abc12.mongodb.net/wealthwatch?retryWrites=true&w=majority
NEXTAUTH_SECRET=<run the command below to generate this>
NEXTAUTH_URL=http://localhost:3000
PRICE_UPDATE_SECRET=any-long-random-string-you-choose
```

Generate `NEXTAUTH_SECRET` by running in the terminal:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Copy the output and paste it as the value of `NEXTAUTH_SECRET`.

---

## Step 4 — Install frontend dependencies

Still inside the `frontend` folder:
```bash
npm install
```

This installs Next.js, React, Recharts, NextAuth, Mongoose, and all other packages. Takes 1–2 minutes.

---

## Step 5 — Run the frontend

```bash
npm run dev
```

You should see:
```
▲ Next.js 14.2.4
- Local:        http://localhost:3000
- Environments: .env.local
✓ Ready in 2.1s
```

Open **http://localhost:3000** in your browser.
You'll be redirected to `/auth/signin` — click "Create account" to register.

---

## Step 6 — Python price fetcher (separate terminal)

Open a **second terminal** in VS Code (**Terminal → New Terminal**).

### Create a virtual environment

```bash
# From the project root (wealthwatch/)
cd python

# macOS / Linux
python3 -m venv venv
source venv/bin/activate

# Windows PowerShell
python -m venv venv
venv\Scripts\Activate.ps1
```

### Install dependencies

```bash
pip install -r requirements.txt
```

### Create the Python env file

```bash
# macOS / Linux
cp ../.env.example .env

# Windows
copy ..\\.env.example .env
```

Edit `python/.env` and set:
```env
WEALTHWATCH_API_URL=http://localhost:3000
PRICE_UPDATE_SECRET=any-long-random-string-you-choose
FETCH_INTERVAL_MINUTES=15
```

`PRICE_UPDATE_SECRET` must match exactly what you put in `frontend/.env.local`.

### Run the fetcher

```bash
python price_fetcher.py
```

You should see:
```
10:30:00 [INFO] WealthWatch India Price Fetcher v3
10:30:00 [INFO] API  : http://localhost:3000
10:30:00 [INFO] Every: 15 minutes
10:30:01 [INFO] USD/INR = 83.94
10:30:02 [INFO] NSE/BSE stocks: 20 tickers fetched
10:30:04 [INFO] Crypto: 10 tickers in INR from CoinGecko
10:30:05 [INFO] Gold: ₹71840/10g (-0.29%)
10:30:06 [INFO] POST /api/prices: Updated prices for 33 tickers
```

---

## Running both at once (recommended)

Install `concurrently` in the root folder to start everything with one command:

```bash
# From project root (wealthwatch/)
npm install
npm run dev
```

This uses the root `package.json` to run frontend and backend simultaneously.

---

## VS Code recommended extensions

Install these for the best experience — VS Code will prompt you automatically if you add a `.vscode/extensions.json`:

- **ESLint** (`dbaeumer.vscode-eslint`)
- **Prettier** (`esbenp.prettier-vscode`)
- **Tailwind CSS IntelliSense** (`bradlc.vscode-tailwindcss`)
- **TypeScript Importer** (`pmneo.tsimporter`)
- **Python** (`ms-python.python`)
- **MongoDB for VS Code** (`mongodb.mongodb-vscode`)

---

## Common errors & fixes

### `MONGODB_URI is not defined`
You forgot to create `frontend/.env.local`. Go back to Step 3.

### `Error: Cannot find module 'next-auth'`
You forgot to run `npm install`. Run it inside the `frontend/` folder.

### Port 3000 already in use
```bash
# macOS / Linux — kill whatever is on 3000
lsof -ti:3000 | xargs kill -9

# Windows PowerShell
netstat -ano | findstr :3000
taskkill /PID <pid> /F
```

### Python: `ModuleNotFoundError: No module named 'yfinance'`
Make sure your virtual environment is activated (you should see `(venv)` in the terminal prompt), then run `pip install -r requirements.txt` again.

### NSE prices not updating
NSE market hours are 9:15 AM – 3:30 PM IST, Monday–Friday. yfinance returns the last trading session's closing price outside these hours — this is expected.

### `zoneinfo` not found (Python < 3.9)
```bash
pip install backports.zoneinfo
```

---

## Project structure quick reference

```
wealthwatch/
├── frontend/              ← Next.js app (run: npm run dev)
│   ├── src/
│   │   ├── app/           ← Pages and API routes
│   │   ├── components/    ← UI components
│   │   ├── hooks/         ← usePortfolio, useTransactions
│   │   ├── lib/           ← MongoDB, models, utils
│   │   └── types/         ← TypeScript types
│   └── .env.local         ← Your secrets (never commit this)
├── python/                ← Price fetcher (run: python price_fetcher.py)
│   ├── price_fetcher.py
│   ├── requirements.txt
│   └── .env
└── SETUP.md               ← This file
```

---

## What works without the Python fetcher

The app runs fine without the price fetcher — you just won't get live price updates. When you add an asset, its `currentPrice` is seeded from your buy price. The fetcher updates it every 15 minutes once running.

